# ASTRA Health AI

Offline-first Mars EVA health and safety hackathon MVP. All profiles, missions, telemetry, baselines, and thresholds are synthetic. No real hardware or clinical validation. Demo limits are not NASA medical limits.

## Run

Requires Python 3.12+ and Node.js 20+ with npm (or pnpm).

```sh
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cd ../frontend
npm install
npm run build
cd ../backend
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000. The API serves the built React app. For UI development, run `npm run dev` in `frontend` alongside the API; Vite proxies `/api` to port 8000. Build the frontend before starting the single-server production demo.

```sh
cd backend
python -m pytest -q
```

## Implemented workflow

1. Futuristic navy/cyan/orange interface with an interactive anatomical schematic; demo astronaut sign-in and mission selection, with two individual synthetic baselines.
2. Pre-EVA assessment: sleep, stress, heart rate, blood pressure, symptom selection, a three-trial interactive reaction test (median), eight-location visual simulation, quality tracking, personal baseline comparisons, longitudinal charts, missing-input and stale-data holds.
3. Readiness review: required cognitive summaries and deterministic findings, named human attestation, blocked authorization for held/expired assessments. Demo sign-in and reviewer names are not authenticated roles.
4. Live EVA: locally generated VO₂ and VCO₂ in L/min, calculated RER, Recharts trend, suit reserve O₂ (%) and CO₂ (%), selectable nominal, low-O₂, high-CO₂, missing, stale, and elevated-RER scenarios.
5. Prioritized guidance, local audit inspection and JSON export. Critical alerts cannot be dismissed or overridden. Correcting a simulated scenario changes the active input; historical decisions remain logged.
6. Recovery report: session summary and locally saved recovery notes.

## Offline behavior

After the production app has loaded successfully and its service worker is ready, its HTML, JavaScript, and CSS are cached for offline reload on localhost. No external fonts or services are required. Assessments, critical rule evaluation, reaction test, human demo attestation, telemetry, and recovery work locally. Draft assessment and audit events persist in browser localStorage; authorization is deliberately not restored after reload. Closing the browser loses the in-memory telemetry session. Do not clear browser site storage if you need local records.

The local Python API can run without internet after dependencies are installed. It persists assessment decisions, human authorization, rejected authorization attempts, and submitted telemetry decisions in SQLite (`ASTRA_DB`, default `backend/astra.sqlite3`). Browser-generated telemetry and recovery reports are local-only. NeuroVision start/completion/interruption events queue locally and synchronize to SQLite automatically at startup and on reconnect, with a manual retry button and idempotent event IDs. Older general audit events still use JSON export; they are not automatically uploaded. Browser storage and SQLite logs are not tamper-proof. Initial installation requires downloaded dependencies.

## Safety contract

No LLM is called. Safety preserves `demo-v1` physiological and suit rules in Python and TypeScript and adds deterministic `neuro-v1` screening holds. RER is VCO₂ / VO₂; invalid or missing measurements produce no ratio. An elevated ratio produces **information only**, never an EVA abort decision. Suit O₂ and CO₂ rules evaluate independently of metabolic data and still raise critical alerts if metabolic sensors are missing.

All required assessment values, symptoms, and both NeuroVision screenings must be present in the Sprint 2 workflow. Serious symptoms produce critical alerts, other adverse findings produce holds. A passing assessment means **awaiting human**, never automatic authorization. Human attestation cannot bypass a hold or an assessment older than five minutes. Changes to crew, mission, or assessment invalidate local authorization. This is a simulated workflow without secure human identity verification.

Alert order: critical → hold → caution → info, then stable code ordering. Critical guidance requests stopping the task and contacting human mission control. No automated hardware control exists.

## API contracts

See `contracts/openapi.json` or runtime `/docs`. Pydantic models are the backend contract source. `frontend/src/rules.ts` defines client types and offline rule evaluation.

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/astronauts` | Synthetic crew and personal baselines |
| GET | `/api/missions` | Synthetic missions |
| POST | `/api/assessments` | Validated assessment, findings, persisted ID |
| POST | `/api/authorizations` | Explicit named human demo attestation |
| POST | `/api/telemetry/evaluate` | RER, suit alerts, data quality, audit |
| GET | `/api/audit` | Most recent 200 server audit events |

Example assessment body:

```json
{"astronaut_id":"a01","mission_id":"eva-042","sleep":7.6,"stress":3,"heart_rate":64,"systolic":118,"diastolic":76,"symptoms":["none"],"reaction_ms":280,"age_seconds":0}
```

## Demo thresholds (fictional)

- Sleep under 6 hours or stress at least 7: hold.
- Heart rate more than 25 bpm from individual baseline: hold.
- Systolic more than 25 mmHg or diastolic more than 15 mmHg from baseline: hold.
- Reaction time over 1.5× baseline: hold.
- Assessment data older than 300 seconds: hold.
- Suit oxygen reserve under 20% or suit CO₂ at least 1%: critical.
- Missing telemetry or telemetry older than 15 seconds: hold.
- RER over 1.1: informational context only.

These are hackathon demonstration choices, not medical or operational recommendations. Baselines are static mock records; no calibration or clinical validation is implemented.

## Sprint 2: NeuroVision and 3D mission interface

The existing six screens, legacy API routes, SQLite audit table, physiological thresholds, RER behavior, and human attestation workflow are retained. No external services are deployed or modified.

### Body explorer

- A locally generated Three.js anatomical schematic shows the head, eyes, brain, heart, lungs, ribs, spine, limbs, joints, hands, and feet. It is illustrative geometry, not a clinical anatomical model or a scan of the crew member.
- Drag to rotate, use rotation and zoom buttons for keyboard access, or reset to full-body view. Zoom is bounded. Desktop scrolling through body-system cards focuses the camera; explicit system buttons and markers work on mobile and desktop.
- Brain/vision, cardiovascular, respiratory/metabolic, and musculoskeletal selection populates a contextual panel using current ASTRA assessment data. Unavailable measurements show **Not Assessed**. No muscle/bone sensor or VO₂ baseline is fabricated.
- The panel provides fixed, non-diagnostic workflow guidance. It never generates medical treatments or authorizes EVA.
- Critical alerts remain in a fixed safety rail across all screens. The model and panels cannot dismiss or override them. RER alone remains information only.
- WebGL initialization failure or context loss activates a functional SVG 2D schematic. A manual 2D toggle and 3D retry are provided. Reduced-motion preference disables camera interpolation, orbit damping, CSS transitions, and telemetry chart animations.
- All built JavaScript/CSS chunks, including the lazy 3D renderer, are precached through a generated manifest. Cache names change with build asset hashes. The app needs one successful load/service-worker installation before an offline reload.

### NeuroVision protocol and fictional limits

- Three reaction stimuli and eight visual-screen locations (NW, N, NE, E, SE, S, SW, W).
- Wait for each stimulus, then click or press Space. Responses below 100 ms count as errors. A stimulus expires after 1500 ms and is recorded as missed. Early responses are recorded; they cannot silently count as a normal result.
- Each attempt stores UTC start/completion and stimulus timestamps, response times, missed stimuli, false starts, median, error rate, and completion quality. Switching screens or hiding the tab interrupts an active attempt. Reloading retains the unfinished local attempt as incomplete.
- Error rate = (missed stimuli + early/invalid responses) / (recorded stimuli + early/invalid responses). Miss rate = misses / recorded stimuli. No denominator means unavailable, never zero by default.
- Fictional baseline reaction/visual times: Maya 280/450 ms; Alex 310/480 ms. Fictional baseline miss/error rates are zero. Any missed stimulus or error degrades quality and holds readiness. Median above 1.5× the relevant baseline also holds readiness.
- Both current crew/mission screenings must be complete and no older than 300 seconds. Missing, interrupted, malformed, future-dated, duplicate-location, stale, or degraded data hold readiness. The latest attempt supersedes older successful attempts. New attempts invalidate the local prior authorization.
- A human still explicitly authorizes the simulated EVA after all deterministic checks pass. The server rechecks screening expiry at authorization and rejects a newer recorded attempt that supersedes the assessed evidence.
- This visual-screening simulation is **non-diagnostic**. It does not measure gaze, acuity, calibrated visual-field angles, SANS, or neurological disease. Browser timing and input-device latency are not clinically calibrated.

### Added API contracts

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/readiness` | Sprint 2 readiness: legacy assessment fields plus nullable `reaction_screening` and `visual_screening`; missing evidence holds |
| POST | `/api/neurovision/events` | Validate and persist start/completion/interruption event plus SQLite audit record; deduplicate event ID |
| GET | `/api/neurovision/events?astronaut_id=a01` | Inspect locally synchronized screening events |

`/api/assessments` remains the Sprint 1 compatibility endpoint with its original physiological contract and original 33 tests. It does not perform NeuroVision screening. The updated UI exclusively uses `/api/readiness`; do not use the legacy endpoint for Sprint 2 cognitive readiness. Existing `/api/authorizations` is preserved and checks stored Sprint 2 evidence when present. No authenticated human or AI role exists in this demo.

`neuro_events` is an additive SQLite table. Existing audit and assessment rows are preserved. Browser-local screening history and the event outbox are separate from the existing assessment draft/audit keys. Failed or corrupt storage explicitly holds cognitive readiness. Sync retries preserve unacknowledged events, and the API returns 409 for an event ID reused with a different payload. General offline readiness/authorization audit events are still local-only; only NeuroVision assessment events automatically reconcile. Browser history is not automatically restored from SQLite after site storage is cleared, although the history API retains synced events.

### Files changed and added

- Modified: `frontend/src/main.tsx`, `frontend/src/style.css`, `frontend/public/sw.js`, `frontend/vite.config.ts`, `frontend/package.json`, `frontend/pnpm-lock.yaml`, `frontend/pnpm-workspace.yaml`.
- Added: `frontend/src/BodyExplorer.tsx`, `frontend/src/bodyScene.ts`, `frontend/src/bodyData.ts`, `frontend/src/NeuroVisionPanel.tsx`, `frontend/src/neurovision.ts`.
- Modified: `backend/app/models.py`, `backend/app/main.py`; added `backend/app/neurovision.py`.
- Added: `backend/tests/test_neurovision.py`, `frontend/tests/neurovision.test.cjs`, `frontend/tests/body.test.cjs`, `frontend/tests/browser.cjs`.
- Updated: this README, `contracts/openapi.json`, production `frontend/dist/`, screenshots, and downloadable archive. Existing safety rules and original test files are unchanged.

### Test and browser commands

```sh
cd frontend
npm install
npx playwright install chromium
npm test
npm run build
# Start backend with uvicorn as described above, then:
npm run test:browser
```

With Node available on PATH and frontend dependencies installed, `cd backend && python -m pytest -q` runs the original 33 tests plus new tests, including Python/TypeScript rule parity. Parity tests explicitly skip when Node/dependencies are unavailable. The browser suite uses only the local app and saves desktop, NeuroVision, and mobile screenshots in the project directory. It uses fresh browser storage; it appends synthetic records to the local server database.

### Remaining limitations

No clinical, hardware, or operational validation; no eye tracking or screen calibration; illustrative anatomy; browser timing variability; no authenticated reviewer identity; no encrypted/tamper-proof audit storage; no medical diagnosis or AI treatment generation. LocalStorage has capacity limits and no multi-tab conflict resolution. Initial dependency installation and app caching need connectivity. Baselines and demo thresholds are static fictional inputs. Telemetry is generated locally; muscle/bone measures and individual metabolic baselines are unavailable. A full accessibility audit and physical-device test matrix remain outside this MVP.

`backend/requirements.lock.txt` records tested Python versions and `frontend/pnpm-lock.yaml` frontend resolutions. The chart bundle emits a non-blocking Vite size advisory.

See `IMPLEMENTATION.md` for verification results and run instructions for this delivery.

## ASTRA MuscleSense

Available in Pre-EVA Assessment and Post-EVA Recovery. Select astronaut-left or astronaut-right quadriceps to focus and highlight the thigh in the existing 3D explorer. Start the simulator, collect at least five samples, then save a phase-specific summary. Separate local records are kept per crew, mission, side and phase. The module works offline once the app is cached. Records are browser-local; MuscleSense does not currently synchronize to SQLite or alter the existing readiness rules.

The plot shows simulated sEMG RMS (µV), median frequency (Hz), and dynamic acceleration (g); angular velocity (°/s) is shown numerically. These are generated feature streams, not raw sampled EMG or real IMU packets. Baselines are fictional. A median-frequency decrease of at least 15% from baseline flags human review only. At least five samples are required; contact loss, artifacts, invalid values or quality below 80% make the window uninterpretable. These are demo thresholds without NASA or clinical validation. Comparisons require comparable workload and measurement conditions; sEMG cannot independently establish fatigue, injury, or recovery clearance.

Guidance sources: [SENIAM fixation recommendations](https://www.seniam.org/fixation.htm) and [Interpretation of EMG changes with fatigue: facts, pitfalls, and fallacies](https://pubmed.ncbi.nlm.nih.gov/12488084/). The app's pause/reassess/human-review workflow is a conservative design choice, not a validated treatment protocol. It prescribes no treatments or recovery duration.

Hardware roadmap:
- V1: Non-invasive surface sEMG + IMU; investigate repeatability, synchronization, contact quality, artifacts and electrical safety.
- V2: Sweat-resistant adhesive and microfluidic design research; investigate skin compatibility, comfort, sweat management and sensor drift.
- V3: Research-stage microneedle electrode concept only; qualified research, ethics and regulatory review would be required. No invasive procedure or hardware implementation is included.

Added `src/MuscleSensePanel.tsx`, `src/muscleSense.ts`, `tests/muscle.test.cjs`, and `tests/muscle-browser.cjs`. Updated `src/main.tsx`, `src/BodyExplorer.tsx`, and `src/bodyScene.ts` for integration. Backend endpoints, audit logs and safety rules are preserved. Run `node tests/muscle-browser.cjs` with the local server running after installing Playwright Chromium. Existing `npm test`, `npm run test:browser`, production build, and backend Pytest commands still apply.

Limitations: no hardware, no clinical validation, no raw-signal processing, no treatment recommendations, browser-local MuscleSense storage only, and no automatic readiness gating based on MuscleSense. Current simulator windows are lost when navigating away; explicitly saved summaries retain their measurements and timestamps.
