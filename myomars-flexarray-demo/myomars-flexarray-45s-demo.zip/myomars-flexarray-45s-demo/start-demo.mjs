#!/usr/bin/env node
// MyoMars FlexArray-MN · 45-second guided demo · one-command launcher.
//
// Needs only Node.js 18+ in the default mode (no npm install, no internet).
//
//   node start-demo.mjs               serve the prebuilt demo at http://127.0.0.1:8000/#flexarray
//   node start-demo.mjs --rebuild     install frontend dependencies and rebuild from source first
//   node start-demo.mjs --full        run the full ASTRA app with its Python backend (Python 3.12+)
//   node start-demo.mjs --port 8080   use another port (or set PORT)
//   node start-demo.mjs --open        also open the page in the default browser
//   node start-demo.mjs --help
//
// All data in this demo are synthetic. Not a medical device; not a diagnosis.
import http from 'node:http';
import net from 'node:net';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn, spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const FRONTEND = path.join(ROOT, 'frontend');
const DIST = path.join(FRONTEND, 'dist');
const BACKEND = path.join(ROOT, 'backend');
const HOST = '127.0.0.1';
const WIN = process.platform === 'win32';

const USAGE = `MyoMars FlexArray · 45-second guided demo

Usage: node start-demo.mjs [--rebuild] [--full] [--port N] [--open]

  (no options)  Serve the prebuilt demo. Needs Node.js 18+ only.
  --rebuild     Install frontend dependencies (pnpm if available, else npm ci)
                and rebuild frontend/dist from source before serving.
  --full        Run the full ASTRA app with its FastAPI backend instead of the
                static server. Needs Python 3.12+; creates backend/.venv and
                installs backend/requirements.lock.txt on first run.
  --port N      Port to listen on (default 8000, or PORT from the environment or .env).
  --open        Open the demo URL in the default browser once the server is up.
  --help        Show this help.

The server listens on 127.0.0.1 only (this computer). Stop it with Ctrl+C.`;

function fail(message) { console.error(`\n✖ ${message}\n`); process.exit(1); }

// ---- options -----------------------------------------------------------------
const major = Number(process.versions.node.split('.')[0]);
if (major < 18) fail(`Node.js 18 or newer is required (found ${process.versions.node}). Install the LTS release from https://nodejs.org`);

loadDotEnv(path.join(ROOT, '.env'));
const opts = {rebuild: false, full: false, open: false, port: Number(process.env.PORT || 8000)};
const argv = process.argv.slice(2);
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '--help' || a === '-h') { console.log(USAGE); process.exit(0); }
  else if (a === '--rebuild') opts.rebuild = true;
  else if (a === '--full') opts.full = true;
  else if (a === '--open') opts.open = true;
  else if (a === '--port') opts.port = Number(argv[++i]);
  else if (a.startsWith('--port=')) opts.port = Number(a.slice(7));
  else fail(`Unknown option "${a}".\n\n${USAGE}`);
}
if (!Number.isInteger(opts.port) || opts.port < 1 || opts.port > 65535) fail('--port must be a whole number between 1 and 65535.');
const URL_DEMO = `http://${HOST}:${opts.port}/#flexarray`;

// Minimal .env reader (KEY=VALUE lines). Real environment variables win. Only PORT and ASTRA_DB are used.
function loadDotEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    const value = m[2].replace(/^(['"])(.*)\1$/, '$2');
    if (process.env[m[1]] === undefined) process.env[m[1]] = value;
  }
}

// ---- helpers -----------------------------------------------------------------
function run(cmd, args, cwd) {
  console.log(`\n→ ${cmd} ${args.join(' ')}   (in ${path.relative(ROOT, cwd) || '.'})`);
  const r = spawnSync(cmd, args, {cwd, stdio: 'inherit', shell: needsShell(cmd)});
  if (r.error) fail(`Could not run ${cmd}: ${r.error.message}`);
  if (r.status !== 0) fail(`${cmd} ${args.join(' ')} failed (exit code ${r.status}).`);
}
function has(cmd) { return spawnSync(cmd, ['--version'], {stdio: 'ignore', shell: needsShell(cmd)}).status === 0; }
// npm and pnpm are .cmd scripts on Windows and need a shell; Python executables do not.
function needsShell(cmd) { return WIN && /^(npm|pnpm|npx)$/.test(cmd); }

function newestMtime(dir) {
  let newest = 0;
  for (const entry of fs.readdirSync(dir, {withFileTypes: true})) {
    const p = path.join(dir, entry.name);
    newest = Math.max(newest, entry.isDirectory() ? newestMtime(p) : fs.statSync(p).mtimeMs);
  }
  return newest;
}

function portFree(port) {
  return new Promise(resolve => {
    const probe = net.createServer().once('error', () => resolve(false)).once('listening', () => probe.close(() => resolve(true)));
    probe.listen(port, HOST);
  });
}
function portBusyMessage() {
  return `Port ${opts.port} is already in use.\n  · If the demo is already running, open ${URL_DEMO}\n  · Otherwise stop the other program, or choose another port: node start-demo.mjs --port 8080`;
}

function openBrowser(url) {
  const [cmd, args] = WIN ? ['cmd', ['/c', 'start', '""', url]] : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
  try { spawn(cmd, args, {stdio: 'ignore', detached: true}).on('error', () => {}).unref(); } catch { /* the URL is printed anyway */ }
}

function banner(mode) {
  console.log(`
MyoMars FlexArray-MN · 45-second guided demo · ${mode}
Synthetic data only · not a medical device · not a diagnosis

  Open in Chrome or Edge:  ${URL_DEMO}
  Then press "Start demo". The clock pauses at 0:35 until you click
  "Confirm review as demo reviewer" (it never confirms by itself).

Press Ctrl+C to stop the server.`);
}

// ---- 1. frontend build -----------------------------------------------------------
if (opts.rebuild) {
  if (!fs.existsSync(path.join(FRONTEND, 'node_modules'))) {
    if (has('pnpm') && fs.existsSync(path.join(FRONTEND, 'pnpm-lock.yaml'))) run('pnpm', ['install', '--frozen-lockfile'], FRONTEND);
    else if (fs.existsSync(path.join(FRONTEND, 'package-lock.json'))) run('npm', ['ci'], FRONTEND);
    else run('npm', ['install'], FRONTEND);
  }
  run('npm', ['run', 'build'], FRONTEND);
}
if (!fs.existsSync(path.join(DIST, 'index.html'))) fail('frontend/dist is missing. Run: node start-demo.mjs --rebuild');
if (!opts.rebuild && newestMtime(path.join(FRONTEND, 'src')) > fs.statSync(path.join(DIST, 'index.html')).mtimeMs + 2000) {
  console.warn('\n⚠ Files in frontend/src are newer than the prebuilt frontend/dist. To see your changes, run: node start-demo.mjs --rebuild');
}

// ---- 2a. full mode: FastAPI backend serves frontend/dist and the /api routes -------
if (opts.full) {
  const python = findPython();
  if (!python) fail('--full needs Python 3.12 or newer on PATH (python3, or "py -3" on Windows). The demo itself runs without it: node start-demo.mjs');
  const venv = path.join(BACKEND, '.venv');
  const vpy = WIN ? path.join(venv, 'Scripts', 'python.exe') : path.join(venv, 'bin', 'python');
  const lock = path.join(BACKEND, 'requirements.lock.txt');
  const marker = path.join(venv, '.myomars-lock.sha256');
  const lockHash = crypto.createHash('sha256').update(fs.readFileSync(lock)).digest('hex');
  if (!fs.existsSync(vpy)) run(python[0], [...python.slice(1), '-m', 'venv', venv], ROOT);
  if (!fs.existsSync(marker) || fs.readFileSync(marker, 'utf8').trim() !== lockHash) {
    run(vpy, ['-m', 'pip', 'install', '--disable-pip-version-check', '-r', lock], BACKEND);
    fs.writeFileSync(marker, lockHash + '\n');
  }
  if (!(await portFree(opts.port))) fail(portBusyMessage());
  const db = path.resolve(ROOT, process.env.ASTRA_DB || path.join('backend', 'astra.sqlite3'));
  banner('full ASTRA app (FastAPI backend)');
  console.log(`  Backend audit log (synthetic data only): ${path.relative(ROOT, db)}\n`);
  const child = spawn(vpy, ['-m', 'uvicorn', 'app.main:app', '--host', HOST, '--port', String(opts.port)], {cwd: BACKEND, stdio: 'inherit', env: {...process.env, ASTRA_DB: db}});
  for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => child.kill(sig));
  child.on('exit', code => process.exit(code ?? 0));
  if (opts.open) waitForServer().then(ok => ok && openBrowser(URL_DEMO));
} else {
  // ---- 2b. demo-only mode: static server for frontend/dist -----------------------
  serveStatic();
}

function findPython() {
  const candidates = WIN ? [['py', '-3'], ['python']] : [['python3'], ['python']];
  for (const c of candidates) {
    const r = spawnSync(c[0], [...c.slice(1), '-c', 'import sys;print("%d.%d" % sys.version_info[:2])'], {encoding: 'utf8'});
    if (r.status !== 0) continue;
    const [M, m] = r.stdout.trim().split('.').map(Number);
    if (M > 3 || (M === 3 && m >= 12)) return c;
  }
  return null;
}

function waitForServer(tries = 100) {
  return new Promise(resolve => {
    const attempt = n => http.get(`http://${HOST}:${opts.port}/`, res => { res.resume(); resolve(true); })
      .on('error', () => (n > 0 ? setTimeout(() => attempt(n - 1), 300) : resolve(false)));
    attempt(tries);
  });
}

function serveStatic() {
  const TYPES = {
    '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.map': 'application/json; charset=utf-8',
    '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
    '.ico': 'image/x-icon', '.woff': 'font/woff', '.woff2': 'font/woff2', '.glb': 'model/gltf-binary',
    '.txt': 'text/plain; charset=utf-8', '.webmanifest': 'application/manifest+json',
  };
  const server = http.createServer((req, res) => {
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
    catch { res.writeHead(400).end(); return; }
    // Demo-only mode has no backend. Drop /api connections so the app sees an
    // unreachable server and uses its existing offline path (exactly as when the
    // backend is down). The 45-second demo itself never calls /api.
    if (pathname === '/api' || pathname.startsWith('/api/')) { req.socket.destroy(); return; }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, {Allow: 'GET, HEAD'}).end(); return; }
    if (pathname.endsWith('/')) pathname += 'index.html';
    const file = path.resolve(DIST, '.' + pathname);
    if (!file.startsWith(DIST + path.sep)) { res.writeHead(403).end(); return; }
    fs.stat(file, (err, st) => {
      if (err || !st.isFile()) { res.writeHead(404, {'Content-Type': 'text/plain; charset=utf-8'}).end('Not found'); return; }
      res.writeHead(200, {
        'Content-Type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream',
        'Content-Length': st.size,
        // Hashed bundles can be cached; the shell, manifest and service worker must revalidate.
        'Cache-Control': pathname.startsWith('/assets/') ? 'public, max-age=31536000, immutable' : 'no-cache',
        'X-Content-Type-Options': 'nosniff',
      });
      if (req.method === 'HEAD') res.end(); else fs.createReadStream(file).pipe(res);
    });
  });
  server.on('error', e => fail(e.code === 'EADDRINUSE' ? portBusyMessage() : `Server error: ${e.message}`));
  server.listen(opts.port, HOST, () => {
    banner('demo-only mode (no backend)');
    console.log('  Other ASTRA screens work in their offline/local mode. Use --full for the Python backend.\n');
    if (opts.open) openBrowser(URL_DEMO);
  });
  for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { server.close(); process.exit(0); });
}
