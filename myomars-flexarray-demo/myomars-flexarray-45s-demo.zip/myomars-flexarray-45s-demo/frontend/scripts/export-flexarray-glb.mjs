// Export the ASTRA FlexArray-MN V2.1 model to GLB (glTF 2.0 binary), in presentation and engineering visualization scales.
// Reads the same geometry specification the 3D Explorer uses (src/flexarray/flexArrayGeometry.ts)
// and rebuilds the six layers as plain triangle meshes (no instancing, no fat lines) so the files
// open in Blender, PowerPoint, Windows 3D Viewer, and any glTF 2.0 viewer.
//
//   node scripts/export-flexarray-glb.mjs [outDir]      (default: ../assets/3d)
//
// Does not touch the Explorer source. Output units: metres, +Y up (glTF convention).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import ts from 'typescript';
import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { mergeGeometries, mergeVertices } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const outDir = path.resolve(process.argv[2] ?? path.join(root, '..', 'assets', '3d'));

// --- load the Explorer's geometry spec (TypeScript, transpiled in memory) ---
async function loadTs(file) {
  const src = fs.readFileSync(file, 'utf8');
  const js = ts.transpileModule(src, { compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 } }).outputText;
  return import('data:text/javascript;base64,' + Buffer.from(js).toString('base64'));
}
const G = await loadTs(path.join(root, 'src/flexarray/flexArrayGeometry.ts'));
const D = await loadTs(path.join(root, 'src/flexarray/flexArrayData.ts'));
const { FOOTPRINT, COLORS, COMPONENTS, SCALE_PROFILES, layerStack, layerY, scaleReadout, electrodeGrid, sweatRoutes, serpentine, ENGINEERING_THICKNESS, ENGINEERING_DETAILS } = G;

// --- Node polyfill: GLTFExporter uses FileReader for binary output ---
globalThis.FileReader ??= class {
  readAsArrayBuffer(blob) { blob.arrayBuffer().then(b => { this.result = b; this.onloadend?.(); }); }
  readAsDataURL(blob) { blob.arrayBuffer().then(b => { this.result = `data:${blob.type || 'application/octet-stream'};base64,` + Buffer.from(b).toString('base64'); this.onloadend?.(); }); }
};

const UNIT_TO_M = 0.01; // scene unit = 10 mm
const ROWS = 8, COLS = 8;   // default candidate grid (same as Explorer default)

// ---------- materials (mirroring the Explorer's look) ----------
const mats = new Map();
function mat(name, color, { opacity = 1, metalness = 0.1, roughness = 0.35, emissive = null, emissiveIntensity = 0 } = {}) {
  if (mats.has(name)) return mats.get(name);
  const m = new THREE.MeshStandardMaterial({ name, color, metalness, roughness, transparent: opacity < 1, opacity, side: THREE.DoubleSide });
  if (emissive) { m.emissive = new THREE.Color(emissive); m.emissiveIntensity = emissiveIntensity; }
  mats.set(name, m);
  return m;
}
const GOLD = () => mat('Gold_Contact', COLORS.gold, { metalness: 0.85, roughness: 0.28, emissive: '#5a3d0c', emissiveIntensity: 0.35 });
const TRACE_GOLD = () => mat('Gold_Trace', '#d6b25d', { metalness: 0.8, roughness: 0.3 });

// ---------- geometry helpers ----------
function roundedRect(w, d, r) {
  const s = new THREE.Shape(), x = -w / 2, y = -d / 2;
  s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + d - r); s.quadraticCurveTo(x + w, y + d, x + w - r, y + d);
  s.lineTo(x + r, y + d); s.quadraticCurveTo(x, y + d, x, y + d - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y);
  return s;
}
function slab(thickness, hole = 0) {
  const shape = roundedRect(FOOTPRINT.width, FOOTPRINT.depth, FOOTPRINT.radius);
  if (hole > 0) {
    const h = roundedRect(FOOTPRINT.width - hole * 2, FOOTPRINT.depth - hole * 2, Math.max(0.1, FOOTPRINT.radius - hole * 0.6));
    shape.holes.push(new THREE.Path(h.getPoints(24).reverse()));
  }
  const g = new THREE.ExtrudeGeometry(shape, { depth: thickness, bevelEnabled: false, curveSegments: 18 });
  g.rotateX(-Math.PI / 2); // lie in XZ, thickness along +Y (same as Explorer)
  return g;
}
const clean = g => { const n = g.index ? g.toNonIndexed() : g; for (const k of Object.keys(n.attributes)) if (!['position', 'normal', 'uv'].includes(k)) n.deleteAttribute(k); if (!n.attributes.uv) n.setAttribute('uv', new THREE.Float32BufferAttribute(new Float32Array(n.attributes.position.count * 2), 2)); return n; };
const placed = (geo, x, y, z, rx = 0) => { const g = geo.clone(); if (rx) g.rotateX(rx); g.translate(x, y, z); return clean(g); };
const weld = g => mergeVertices(g, 1e-5); // shared vertices -> indexed, much smaller files
const merge = parts => weld(mergeGeometries(parts.map(clean), false));
function tube(points, radius = 0.012) {
  const path3 = new THREE.CurvePath();
  for (let i = 1; i < points.length; i++) path3.add(new THREE.LineCurve3(new THREE.Vector3(...points[i - 1]), new THREE.Vector3(...points[i])));
  return clean(new THREE.TubeGeometry(path3, Math.max(8, points.length * 4), radius, 8, false));
}
const mesh = (name, geometry, material) => { const m = new THREE.Mesh(geometry.index ? geometry : weld(geometry), material); m.name = name; return m; };

// ---------- the six layers ----------
function buildLayer(index0, mode) {
  const spec = D.LAYERS[index0], g = layerStack(mode)[index0], top = g.thickness, P = SCALE_PROFILES[mode];
  const group = new THREE.Group();
  group.name = `L${spec.index}_${spec.shortName.replace(/[^A-Za-z0-9]+/g, '_')}`;
  group.userData = { layer_index: spec.index, layer_id: spec.id, layer_name: spec.name, validation_status: spec.validation_status,
    thickness_um_rendered: Math.round(top * 10000), thickness_um_engineering: ENGINEERING_THICKNESS[spec.id].um, thickness_basis: ENGINEERING_THICKNESS[spec.id].basis };
  const base = mat(`L${spec.index}_Substrate`, g.color, { opacity: g.opacity });
  group.add(mesh(`${group.name}__Substrate`, clean(slab(g.thickness, spec.id === 'adhesive-frame' ? 0.8 : 0)), base));

  if (spec.id === 'protective-film') {
    const pore = new THREE.CircleGeometry(0.045, 12), parts = [];
    for (let r = 0; r < 9; r++) for (let c = 0; c < 13; c++) parts.push(placed(pore, (c - 6) * 0.42, top + P.poreLift, (r - 4) * 0.42, -Math.PI / 2));
    group.add(mesh(`${group.name}__BreathablePores`, merge(parts), mat('L1_Pores', '#0b2a44', { opacity: 0.75 })));
  }
  if (spec.id === 'microneedle-array') {
    const pts = electrodeGrid(ROWS, COLS);
    const pad = new THREE.CylinderGeometry(P.pad.radius, P.pad.radius, P.pad.height, 20);
    const needle = new THREE.ConeGeometry(P.needle.radius, P.needle.length, 16); needle.rotateX(Math.PI); // tip points toward skin (-Y)
    group.add(mesh(`${group.name}__ContactPads`, merge(pts.map(p => placed(pad, p.x, top + P.pad.height / 2, p.z))), GOLD()));
    const needles = mesh(`${group.name}__Microneedles`, merge(pts.map(p => placed(needle, p.x, top - P.needle.length / 2, p.z))), GOLD());
    const r = scaleReadout(mode);
    needles.userData = { candidate_length_um: r.candidateNeedleUm, rendered_length_mm: r.renderedNeedleMm, exaggeration: r.needleExaggeration, basis: 'research candidate, unvalidated' };
    group.add(needles);
    const traces = [];
    for (let r = 0; r < ROWS; r++) { const z = (r - (ROWS - 1) / 2) * 0.5 + 0.16; traces.push(tube([[-FOOTPRINT.width / 2 + 0.4, top + P.traceRadius, z], [((COLS - 1) / 2) * 0.5, top + P.traceRadius, z]], P.traceRadius)); }
    group.add(mesh(`${group.name}__RowTraces`, merge(traces), TRACE_GOLD()));
  }
  if (spec.id === 'sweat-management') {
    const routes = sweatRoutes(ROWS, COLS);
    group.add(mesh(`${group.name}__MicrofluidicChannels`, merge(routes.map(r => tube(r.map(([x, z]) => [x, top + P.channelRadius, z]), P.channelRadius))),
      mat('L3_Channel', COLORS.cyan, { opacity: 0.9, emissive: COLORS.cyan, emissiveIntensity: 0.6 })));
    const ring = new THREE.TorusGeometry(0.14, P.ringTube, 8, 24);
    group.add(mesh(`${group.name}__ElectrodeIsolationRings`, merge(electrodeGrid(ROWS, COLS).map(p => placed(ring, p.x, top + P.ringTube, p.z, Math.PI / 2))),
      mat('L3_IsolationRing', '#9ef6ff', { opacity: 0.75, emissive: COLORS.cyan, emissiveIntensity: 0.5 })));
  }
  if (spec.id === 'flex-electronics') {
    for (const c of COMPONENTS) {
      const m = mat(`L4_${c.id.toUpperCase()}`, c.color, { opacity: c.id === 'battery' ? 0.9 : 1, metalness: c.id === 'battery' ? 0.6 : 0.2, roughness: 0.4 });
      const part = mesh(`${group.name}__${c.label.replace(/[^A-Za-z0-9]+/g, '_').replace(/_$/, '')}`, clean(new THREE.BoxGeometry(c.w, c.h, c.d)), m);
      part.position.set(c.x, top + c.h / 2, c.z);
      part.userData = { component: c.label, placement: 'conceptual', package_height_mm: c.h * 10, basis: 'assumption' };
      group.add(part);
    }
    const afe = COMPONENTS.find(c => c.id === 'afe'), pin = new THREE.BoxGeometry(0.04, 0.02, 0.07);
    group.add(mesh(`${group.name}__AFE_Pins`, merge(Array.from({ length: 10 }, (_, i) => placed(pin, afe.x - afe.w / 2 + 0.08 + i * 0.105, top + 0.01, afe.z + afe.d / 2 + 0.03))), GOLD()));
    const segs = [[-0.6, -0.4, -0.2, -0.6], [-0.6, 0, -0.35, 0.35], [0.45, 0.35, 0.85, 0.4], [0.35, -0.6, 0.85, -0.55], [1.45, 0.4, 1.95, 0.4]];
    const tr = Math.min(0.008, P.traceRadius);
    const antenna = serpentine(1.1, 4, 0.08, 0, 40).points.map(([x, z]) => [1.25 + z, top + tr, 0.9 + x * 0.6]);
    group.add(mesh(`${group.name}__CopperTraces_Antenna`, merge([...segs.map(([x1, z1, x2, z2]) => tube([[x1, top + tr, z1], [x2, top + tr, z2]], tr)), tube(antenna, tr)]), TRACE_GOLD()));
  }
  if (spec.id === 'stretchable-interconnect') {
    const pts = serpentine(4.4, 7, 0.16, 0).points; // relaxed (0 % strain)
    group.add(mesh(`${group.name}__SerpentineTraces`, merge([-1.6, -0.95, -0.3, 0.35, 1.0, 1.65].map(z => tube(pts.map(([x, dz]) => [x, top + P.serpentineRadius, z + dz]), P.serpentineRadius))), GOLD()));
  }
  return group;
}

function buildModel(explode, label, mode) {
  const scene = new THREE.Scene();
  const model = new THREE.Group();
  const r = scaleReadout(mode);
  model.name = `FlexArrayMN_V2_1_${mode}_${label}`;
  model.scale.setScalar(UNIT_TO_M);
  model.userData = {
    model: D.MODEL_VERSION, configuration: label, visualization_scale: mode, scale_badge: SCALE_PROFILES[mode].badge,
    units: 'metres (root scale 0.01 maps 1 design unit = 10 mm)',
    up_axis: '+Y (away from skin); skin-facing surface at Y = 0; long axis = X',
    footprint_mm: [...r.footprintMm], candidate_electrode_pitch_mm: r.pitchMm,
    candidate_microneedle_length_um: r.candidateNeedleUm, rendered_microneedle_length_mm: r.renderedNeedleMm, visualization_exaggeration: r.needleExaggeration,
    layer_thickness: r.thickness.map(t => ({ layer: t.id, rendered_um: t.renderedUm, engineering_um: t.engineeringUm, basis: t.basis, exaggeration: t.exaggeration })),
    engineering_details: ENGINEERING_DETAILS,
    open_issues: [`Layers 3-6 (~${r.belowNeedleUm} um, assumed) lie below the layer-2 needle base; a ${r.candidateNeedleUm} um needle ends ~${-r.needleReachUm} um short of skin.`,
      `Assumed component packages up to ${r.maxComponentMm} mm exceed the ${r.engineeringStackMm} mm engineering laminate.`],
    scale_note: mode === 'presentation'
      ? `NOT TO SCALE: layer thickness and microneedles exaggerated (needles ${r.renderedNeedleMm} mm drawn = ${r.needleExaggeration}x the ${r.candidateNeedleUm} um candidate).`
      : 'Engineering scale: research-candidate dimensions where defined, other thicknesses are assumptions. Not a manufacturing specification.',
    electrode_grid: `${ROWS}x${COLS} candidate sites (not 64 independent channels)`,
    disclaimer: D.DISCLAIMER,
  };
  D.LAYERS.forEach((_, i) => { const layer = buildLayer(i, mode); layer.position.y = layerY(i, explode, mode); model.add(layer); });
  scene.add(model);
  return { scene, model };
}

function exportGlb(object, animations = []) {
  return new Promise((resolve, reject) => new GLTFExporter().parse(object, r => resolve(Buffer.from(r)), reject, { binary: true, onlyVisible: true, animations }));
}

fs.mkdirSync(outDir, { recursive: true });
const outputs = [];
for (const mode of ['presentation', 'engineering']) {
  for (const [label, explode] of [['assembled', 0], ['exploded', 1]]) {
    const { scene } = buildModel(explode, label, mode);
    const buf = await exportGlb(scene);
    const file = path.join(outDir, `flexarray-mn-v2.1-${mode}-${label}.glb`);
    fs.writeFileSync(file, buf); outputs.push([file, buf.length]);
  }
  // One file per scale with an "Explode" clip (assembled -> exploded, 2 s) for PowerPoint / Blender playback.
  const { scene, model } = buildModel(0, 'animated', mode);
  const tracks = model.children.map((layer, i) => new THREE.VectorKeyframeTrack(`${layer.name}.position`, [0, 2], [0, layerY(i, 0, mode), 0, 0, layerY(i, 1, mode), 0]));
  const buf = await exportGlb(scene, [new THREE.AnimationClip('Explode', 2, tracks)]);
  const file = path.join(outDir, `flexarray-mn-v2.1-${mode}-explode-animated.glb`);
  fs.writeFileSync(file, buf); outputs.push([file, buf.length]);
}
for (const [f, n] of outputs) console.log(`${path.relative(process.cwd(), f)}  ${(n / 1024).toFixed(1)} KB`);
