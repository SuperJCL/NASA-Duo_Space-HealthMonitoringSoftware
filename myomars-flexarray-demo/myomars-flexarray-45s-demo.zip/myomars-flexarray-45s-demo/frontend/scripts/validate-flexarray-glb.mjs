// Re-import the exported FlexArray-MN GLBs with three.js GLTFLoader and check structure, materials, scale and layout.
//   node scripts/validate-flexarray-glb.mjs [dir]   (default: ../assets/3d)
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

const dir = path.resolve(process.argv[2] ?? path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'assets', '3d'));
const LAYERS = ['L1_Protective_film', 'L2_Microneedle_array', 'L3_Sweat_management', 'L4_Flexible_electronics', 'L5_Stretchable_interconnect', 'L6_Adhesive_frame'];
const load = file => { const b = fs.readFileSync(file); return new Promise((res, rej) => new GLTFLoader().parse(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength), '', res, rej)); };
const hex = c => '#' + c.getHexString();
const results = {};

const EXPECT = { presentation: { needleMm: 3.6, exaggeration: 18, filmUm: 500 }, engineering: { needleMm: 0.2, exaggeration: 1, filmUm: 30 } };
for (const scale of ['presentation', 'engineering']) for (const config of ['assembled', 'exploded', 'explode-animated']) {
  const cfg = config, key = `${scale}-${config}`;
  const file = path.join(dir, `flexarray-mn-v2.1-${key}.glb`);
  const gltf = await load(file);
  const root = gltf.scene.children[0];
  assert.match(root.name, /^FlexArrayMN_V2_1_/, 'root node name');
  assert.ok(Math.abs(root.scale.x - 0.01) < 1e-9, 'root scale maps design units to metres');
  assert.equal(root.userData.disclaimer, 'Conceptual engineering design — not manufactured, clinically validated, or flight-qualified.');
  const x = root.userData, e = EXPECT[scale];
  assert.equal(x.visualization_scale, scale);
  assert.deepEqual(x.footprint_mm, [64, 48]); assert.equal(x.candidate_electrode_pitch_mm, 5); assert.equal(x.candidate_microneedle_length_um, 200);
  assert.equal(x.rendered_microneedle_length_mm, e.needleMm); assert.equal(x.visualization_exaggeration, e.exaggeration);
  if (scale === 'presentation') assert.match(x.scale_note, /NOT TO SCALE/); else assert.match(x.scale_note, /Not a manufacturing specification/);
  assert.ok(x.layer_thickness.every(t => ['candidate', 'assumption', 'design'].includes(t.basis)));
  // six independent, named, top-level layer nodes in order
  assert.deepEqual(root.children.map(c => c.name), LAYERS);
  root.children.forEach((l, i) => { assert.equal(l.userData.layer_index, i + 1); assert.ok(l.children.length >= (i === 5 ? 1 : 2), l.name + ' has substrate (+ detail meshes)'); assert.match(l.children[0].name, /__Substrate$/); });
  // materials & colours survive the round trip
  const materials = new Map();
  gltf.scene.traverse(o => { if (o.isMesh) materials.set(o.material.name, o.material); });
  assert.equal(hex(materials.get('Gold_Contact').color), '#d9b45a');
  assert.ok(materials.get('Gold_Contact').metalness > 0.8);
  assert.ok(materials.get('L1_Substrate').transparent && materials.get('L1_Substrate').opacity < 0.5);
  assert.ok(materials.get('L3_Channel').emissive.getHex() > 0, 'channel glow kept as emissive');
  // scale: footprint 64 x 48 mm
  gltf.scene.updateMatrixWorld(true);
  const sizeOf = o => new THREE.Box3().setFromObject(o).getSize(new THREE.Vector3());
  const needleMesh = root.children[1].children.find(c => c.name.endsWith('__Microneedles'));
  // 8 x 8 cones stacked at one height: box height = needle length
  assert.ok(Math.abs(sizeOf(needleMesh).y * 1000 - e.needleMm) < 1e-3, `${key}: needle ${sizeOf(needleMesh).y * 1000} mm`);
  assert.ok(Math.abs(sizeOf(root.children[0].children[0]).y * 1e6 - e.filmUm) < 0.5, `${key}: film thickness`);
  const sub = new THREE.Box3().setFromObject(root.children[5].children[0]);
  const size = sub.getSize(new THREE.Vector3());
  assert.ok(Math.abs(size.x - 0.064) < 1e-4 && Math.abs(size.z - 0.048) < 1e-4, 'footprint 64 x 48 mm, got ' + size.toArray());
  // layout: skin-facing layer at Y=0; assembled layers touch, exploded layers separate
  const ys = root.children.map(l => l.position.y * 0.01);
  assert.equal(ys[5], 0);
  const gaps = ys.slice(0, 5).map((y, i) => y - ys[i + 1]);
  if (cfg === 'exploded') assert.ok(gaps.every(g => g > 0.01), 'exploded gaps > 10 mm');
  else assert.ok(gaps.every(g => g > 0 && g < 0.001), 'assembled layers stacked < 1 mm apart');
  if (cfg === 'explode-animated') { assert.equal(gltf.animations.length, 1); assert.equal(gltf.animations[0].name, 'Explode'); assert.equal(gltf.animations[0].tracks.length, 6); }
  let meshes = 0, tris = 0; gltf.scene.traverse(o => { if (o.isMesh) { meshes++; tris += (o.geometry.index ? o.geometry.index.count : o.geometry.attributes.position.count) / 3; } });
  const bbox = new THREE.Box3().setFromObject(gltf.scene).getSize(new THREE.Vector3());
  results[key] = { bytes: fs.statSync(file).size, meshes, triangles: tris, materials: materials.size, bbox_mm: bbox.toArray().map(v => +(v * 1000).toFixed(1)), animations: gltf.animations.map(a => a.name) };
}
console.log(JSON.stringify(results, null, 2));
console.log('three.js re-import: all checks passed');
