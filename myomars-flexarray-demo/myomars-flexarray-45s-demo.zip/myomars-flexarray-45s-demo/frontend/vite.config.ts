import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
export default defineConfig({plugins:[react(),{
 name:'astra-offline-assets',
 writeBundle(options,bundle){
  const assets=Object.keys(bundle).filter(name=>/\.(js|css)$/.test(name)).map(name=>'/'+name);
  const directory=resolve(options.dir??'dist');
  writeFileSync(resolve(directory,'offline-assets.json'),JSON.stringify(assets));
  const version=createHash('sha256').update(assets.join('|')).digest('hex').slice(0,12);
  const worker=readFileSync(resolve('public/sw.js'),'utf8').replace(/const CACHE='[^']+'/,`const CACHE='astra-${version}'`);
  writeFileSync(resolve(directory,'sw.js'),worker);
 }
}],server:{proxy:{'/api':'http://127.0.0.1:8000'}},build:{rollupOptions:{output:{manualChunks:{three:['three'],charts:['recharts']}}}}});
