export type Side='left'|'right';
export type MuscleSample={second:number;rms:number|null;medianHz:number|null;accel:number|null;gyro:number|null;quality:number;contact:boolean;artifact:boolean};
export const muscleBaseline=(crew:string,side:Side)=>({rms:crew==='a02'?85:75,medianHz:crew==='a02'?92:100,accel:side==='left'?.4:.42,gyro:30});
export function muscleSample(crew:string,side:Side,second:number,scenario:string):MuscleSample{
 const b=muscleBaseline(crew,side),fatigue=scenario==='fatigue'?Math.min(second/30,1):0;
 return {second,rms:scenario==='missing'?null:b.rms*(1+fatigue*.35)+Math.sin(second)*4,medianHz:scenario==='missing'?null:b.medianHz*(1-fatigue*.25),accel:scenario==='missing'?null:b.accel+Math.sin(second/2)*.1,gyro:scenario==='missing'?null:30+Math.sin(second)*8,quality:scenario==='missing'?0:scenario==='artifact'?35:scenario==='contact'?45:95,contact:scenario!=='contact'&&scenario!=='missing',artifact:scenario==='artifact'};
}
export function muscleSummary(samples:MuscleSample[],baseline:ReturnType<typeof muscleBaseline>){
 if(samples.length<5)return {status:'Not Assessed',drop:null,activity:null};
 if(samples.some(s=>!s.contact||s.artifact||s.quality<80||[s.rms,s.medianHz,s.accel,s.gyro].some(v=>v===null||!Number.isFinite(v))))return {status:'Uninterpretable — check signal',drop:null,activity:null};
 const recent=samples.slice(-5),hz=recent.reduce((n,s)=>n+s.medianHz!,0)/recent.length;
 const drop=(baseline.medianHz-hz)/baseline.medianHz*100;
 return {status:drop>=15?'Fatigue-related trend — human review':'No demo trend flag',drop,activity:recent.reduce((n,s)=>n+s.rms!,0)/recent.length};
}
