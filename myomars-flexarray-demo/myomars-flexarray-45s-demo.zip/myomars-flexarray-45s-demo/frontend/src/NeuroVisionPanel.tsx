import {useEffect,useRef,useState} from 'react';
import {LineChart,Line,XAxis,YAxis,CartesianGrid,Tooltip,ResponsiveContainer,ReferenceLine} from 'recharts';
import {cognitiveBaselines,sectors,summarize,latest,type Kind,type Screening,type ScreeningEvent} from './neurovision';
import type {Crew} from './rules';
type Props={crew:Crew;mission:string;history:Screening[];onEvent:(event:ScreeningEvent)=>boolean;storageError:string;pending:number;onSync:()=>void};
export function NeuroVision({crew,mission,history,onEvent,storageError,pending,onSync}:Props){
 const [phase,setPhase]=useState<'idle'|'wait'|'stimulus'>('idle'),[kind,setKind]=useState<Kind>('reaction'),[session,setSession]=useState<Screening|null>(null),[message,setMessage]=useState('');
 const active=useRef<Screening|null>(null),timer=useRef<number>(),stimulus=useRef(0),shownAt=useRef(''),errors=useRef(0),phaseRef=useRef(phase),emitRef=useRef(onEvent);
 emitRef.current=onEvent;
 const phaseTo=(p:typeof phase)=>{phaseRef.current=p;setPhase(p)};
 const record=(s:Screening,event:ScreeningEvent['event'])=>emitRef.current({event_id:crypto.randomUUID(),event,screening:s});
 const finish=(s:Screening,interrupted=false)=>{
 clearTimeout(timer.current);const done={...s,completed_at:new Date().toISOString(),interrupted,unassigned_errors:interrupted?Math.min(100,errors.current):0};active.current=null;setSession(done);phaseTo('idle');record(done,interrupted?'interrupted':'completed');setMessage(interrupted?'Test interrupted. Completion quality is not normal; repeat the full test.':'Screening saved locally. Review quality and baseline comparison below.');
 };
 const next=(s:Screening)=>{
 active.current=s;setSession(s);errors.current=0;phaseTo('wait');
 timer.current=window.setTimeout(()=>{shownAt.current=new Date().toISOString();stimulus.current=performance.now();phaseTo('stimulus');timer.current=window.setTimeout(()=>respond(true),1500)},700+Math.random()*1000);
 };
 const respond=(miss=false)=>{
 const s=active.current;if(!s)return;
 if(phaseRef.current==='wait'){errors.current++;setMessage('Early response recorded. Wait for the stimulus.');return}
 if(phaseRef.current!=='stimulus')return;
 const ms=Math.round(performance.now()-stimulus.current);
 if(!miss&&ms<100){errors.current++;setMessage('Response under 100 ms: recorded as an error. Wait and respond again.');return}
 clearTimeout(timer.current);
 const trial={stimulus_at:shownAt.current,response_ms:miss||ms>1500?null:ms,false_starts:Math.min(100,errors.current),sector:s.kind==='visual'?sectors[s.trials.length]:null};
 const updated={...s,trials:[...s.trials,trial]};
 if(updated.trials.length===(s.kind==='reaction'?3:8))finish(updated);else next(updated);
 };
 const start=(k:Kind)=>{
 const s:Screening={session_id:crypto.randomUUID(),astronaut_id:crew,mission_id:mission,kind:k,started_at:new Date().toISOString(),completed_at:null,interrupted:false,trials:[]};
 if(!record(s,'started')){setMessage('Cannot start: local storage is unavailable.');return}
 setKind(k);setMessage('');next(s);
 };
 useEffect(()=>{
 const interrupt=()=>{if(active.current&&document.hidden)finish(active.current,true)};
 const key=(e:KeyboardEvent)=>{if(e.code==='Space'&&active.current){e.preventDefault();if(!e.repeat)respond()}};
 document.addEventListener('visibilitychange',interrupt);window.addEventListener('keydown',key);
 return()=>{document.removeEventListener('visibilitychange',interrupt);window.removeEventListener('keydown',key);clearTimeout(timer.current);if(active.current){const s=active.current;active.current=null;record({...s,completed_at:new Date().toISOString(),interrupted:true,unassigned_errors:Math.min(100,errors.current)},'interrupted')}};
 },[]);
 const position=[{left:'18%',top:'18%'},{left:'50%',top:'12%'},{left:'82%',top:'18%'},{left:'88%',top:'50%'},{left:'82%',top:'82%'},{left:'50%',top:'88%'},{left:'18%',top:'82%'},{left:'12%',top:'50%'}][session?.trials.length??0];
 const chart=history.filter(s=>s.astronaut_id===crew&&s.completed_at).sort((a,b)=>Date.parse(a.completed_at!)-Date.parse(b.completed_at!)).map(s=>{const v=summarize(s,Date.parse(s.completed_at!));return {stamp:new Date(s.completed_at!).toLocaleString(),kind:s.kind,quality:v.quality,reaction:s.kind==='reaction'?v.median_ms:null,visual:s.kind==='visual'?v.median_ms:null,error:v.error_rate===null?null:Math.round(v.error_rate*100),miss:v.miss_rate===null?null:Math.round(v.miss_rate*100)}});
 return <section className="neurovision"><div className="section-head"><div><span className="eyebrow">03 / NEUROVISION AI</span><h2>Cognitive & visual screening</h2></div><span className="tag">NON-DIAGNOSTIC SIMULATION</span></div>
 <p>No AI makes safety decisions. This screen does not diagnose SANS or neurological disease. Baselines and readiness limits are fictional.</p>
 <p>Reaction: 3 stimuli. Visual simulation: 8 screen locations while you look at the center cross. Click the signal or press Space when it appears; each signal expires after 1.5 seconds. This is not clinical perimetry; gaze and viewing conditions are not measured.</p>
 <div className="controls"><button disabled={phase!=='idle'} onClick={()=>start('reaction')}>Start reaction assessment</button><button disabled={phase!=='idle'} onClick={()=>start('visual')}>Start visual simulation</button>{phase!=='idle'&&<button onClick={()=>finish(active.current!,true)}>Cancel screening</button>}</div>
 {phase!=='idle'&&<><p role="status">{kind==='reaction'?'Reaction':'Visual'} · Trial {(session?.trials.length??0)+1} / {kind==='reaction'?3:8} · {phase==='wait'?'Wait for the signal':'Respond now'}</p><div className={'stimulus-field '+kind} onClick={()=>{if(phaseRef.current==='wait')respond()}}><span className="fixation" aria-hidden="true">+</span>{phase==='stimulus'&&<button aria-label="Respond to stimulus" className="stimulus" style={kind==='visual'?position:{left:'50%',top:'50%'}} onClick={e=>{e.stopPropagation();respond()}}>●</button>}</div></>}
 {message&&<p role="status">{message}</p>}{storageError&&<div role="alert" className="alert critical">{storageError} Readiness is on hold.</div>}
 <div className="grid two">{(['reaction','visual'] as Kind[]).map(k=>{const s=latest(history,crew,mission,k),v=s?summarize(s):null;return <article className="neuro-summary" key={k}><h3>{k==='reaction'?'Reaction assessment':'Visual simulation'}</h3><p>Quality: <strong>{v?.quality??'missing'}</strong> · {v?.status??'hold'}</p><dl><dt>Median / fictional baseline</dt><dd>{v?.median_ms??'Not Assessed'} / {cognitiveBaselines[crew][k==='reaction'?'reaction_ms':'visual_ms']} ms</dd><dt>Missed stimuli / false starts</dt><dd>{v?.missed_stimuli??'Not Assessed'} / {v?.false_starts??'Not Assessed'}</dd><dt>Error rate (misses + early responses)</dt><dd>{v?.error_rate==null?'Not Assessed':(v.error_rate*100).toFixed(1)+'%'}</dd><dt>Trials / expected</dt><dd>{v?.recorded_trials??0} / {k==='reaction'?3:8}</dd><dt>Completed at</dt><dd>{s?.completed_at?new Date(s.completed_at).toLocaleString():'Not completed'}</dd></dl></article>})}</div>
 <h3>Longitudinal performance · {crew.toUpperCase()}</h3><p>Only recorded local attempts are plotted, across missions. Gaps indicate an unavailable metric, not a normal result. Quality and exact timestamps are available in the table.</p>
 {chart.length?<><div className="neuro-chart" aria-label="Longitudinal cognitive response time chart"><ResponsiveContainer width="100%" height="100%"><LineChart data={chart}><CartesianGrid stroke="#e1e7df"/><XAxis dataKey="stamp" hide/><YAxis unit=" ms"/><Tooltip/><ReferenceLine y={cognitiveBaselines[crew].reaction_ms} stroke="#227e6b" strokeDasharray="4 4"/><ReferenceLine y={cognitiveBaselines[crew].visual_ms} stroke="#c18a52" strokeDasharray="4 4"/><Line dataKey="reaction" name="Reaction ms" stroke="#227e6b" connectNulls={false} isAnimationActive={false}/><Line dataKey="visual" name="Visual ms" stroke="#c18a52" connectNulls={false} isAnimationActive={false}/></LineChart></ResponsiveContainer></div><p className="hint">Green: reaction · amber: visual · dashed: fictional personal baselines</p><div className="neuro-chart" aria-label="Miss and error rate chart"><ResponsiveContainer width="100%" height="100%"><LineChart data={chart}><CartesianGrid stroke="#e1e7df"/><XAxis dataKey="stamp" hide/><YAxis unit="%" domain={[0,100]}/><Tooltip/><Line dataKey="error" name="Error %" stroke="#b34838" connectNulls={false} isAnimationActive={false}/><Line dataKey="miss" name="Miss %" stroke="#227e6b" connectNulls={false} isAnimationActive={false}/></LineChart></ResponsiveContainer></div><div className="neuro-table"><table><thead><tr><th>Timestamp</th><th>Test</th><th>Quality</th><th>Median ms</th><th>Miss %</th><th>Error %</th></tr></thead><tbody>{chart.map((r,i)=><tr key={i}><td>{r.stamp}</td><td>{r.kind}</td><td>{r.quality}</td><td>{r.reaction??r.visual??'Not Assessed'}</td><td>{r.miss??'Not Assessed'}</td><td>{r.error??'Not Assessed'}</td></tr>)}</tbody></table></div></>:<p>No completed attempts yet. No synthetic history is presented as observed performance.</p>}
 <div className="controls"><span>{pending} assessment events pending SQLite sync</span><button onClick={onSync}>Sync local assessment events</button></div>
 </section>;
}
