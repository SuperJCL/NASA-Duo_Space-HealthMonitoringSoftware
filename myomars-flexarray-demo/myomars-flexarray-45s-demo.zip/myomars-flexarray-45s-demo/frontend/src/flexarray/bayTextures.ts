// Original canvas-drawn textures for the EVA bay backdrop (no external images).
import { mulberry32, ridge } from './bayLayout';

type Ctx = CanvasRenderingContext2D;
export function makeCanvas(w: number, h: number) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  return { canvas: c, ctx: c.getContext('2d')! };
}

/** Stylised Martian landscape seen from the bay window: dusty butterscotch sky, layered ridges, craters, rocks. */
export function drawMarsLandscape(ctx: Ctx, w: number, h: number, seed = 7) {
  const rand = mulberry32(seed);
  const sky = ctx.createLinearGradient(0, 0, 0, h * 0.62);
  sky.addColorStop(0, '#2a1a22'); sky.addColorStop(0.35, '#6e3b33'); sky.addColorStop(0.75, '#c27a55'); sky.addColorStop(1, '#e9b88e');
  ctx.fillStyle = sky; ctx.fillRect(0, 0, w, h);
  // small distant sun with the bluish halo seen in Martian sunsets
  const sx = w * 0.7, sy = h * 0.36, sr = h * 0.018;
  const halo = ctx.createRadialGradient(sx, sy, 0, sx, sy, sr * 9);
  halo.addColorStop(0, 'rgba(214,236,250,0.85)'); halo.addColorStop(0.18, 'rgba(160,200,225,0.35)'); halo.addColorStop(1, 'rgba(160,200,225,0)');
  ctx.fillStyle = halo; ctx.beginPath(); ctx.arc(sx, sy, sr * 9, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#f4fbff'; ctx.beginPath(); ctx.arc(sx, sy, sr, 0, Math.PI * 2); ctx.fill();
  // two tiny moons
  ctx.fillStyle = 'rgba(255,236,220,0.55)'; ctx.beginPath(); ctx.arc(w * 0.22, h * 0.14, h * 0.006, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(w * 0.31, h * 0.09, h * 0.004, 0, Math.PI * 2); ctx.fill();

  const layers = [
    { base: 0.5, amp: 0.12, color: '#c99072', rough: 0.55, haze: 0.55 },
    { base: 0.57, amp: 0.1, color: '#a8613f', rough: 0.6, haze: 0.3 },
    { base: 0.66, amp: 0.08, color: '#7d3c26', rough: 0.62, haze: 0.12 },
    { base: 0.78, amp: 0.07, color: '#4f2318', rough: 0.68, haze: 0 },
  ];
  layers.forEach((L, li) => {
    const r = ridge(rand, 8, L.rough), n = r.length - 1;
    ctx.beginPath(); ctx.moveTo(0, h);
    r.forEach((v, i) => ctx.lineTo((i / n) * w, h * (L.base - v * L.amp)));
    ctx.lineTo(w, h); ctx.closePath();
    const g = ctx.createLinearGradient(0, h * (L.base - L.amp), 0, h);
    g.addColorStop(0, L.color); g.addColorStop(1, shade(L.color, -0.35));
    ctx.fillStyle = g; ctx.fill();
    if (L.haze) { ctx.fillStyle = `rgba(233,184,142,${L.haze * 0.35})`; ctx.fill(); }
    if (li === 2) for (let k = 0; k < 6; k++) { // shallow craters on the mid plain
      const cx = rand() * w, cy = h * (0.7 + rand() * 0.06), rx = w * (0.02 + rand() * 0.04);
      ctx.fillStyle = 'rgba(40,16,10,0.35)'; ctx.beginPath(); ctx.ellipse(cx, cy, rx, rx * 0.16, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(214,150,110,0.35)'; ctx.lineWidth = Math.max(1, w / 900); ctx.beginPath(); ctx.ellipse(cx, cy - rx * 0.03, rx, rx * 0.16, 0, Math.PI, Math.PI * 2); ctx.stroke();
    }
  });
  for (let k = 0; k < 90; k++) { // foreground rocks
    const x = rand() * w, y = h * (0.82 + rand() * 0.18), s = w * (0.002 + rand() * 0.008);
    ctx.fillStyle = `rgba(${30 + rand() * 30},${12 + rand() * 12},${8 + rand() * 8},0.9)`;
    ctx.beginPath(); ctx.ellipse(x, y, s, s * 0.6, 0, 0, Math.PI * 2); ctx.fill();
  }
  const dust = ctx.createLinearGradient(0, h * 0.4, 0, h * 0.7);
  dust.addColorStop(0, 'rgba(240,190,150,0)'); dust.addColorStop(0.5, 'rgba(240,190,150,0.16)'); dust.addColorStop(1, 'rgba(240,190,150,0)');
  ctx.fillStyle = dust; ctx.fillRect(0, 0, w, h);
}

function shade(hex: string, k: number) {
  const n = parseInt(hex.slice(1), 16), f = (c: number) => Math.max(0, Math.min(255, Math.round(c * (1 + k))));
  return `rgb(${f(n >> 16)},${f((n >> 8) & 255)},${f(n & 255)})`;
}

/** Wall display. Content is explicitly labelled as a simulated / concept display — never crew data. */
export function drawMonitor(ctx: Ctx, w: number, h: number, variant: 'wave' | 'patch' | 'airlock') {
  ctx.fillStyle = '#03111b'; ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = 'rgba(76,228,245,0.08)'; ctx.lineWidth = 1;
  for (let x = 0; x < w; x += w / 16) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke(); }
  for (let y = 0; y < h; y += h / 10) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke(); }
  ctx.fillStyle = '#4CE4F5'; ctx.font = `600 ${Math.round(h * 0.07)}px sans-serif`;
  const title = variant === 'wave' ? 'PRE-EVA BAY 02 · SIMULATED DISPLAY' : variant === 'patch' ? 'FLEXARRAY-MN · CONCEPT VIEW' : 'EVA AIRLOCK 02';
  ctx.fillText(title, w * 0.05, h * 0.13);
  if (variant === 'wave') {
    for (let row = 0; row < 3; row++) {
      ctx.strokeStyle = ['#4CE4F5', '#9ff3fb', '#D9B45A'][row]; ctx.lineWidth = Math.max(1.5, h / 160); ctx.beginPath();
      const y0 = h * (0.34 + row * 0.2);
      for (let x = 0; x <= w * 0.9; x += 2) {
        const t = x / w; const v = Math.sin(t * 70 + row) * 0.4 + Math.sin(t * 190 + row * 2) * 0.25 + Math.sin(t * 13) * 0.2;
        x === 0 ? ctx.moveTo(w * 0.05 + x, y0 + v * h * 0.06) : ctx.lineTo(w * 0.05 + x, y0 + v * h * 0.06);
      }
      ctx.stroke();
    }
    ctx.fillStyle = 'rgba(255,207,134,0.9)'; ctx.font = `500 ${Math.round(h * 0.05)}px sans-serif`;
    ctx.fillText('DEMO WAVEFORM — NOT CREW DATA', w * 0.05, h * 0.93);
  } else if (variant === 'patch') {
    const pw = w * 0.42, ph = pw * 0.75, px = w * 0.08, py = h * 0.24;
    ctx.strokeStyle = '#4CE4F5'; ctx.lineWidth = 2; roundRect(ctx, px, py, pw, ph, ph * 0.14); ctx.stroke();
    ctx.fillStyle = '#D9B45A';
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) { ctx.beginPath(); ctx.arc(px + pw * (0.16 + c * 0.097), py + ph * (0.14 + r * 0.103), ph * 0.022, 0, Math.PI * 2); ctx.fill(); }
    ctx.fillStyle = '#cfe9f5'; ctx.font = `500 ${Math.round(h * 0.055)}px sans-serif`;
    ['6 LAYERS · 8×8 CANDIDATE SITES', '64 × 48 mm FOOTPRINT', 'NOT MANUFACTURED', 'NOT FLIGHT-QUALIFIED'].forEach((t, i) => ctx.fillText(t, w * 0.56, h * (0.33 + i * 0.13)));
  } else {
    ctx.fillStyle = '#ffcf86'; ctx.font = `600 ${Math.round(h * 0.12)}px sans-serif`; ctx.fillText('PRESSURISED · STANDBY', w * 0.05, h * 0.5);
    ctx.fillStyle = '#cfe9f5'; ctx.font = `500 ${Math.round(h * 0.06)}px sans-serif`; ctx.fillText('SIMULATED STATUS PANEL', w * 0.05, h * 0.75);
  }
}

/** Hazard stripes (used on airlock frame and floor edge). */
export function drawHazard(ctx: Ctx, w: number, h: number) {
  ctx.fillStyle = '#1a1d22'; ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = '#c9902f';
  for (let x = -h; x < w + h; x += h * 1.2) { ctx.beginPath(); ctx.moveTo(x, h); ctx.lineTo(x + h * 0.6, h); ctx.lineTo(x + h * 1.2, 0); ctx.lineTo(x + h * 0.6, 0); ctx.closePath(); ctx.fill(); }
}

/** Floor plates. */
export function drawFloor(ctx: Ctx, w: number, h: number) {
  ctx.fillStyle = '#12171d'; ctx.fillRect(0, 0, w, h);
  const n = 8, s = w / n;
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
    const g = ctx.createLinearGradient(i * s, j * s, (i + 1) * s, (j + 1) * s);
    g.addColorStop(0, '#192028'); g.addColorStop(1, '#12171d');
    ctx.fillStyle = g; ctx.fillRect(i * s + 2, j * s + 2, s - 4, s - 4);
    ctx.fillStyle = 'rgba(160,190,210,0.12)';
    for (const [dx, dy] of [[10, 10], [s - 10, 10], [10, s - 10], [s - 10, s - 10]]) { ctx.beginPath(); ctx.arc(i * s + dx, j * s + dy, 2.2, 0, Math.PI * 2); ctx.fill(); }
  }
}

function roundRect(ctx: Ctx, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}
