// Layout specification for the Mars EVA preparation bay backdrop (original, procedural).
// Pure data so it can be unit-tested; FlexArrayEnvironment.tsx renders it.
// The bay is a BACKDROP: it is not to scale with the patch, which is shown as a magnified holographic display.

import { CAMERA_DEFAULT } from './flexArrayGeometry';

export type Vec3 = [number, number, number];
export type BayQuality = 'full' | 'lite';
export type Backdrop = 'bay' | 'minimal';

const R = { x0: -44, x1: 44, z0: -38, z1: 44 };
export const BAY = {
  /** Room bounds in the bay's local frame (local −z = back wall, facing the default camera). */
  room: R,
  floorY: -16,
  ceilingY: 36,
  /** Rotate the whole bay so its back wall squarely faces the default camera azimuth. */
  yaw: Math.atan2(CAMERA_DEFAULT.position[0], CAMERA_DEFAULT.position[2]),
  maxCameraDistance: 32,
  /** Orbit tilt limit in bay mode, so the camera never drops below the floor. */
  maxPolarAngle: 1.92,
  cameraTarget: [0, 2.7, 0] as Vec3,
  pedestal: { radius: 6, height: 1.0, top: -4.8 },
  /** Nothing in the bay may enter this cylinder around the hologram (radius, from pedestal top up). */
  keepOut: { radius: 9 },
  /** Back-wall panorama, left → right: suit lockers · Mars window · medical station. */
  window: { wallZ: R.z0, x0: -14, x1: 18, y0: -14, y1: 8 },
  suitScale: 0.62,
  suits: [-40, -31, -22].map(x => [x, -16, R.z0 + 3.4] as Vec3),
  medical: {
    bed: [33, -16, R.z0 + 8] as Vec3,
    monitors: [[27, 1, R.z0 + 0.7], [38.5, 1, R.z0 + 0.7]] as Vec3[],
    cabinet: [41.5, -16, R.z0 + 4] as Vec3,
    ivPole: [24, -16, R.z0 + 10] as Vec3,
  },
  airlock: { wallZ: R.z1, x: 0, y: -4, radius: 9 },
  racks: [-24, -10, 4, 18, 32].map(z => [R.x1 - 3, -16, z] as Vec3),
  lamps: [[-30, 35.6, -26], [4, 35.6, -26], [30, 35.6, -20], [0, 35.6, 22]] as Vec3[],
};

/** Every placed prop (bay-local coordinates) with its approximate footprint radius (for keep-out tests). */
export function bayProps(quality: BayQuality = 'full') {
  const suits = quality === 'lite' ? BAY.suits.slice(0, 2) : BAY.suits;
  return [
    ...suits.map(p => ({ kind: 'suit', p, r: 5 * BAY.suitScale })),
    { kind: 'bed', p: BAY.medical.bed, r: 8 },
    { kind: 'cabinet', p: BAY.medical.cabinet, r: 3 },
    { kind: 'iv', p: BAY.medical.ivPole, r: 1.5 },
    ...BAY.medical.monitors.map(p => ({ kind: 'monitor', p, r: 4.5 })),
    ...BAY.racks.map(p => ({ kind: 'rack', p, r: 3 })),
  ];
}

/** Lite mode on small screens / few CPU cores: fewer suits and particles, no light shafts, smaller textures. */
export function bayQuality(width: number, cores: number | undefined): BayQuality {
  return width < 720 || (cores !== undefined && cores <= 4) ? 'lite' : 'full';
}

export const BAY_SETTINGS: Record<BayQuality, { dust: number; shafts: boolean; marsTexture: number }> = {
  full: { dust: 260, shafts: true, marsTexture: 2048 },
  lite: { dust: 90, shafts: false, marsTexture: 1024 },
};

/** Deterministic PRNG so the generated landscape is identical on every load. */
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Midpoint-displacement ridge line, values in [0, 1], length 2^levels + 1. */
export function ridge(rand: () => number, levels: number, roughness: number) {
  const n = 2 ** levels;
  const h = new Array<number>(n + 1).fill(0);
  h[0] = rand(); h[n] = rand();
  let step = n, amp = 0.5;
  while (step > 1) {
    const half = step / 2;
    for (let i = half; i < n; i += step) h[i] = (h[i - half] + h[i + half]) / 2 + (rand() - 0.5) * amp;
    step = half; amp *= roughness;
  }
  const lo = Math.min(...h), hi = Math.max(...h);
  return h.map(v => (v - lo) / (hi - lo || 1));
}
