import { channelEstimate, type Referencing } from './flexArrayData';
import { COLORS } from './flexArrayGeometry';

type Props = {
  rows: number; cols: number; referencing: Referencing; afe: number;
  onGrid: (n: number) => void; onReferencing: (r: Referencing) => void; onAfe: (n: number) => void;
};

/** Top-view electrode matrix: shows sites, derivations, and which derivations a given AFE could digitize. */
export function ElectrodeMatrix({ rows, cols, referencing, afe, onGrid, onReferencing, onAfe }: Props) {
  const est = channelEstimate(rows, cols, referencing, afe);
  const pitch = 30, pad = 26, w = pad * 2 + (cols - 1) * pitch, h = pad * 2 + (rows - 1) * pitch;
  let k = 0;
  return <div className="fa-card" role="region" aria-labelledby="fa-matrix-title">
    <div className="fa-card-head"><h3 id="fa-matrix-title">Top-view electrode matrix</h3><span className="fa-tag fa-tag-b">Proposed target</span></div>
    <div className="fa-matrix">
      <svg viewBox={`0 0 ${w} ${h}`} role="img" aria-label={est.note} className="fa-matrix-svg">
        <rect x={4} y={4} width={w - 8} height={h - 8} rx={12} fill="#0b1a2b" stroke="#244a63" />
        {referencing === 'single-differential' && Array.from({ length: rows }, (_, r) => Array.from({ length: cols - 1 }, (_, c) => {
          const on = k++ < est.digitized;
          return <line key={r + '-' + c} x1={pad + c * pitch} x2={pad + (c + 1) * pitch} y1={pad + r * pitch} y2={pad + r * pitch} stroke={on ? COLORS.cyan : '#2a4054'} strokeWidth={on ? 3 : 2} />;
        }))}
        {Array.from({ length: rows * cols }, (_, i) => {
          const r = Math.floor(i / cols), c = i % cols;
          const on = referencing === 'monopolar' ? i < est.digitized : true;
          return <circle key={i} cx={pad + c * pitch} cy={pad + r * pitch} r={8} fill={on ? COLORS.gold : '#4a4636'} stroke={on ? '#fff3c4' : '#6b6450'} strokeWidth={1} />;
        })}
      </svg>
      <div className="fa-matrix-controls">
        <label>Grid<select value={rows} onChange={e => onGrid(Number(e.target.value))}>{[4, 6, 8].map(n => <option key={n} value={n}>{n} × {n}</option>)}</select></label>
        <label>Referencing<select value={referencing} onChange={e => onReferencing(e.target.value as Referencing)}>
          <option value="monopolar">Monopolar</option><option value="single-differential">Single-differential (row)</option></select></label>
        <label>AFE channels (TBD)<select value={afe} onChange={e => onAfe(Number(e.target.value))}>{[8, 16, 32, 64].map(n => <option key={n} value={n}>{n}</option>)}</select></label>
        <dl className="fa-matrix-stats">
          <div><dt>Electrode sites</dt><dd data-testid="fa-sites">{est.sites}</dd></div>
          <div><dt>Derivations</dt><dd>{est.derivations}</dd></div>
          <div><dt>Max digitized</dt><dd data-testid="fa-digitized">≤ {est.digitized}</dd></div>
          <div><dt>Independent channels</dt><dd>Not established</dd></div>
        </dl>
      </div>
    </div>
    <p className="fa-small">{est.note}</p>
  </div>;
}
