import { Component, Suspense, lazy, useCallback, useEffect, useMemo, useRef, useState, type KeyboardEvent, type ReactNode } from 'react';
import {
  CATEGORY_LABELS, CATEGORY_NOTES, DISCLAIMER, LAYERS, MODEL_VERSION, REFERENCES, STATUS_LABELS, SYSTEM_PARAMETERS,
  layerById, parametersByCategory, referenceById, type Layer, type LayerId, type Parameter, type Referencing,
} from './flexArrayData';
import { BASIS_LABELS, ENGINEERING_DETAILS, SCALE_PROFILES, layerY, nominalTipLayer, scaleReadout, type ScaleMode } from './flexArrayGeometry';
import { FlexArray2D } from './FlexArray2D';
import { ElectrodeMatrix } from './ElectrodeMatrix';
import type { SceneApi, ViewMode } from './FlexArrayScene';
import { bayQuality, type Backdrop } from './bayLayout';
import { drawMarsLandscape, makeCanvas } from './bayTextures';
import { DemoPlayer } from './DemoPlayer';
import { DEMO_SHOTS, type Cue } from './demoScript';
import './flexarray.css';

const FlexArrayScene = lazy(() => import('./FlexArrayScene').then(m => ({ default: m.FlexArrayScene })));

export function hasWebGL() {
  try {
    if ((window as any).__ASTRA_FORCE_NO_WEBGL) return false;
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch { return false; }
}

class SceneBoundary extends Component<{ onError: () => void; children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch() { this.props.onError(); }
  render() { return this.state.failed ? null : this.props.children; }
}

const allVisible = (): Record<LayerId, boolean> => Object.fromEntries(LAYERS.map(l => [l.id, true])) as Record<LayerId, boolean>;
const VIEWS: { id: ViewMode; label: string }[] = [
  { id: 'stack', label: 'Layer stack' }, { id: 'top', label: 'Top view' }, { id: 'skin', label: 'Skin cross-section' }, { id: 'thigh', label: 'Thigh attachment' },
];
type SheetTab = 'references' | 'scale' | 'matrix' | 'system' | 'controls';
const SHEET_TABS: { id: SheetTab; label: string }[] = [
  { id: 'references', label: 'References' }, { id: 'scale', label: 'Scale & assumptions' }, { id: 'matrix', label: 'Electrode matrix' },
  { id: 'system', label: 'System settings' }, { id: 'controls', label: 'Controls' },
];
const pad2 = (n: number) => String(n).padStart(2, '0');

function useReducedMotion() {
  const [reduced, set] = useState(() => matchMedia('(prefers-reduced-motion: reduce)').matches);
  useEffect(() => { const m = matchMedia('(prefers-reduced-motion: reduce)'); const f = () => set(m.matches); m.addEventListener('change', f); return () => m.removeEventListener('change', f); }, []);
  return reduced;
}

/** Two proposed targets + two pending-validation items (falls back to whatever exists), so limits are never hidden. */
function keyParameters(layer: Layer) {
  const b = layer.parameters.filter(p => p.category === 'B'), c = layer.parameters.filter(p => p.category === 'C'), a = layer.parameters.filter(p => p.category === 'A');
  const picked = [...b.slice(0, 2), ...c.slice(0, 2)];
  for (const p of [...a, ...b, ...c]) if (picked.length < 4 && !picked.includes(p)) picked.push(p);
  return picked;
}

// Inline icons (stroke = currentColor)
const Icon = ({ d, label }: { d: string; label?: string }) => <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden={label ? undefined : true} role={label ? 'img' : undefined} aria-label={label}><path d={d} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>;
const I = {
  rotL: 'M4 12a8 8 0 1 0 2.4-5.7M4 4v4.5h4.5', rotR: 'M20 12a8 8 0 1 1-2.4-5.7M20 4v4.5h-4.5',
  zoomIn: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4M8 11h6M11 8v6', zoomOut: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4M8 11h6',
  reset: 'M12 3v3M12 18v3M3 12h3M18 12h3M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  full: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5', unfull: 'M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5',
  explode: 'M4 7l8-4 8 4-8 4zM4 12l8 4 8-4M4 17l8 4 8-4', close: 'M6 6l12 12M18 6L6 18', back: 'M15 5l-7 7 7 7',
};

export default function FlexArrayExplorer({ onExit }: { onExit?: () => void } = {}) {
  const reducedMotion = useReducedMotion();
  const [selected, setSelected] = useState<LayerId | null>(null);
  const [panelOpen, setPanelOpen] = useState(false);
  const [visible, setVisible] = useState(allVisible);
  const [exploded, setExploded] = useState(true);
  const [mode, setMode] = useState<ViewMode>('stack');
  const [scaleMode, setScaleMode] = useState<ScaleMode>('presentation');
  const [stretch, setStretch] = useState(0);
  const [animateStretch, setAnimateStretch] = useState(false);
  const [needleUm, setNeedleUm] = useState(200);
  const [grid, setGrid] = useState({ rows: 8, cols: 8 });
  const [referencing, setReferencing] = useState<Referencing>('single-differential');
  const [afe, setAfe] = useState(32);
  const [render2D, setRender2D] = useState<null | string>(() => (hasWebGL() ? null : 'WebGL is unavailable in this browser.'));
  const [sheet, setSheet] = useState<SheetTab | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [backdrop, setBackdrop] = useState<Backdrop>('bay');
  const [demoActive, setDemoActive] = useState(false);
  const demoSnapshot = useRef<null | { exploded: boolean; mode: ViewMode; scaleMode: ScaleMode; backdrop: Backdrop; selected: LayerId | null; visible: Record<LayerId, boolean> }>(null);
  const demoButton = useRef<HTMLButtonElement>(null);
  const [quality] = useState(() => bayQuality(window.innerWidth, navigator.hardwareConcurrency));
  const [announce, setAnnounce] = useState('');
  const [touched, setTouched] = useState(false);
  const scene = useRef<SceneApi | null>(null);
  const root = useRef<HTMLDivElement>(null);
  const progressEl = useRef<HTMLDivElement>(null);
  const sheetTrigger = useRef<HTMLElement | null>(null);
  const sheetRef = useRef<HTMLDivElement>(null);

  const select = useCallback((id: LayerId | null) => {
    setSelected(id);
    setPanelOpen(!!id);
    setAnnounce(id ? `Selected layer ${layerById(id).index}: ${layerById(id).name}` : 'Selection cleared');
    if (id) setVisible(v => (v[id] ? v : { ...v, [id]: true }));
  }, []);
  const onProgress = useCallback((v: number) => { progressEl.current?.setAttribute('data-explode-progress', String(v)); }, []);
  const onContextLost = useCallback(() => setRender2D('The 3D graphics context was lost.'), []);
  useEffect(() => { if (render2D) onProgress(exploded && mode === 'stack' ? 1 : 0); }, [render2D, exploded, mode, onProgress]);

  // full screen
  useEffect(() => {
    const f = () => setFullscreen(document.fullscreenElement === root.current);
    document.addEventListener('fullscreenchange', f); return () => document.removeEventListener('fullscreenchange', f);
  }, []);
  const canFullscreen = typeof document !== 'undefined' && !!document.documentElement.requestFullscreen;
  const toggleFullscreen = async () => {
    try { if (document.fullscreenElement) await document.exitFullscreen(); else await root.current?.requestFullscreen(); }
    catch { setAnnounce('Full screen is not available in this browser.'); }
  };

  // research sheet: focus in, Escape closes, focus returns to trigger
  const openSheet = (tab: SheetTab, trigger?: HTMLElement | null) => { sheetTrigger.current = trigger ?? (document.activeElement as HTMLElement); setSheet(tab); };
  const closeSheet = () => { const t = sheetTrigger.current; setSheet(null); t?.focus(); };
  useEffect(() => { if (sheet) sheetRef.current?.querySelector<HTMLElement>('.fa-sheet-title')?.focus(); }, [sheet !== null]); // eslint-disable-line react-hooks/exhaustive-deps

  const resetView = () => { setMode('stack'); scene.current?.resetCamera(); setAnnounce('View reset'); };
  const resetModel = () => {
    select(null); setVisible(allVisible()); setExploded(true); setMode('stack'); setScaleMode('presentation'); setStretch(0); setAnimateStretch(false);
    setNeedleUm(200); setGrid({ rows: 8, cols: 8 }); setReferencing('single-differential'); setAfe(32);
    scene.current?.resetCamera(); setAnnounce('Model reset');
  };
  function changeScale(m: ScaleMode) {
    setScaleMode(m);
    setAnnounce(m === 'engineering' ? 'Engineering scale: candidate and assumed dimensions, drawn to scale' : 'Presentation scale: thickness and microneedles exaggerated, not to scale');
  }
  const focusNeedles = () => {
    const x = ((grid.cols - 1) / 2) * 0.5, z = ((grid.rows - 1) / 2) * 0.5;
    const y = layerY(1, exploded && mode === 'stack' ? 1 : 0, scaleMode);
    if (mode !== 'stack') setMode('stack');
    const d = scaleMode === 'engineering' ? 0.3 : 1.6;
    scene.current?.focus([x + d * 0.9, y - d * 0.15, z + d * 1.1], [x, y - SCALE_PROFILES[scaleMode].needle.length / 2, z]);
    select('microneedle-array');
  };

  // ---------- guided demo ----------
  const startDemo = () => {
    demoSnapshot.current = { exploded, mode, scaleMode, backdrop, selected, visible };
    setSheet(null); setPanelOpen(false); setMode('stack'); setScaleMode('presentation'); setBackdrop('bay'); setVisible(allVisible());
    setDemoActive(true); setAnnounce('Guided demo started');
  };
  const exitDemo = useCallback(() => {
    const snap = demoSnapshot.current;
    if (snap) { setExploded(snap.exploded); setMode(snap.mode); setScaleMode(snap.scaleMode); setBackdrop(snap.backdrop); setSelected(snap.selected); setVisible(snap.visible); }
    setPanelOpen(false); setDemoActive(false); scene.current?.resetCamera(); setAnnounce('Guided demo closed');
    requestAnimationFrame(() => demoButton.current?.focus());
  }, []);
  const onDemoCue = useCallback((cue: Cue) => {
    if (cue.explode !== undefined) setExploded(cue.explode);
    if (cue.select !== undefined) { setSelected(cue.select); setPanelOpen(false); }
    if (cue.camera === 'patch') scene.current?.resetCamera();
    else if (cue.camera) scene.current?.focus(DEMO_SHOTS[cue.camera].position, DEMO_SHOTS[cue.camera].target);
  }, []);

  const viewportKeys = (e: KeyboardEvent<HTMLDivElement>) => {
    const k = e.key, s = scene.current;
    const handled = () => { e.preventDefault(); e.stopPropagation(); setTouched(true); };
    if (k === 'ArrowLeft') { s?.rotate(-0.15); handled(); }
    else if (k === 'ArrowRight') { s?.rotate(0.15); handled(); }
    else if (k === 'ArrowUp') { s?.tilt(-0.1); handled(); }
    else if (k === 'ArrowDown') { s?.tilt(0.1); handled(); }
    else if (k === '+' || k === '=') { s?.zoom(0.85); handled(); }
    else if (k === '-' || k === '_') { s?.zoom(1.18); handled(); }
    else if (k === 'e' || k === 'E') { setExploded(x => !x); handled(); }
    else if (k === 'r' || k === 'R') { s?.resetCamera(); handled(); }
    else if (k === 't' || k === 'T') { setMode(m => (m === 'top' ? 'stack' : 'top')); handled(); }
    else if (k === 's' || k === 'S') { changeScale(scaleMode === 'presentation' ? 'engineering' : 'presentation'); handled(); }
    else if (k === 'f' || k === 'F') { void toggleFullscreen(); handled(); }
    else if (/^[1-6]$/.test(k)) { select(LAYERS[Number(k) - 1].id); handled(); }
    else if (k === '0' || k === 'Escape') { if (selected) { select(null); handled(); } }
  };
  const railKeys = (e: KeyboardEvent<HTMLDivElement>) => {
    const fwd = e.key === 'ArrowDown' || e.key === 'ArrowRight', back = e.key === 'ArrowUp' || e.key === 'ArrowLeft';
    if (!fwd && !back) return;
    e.preventDefault();
    const focusedId = (document.activeElement as HTMLElement | null)?.getAttribute('data-layer-button');
    const from = focusedId ?? selected;
    const i = from ? LAYERS.findIndex(l => l.id === from) : -1;
    const next = fwd ? Math.min(LAYERS.length - 1, i + 1) : Math.max(0, i - 1);
    select(LAYERS[next].id);
    (root.current?.querySelector(`[data-layer-button="${LAYERS[next].id}"]`) as HTMLButtonElement | null)?.focus();
  };

  const layer = selected ? layerById(selected) : null;
  const sceneProps = { mode, selected, visible, exploded, reducedMotion, grid, stretch, animateStretch, needleUm, scaleMode, environment: backdrop, quality };
  // 2D fallback keeps the Mars-bay mood with the same generated landscape as a CSS background (no WebGL needed).
  const mars2D = useMemo(() => {
    if (!render2D || backdrop !== 'bay') return undefined;
    try { const { canvas, ctx } = makeCanvas(1024, 512); drawMarsLandscape(ctx, 1024, 512, 7); return `url(${canvas.toDataURL('image/jpeg', 0.82)})`; } catch { return undefined; }
  }, [render2D, backdrop]);
  const readout = scaleReadout(scaleMode);
  const thicknessRange = `${Math.min(...readout.thickness.map(t => t.exaggeration))}–${Math.max(...readout.thickness.map(t => t.exaggeration))}×`;
  const badge = mode === 'skin' ? 'Skin section · 1 unit = 120 µm · illustrative thicknesses' : mode === 'thigh' ? 'Thigh view · 64 × 48 mm patch on simplified thigh'
    : render2D ? '2D schematic · not to scale' : SCALE_PROFILES[scaleMode].badge;

  // ---------- viewer ----------
  const viewport = <div className="fa-viewport" ref={progressEl} data-exploded={exploded} data-mode={mode} data-environment={backdrop} data-quality={quality}
    style={mars2D ? { backgroundImage: `linear-gradient(rgba(3,7,14,.72), rgba(3,7,14,.86)), ${mars2D}`, backgroundSize: 'cover', backgroundPosition: 'center 40%' } : undefined}
    data-renderer={render2D ? '2d' : '3d'} data-scale={scaleMode} tabIndex={0} role="application"
    onKeyDown={viewportKeys} onPointerDown={() => setTouched(true)} onWheel={() => setTouched(true)}
    aria-label="FlexArray-MN 3D viewer. Drag or arrow keys rotate, scroll or plus and minus zoom, E explode or assemble, S presentation or engineering scale, T top view, R reset view, F full screen, 1 to 6 select a layer, Escape clears selection.">
    {render2D
      ? <FlexArray2D {...sceneProps} onSelect={select} reason={render2D} />
      : <SceneBoundary onError={() => setRender2D('The 3D renderer failed to start.')}>
          <Suspense fallback={<div className="fa-loading" role="status">Initializing 3D view…</div>}>
            <FlexArrayScene ref={scene} {...sceneProps} onSelect={select} onProgress={onProgress} onContextLost={onContextLost} />
          </Suspense>
        </SceneBoundary>}
  </div>;

  const scaleBadge = <button type="button" className={'fa-scale-badge fa-scale-badge-' + (render2D || mode === 'skin' || mode === 'thigh' ? 'neutral' : scaleMode)}
    data-testid="fa-scale-badge" onClick={e => openSheet('scale', e.currentTarget)} aria-label={`${badge}. Open scale and assumptions`}>
    <span className="fa-dot" aria-hidden="true" />{badge}
  </button>;

  const readoutLine = <div className="fa-readout" role="group" aria-label="Visualization scale readout" data-scale={scaleMode}>
    <span><span className="fa-rk">Footprint</span> <b data-testid="fa-footprint">{readout.footprintMm[0]} × {readout.footprintMm[1]} mm</b></span>
    <span><span className="fa-rk">Pitch</span> <b data-testid="fa-pitch">{readout.pitchMm} mm</b> <span className="fa-rk">candidate</span></span>
    <span><span className="fa-rk">Needle</span> <b data-testid="fa-needle-candidate">{readout.candidateNeedleUm} µm</b> <span className="fa-rk">candidate · drawn</span> <b data-testid="fa-needle-rendered">{readout.renderedNeedleMm} mm</b></span>
    <span className={readout.needleExaggeration === 1 ? 'fa-ok' : 'fa-exag'}><b data-testid="fa-exaggeration">{readout.needleExaggeration === 1 ? '1× (to scale)' : readout.needleExaggeration + '×'}</b>
      <span className="fa-rk"> {scaleMode === 'presentation' ? `· layers ${thicknessRange} exaggerated` : '· layers mostly assumed'}</span></span>
    {backdrop === 'bay' && <span className="fa-rk" data-testid="fa-backdrop-note">Patch shown magnified · bay backdrop not to scale</span>}
  </div>;

  // ---------- layer selector ----------
  const rail = <div className="fa-rail" role="group" aria-label="Layers" onKeyDown={railKeys}>
    {LAYERS.map(l => <button key={l.id} type="button" data-layer-button={l.id} aria-pressed={selected === l.id}
      className={(selected === l.id ? 'is-on' : '') + (visible[l.id] ? '' : ' is-hidden')}
      aria-label={`Layer ${l.index}: ${l.name}${visible[l.id] ? '' : ' (hidden)'}`}
      onClick={() => select(selected === l.id ? null : l.id)}>
      <span className="fa-rail-num" aria-hidden="true">{pad2(l.index)}</span>
      <span className="fa-rail-name" aria-hidden="true">{l.shortName}</span>
    </button>)}
  </div>;

  // ---------- contextual layer panel ----------
  const keyParams = layer ? keyParameters(layer) : [];
  const panel = layer && panelOpen && <div className="fa-panel" role="region" aria-labelledby="fa-inspector-title" data-layer={layer.id}>
    <div className="fa-panel-head">
      <span className="fa-kicker">Layer {pad2(layer.index)}</span>
      <button type="button" className="fa-icon-btn" aria-label="Close layer details" onClick={() => setPanelOpen(false)}><Icon d={I.close} /></button>
    </div>
    <h2 id="fa-inspector-title" tabIndex={-1}>{layer.name}</h2>
    <span className={'fa-tag fa-tag-' + layer.validation_status} data-testid="fa-panel-status">{STATUS_LABELS[layer.validation_status]}</span>
    <dl className="fa-dl">
      <dt>Purpose</dt><dd>{layer.purpose}</dd>
    </dl>
    <h3 className="fa-sub">Key parameters</h3>
    <ul className="fa-keyparams">{keyParams.map(p => <li key={p.id} data-key-param-id={p.id}>
      <span className="fa-kp-label">{p.label}</span>
      <span className="fa-kp-value">{p.value} <small>{p.unit}</small></span>
      <span className={'fa-cat fa-cat-tag-' + p.category} title={CATEGORY_LABELS[p.category]}>{p.category}</span>
    </li>)}</ul>
    <dl className="fa-dl">
      <dt>Design rationale</dt><dd>{layer.rationale}</dd>
      <dt>Validation status</dt><dd>{STATUS_LABELS[layer.validation_status]}. {layer.validation_summary}</dd>
    </dl>
    {layer.id === 'stretchable-interconnect' && <div className="fa-ctl">
      <label>Stretch {Math.round((animateStretch && !reducedMotion ? 0 : stretch) * 100)} %
        <input type="range" min={0} max={0.4} step={0.01} value={stretch} disabled={animateStretch && !reducedMotion}
          onChange={e => setStretch(Number(e.target.value))} aria-label="Interconnect stretch strain" /></label>
      <label className="fa-check"><input type="checkbox" checked={animateStretch} disabled={reducedMotion} onChange={e => setAnimateStretch(e.target.checked)} />
        Animate stretch{reducedMotion ? ' (off: reduced motion)' : ''}</label>
    </div>}
    <div className="fa-panel-actions">
      {layer.id === 'microneedle-array' && !render2D && <button type="button" className="fa-pill" onClick={focusNeedles}>Zoom to microneedles</button>}
      <button type="button" className="fa-pill" aria-pressed={!visible[layer.id]}
        onClick={() => setVisible(v => ({ ...v, [layer.id]: !v[layer.id] }))}>{visible[layer.id] ? 'Hide layer' : 'Show layer'}</button>
    </div>
    <details className="fa-more">
      <summary>Full engineering data</summary>
      <dl className="fa-dl"><dt>Material concept</dt><dd>{layer.material}</dd></dl>
      <ParameterTable params={layer.parameters} />
      <h3 className="fa-sub">Limitations</h3>
      <ul className="fa-bullets">{layer.limitations.map(x => <li key={x}>{x}</li>)}</ul>
      <h3 className="fa-sub">Evidence</h3>
      <ul className="fa-evidence">{layer.evidence.map(ev => { const r = referenceById(ev.source_id); return <li key={ev.source_id}><p>{ev.note}</p>{r && <RefLine r={r} />}</li>; })}</ul>
    </details>
  </div>;

  // ---------- bottom dock ----------
  const dock = <div className="fa-dock" role="toolbar" aria-label="Viewer controls">
    <div className="fa-dock-group" role="group" aria-label="Rotate">
      <button type="button" className="fa-icon-btn" aria-label="Rotate left" disabled={!!render2D} onClick={() => { scene.current?.rotate(-0.35); setTouched(true); }}><Icon d={I.rotL} /></button>
      <button type="button" className="fa-icon-btn" aria-label="Rotate right" disabled={!!render2D} onClick={() => { scene.current?.rotate(0.35); setTouched(true); }}><Icon d={I.rotR} /></button>
    </div>
    <div className="fa-dock-group" role="group" aria-label="Zoom">
      <button type="button" className="fa-icon-btn" aria-label="Zoom out" disabled={!!render2D} onClick={() => scene.current?.zoom(1.2)}><Icon d={I.zoomOut} /></button>
      <button type="button" className="fa-icon-btn" aria-label="Zoom in" disabled={!!render2D} onClick={() => scene.current?.zoom(0.83)}><Icon d={I.zoomIn} /></button>
    </div>
    <button type="button" className="fa-dock-main" aria-pressed={exploded} disabled={mode !== 'stack'} onClick={() => setExploded(x => !x)}>
      <Icon d={I.explode} /><span>{exploded ? 'Assemble' : 'Explode'}</span>
    </button>
    <label className="fa-view-select"><span className="sr-only">View</span>
      <select aria-label="View" value={mode} onChange={e => setMode(e.target.value as ViewMode)}>
        {VIEWS.map(v => <option key={v.id} value={v.id}>{v.label}</option>)}
      </select>
    </label>
    <button type="button" className="fa-icon-btn" aria-label="Reset view" disabled={!!render2D && mode === 'stack'} onClick={resetView}><Icon d={I.reset} /></button>
    {canFullscreen && <button type="button" className="fa-icon-btn" aria-label={fullscreen ? 'Exit full screen' : 'Full screen'} aria-pressed={fullscreen} onClick={toggleFullscreen}><Icon d={fullscreen ? I.unfull : I.full} /></button>}
  </div>;

  const skinControl = mode === 'skin' && <div className="fa-float-ctl fa-ctl">
    <label>Candidate needle length {needleUm} µm
      <input type="range" min={100} max={300} step={10} value={needleUm} onChange={e => setNeedleUm(Number(e.target.value))} aria-label="Candidate needle length in micrometers" /></label>
    <p className="fa-warn">Nominal tip: {nominalTipLayer(needleUm)} (illustrative thicknesses; skin deforms on insertion). Penetration depth is <strong>not validated</strong>.</p>
  </div>;

  const disclaimer = <p className="fa-disclaimer" data-testid="fa-disclaimer">{DISCLAIMER}</p>;

  // ---------- research sheet (all detailed engineering content) ----------
  const sheetEl = sheet && <div className="fa-sheet-backdrop" onClick={e => { if (e.target === e.currentTarget) closeSheet(); }}>
    <div className="fa-sheet" role="dialog" aria-modal="true" aria-labelledby="fa-sheet-title" ref={sheetRef}
      onKeyDown={e => { if (e.key === 'Escape') { e.stopPropagation(); closeSheet(); } }}>
      <div className="fa-sheet-head">
        <h2 id="fa-sheet-title" className="fa-sheet-title" tabIndex={-1}>Research &amp; References</h2>
        <button type="button" className="fa-icon-btn" aria-label="Close research panel" onClick={closeSheet}><Icon d={I.close} /></button>
      </div>
      <div className="fa-sheet-tabs" role="tablist" aria-label="Research sections">
        {SHEET_TABS.map(t => <button key={t.id} type="button" role="tab" id={'fa-stab-' + t.id} aria-selected={sheet === t.id} aria-controls="fa-sheet-panel"
          tabIndex={sheet === t.id ? 0 : -1} onClick={() => setSheet(t.id)}
          onKeyDown={e => { if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { e.preventDefault(); const i = SHEET_TABS.findIndex(x => x.id === sheet); const n = SHEET_TABS[(i + (e.key === 'ArrowRight' ? 1 : SHEET_TABS.length - 1)) % SHEET_TABS.length]; setSheet(n.id); (e.currentTarget.parentElement?.querySelector('#fa-stab-' + n.id) as HTMLElement | null)?.focus(); } }}>{t.label}</button>)}
      </div>
      <div className="fa-sheet-body" id="fa-sheet-panel" role="tabpanel" aria-labelledby={'fa-stab-' + sheet}>
        {sheet === 'references' && <References />}
        {sheet === 'scale' && <ScaleDetails scaleMode={scaleMode} />}
        {sheet === 'matrix' && <ElectrodeMatrix rows={grid.rows} cols={grid.cols} referencing={referencing} afe={afe}
          onGrid={n => setGrid({ rows: n, cols: n })} onReferencing={setReferencing} onAfe={setAfe} />}
        {sheet === 'system' && <>
          <p className="fa-small">{MODEL_VERSION} · settings that apply to the whole patch.</p>
          <ParameterTable params={SYSTEM_PARAMETERS} />
          <h3 className="fa-sub">Parameter categories</h3>
          <ul className="fa-legend">{(['A', 'B', 'C'] as const).map(c => <li key={c}><span className={'fa-cat fa-cat-tag-' + c}>{c}</span> <strong>{CATEGORY_LABELS[c]}</strong> — {CATEGORY_NOTES[c]}</li>)}</ul>
          <h3 className="fa-sub">Background</h3>
          <div className="fa-seg fa-seg-inline" role="group" aria-label="Background">
            {([['bay', 'Mars EVA bay'], ['minimal', 'Minimal']] as [Backdrop, string][]).map(([b, label]) =>
              <button key={b} type="button" aria-pressed={backdrop === b} onClick={() => setBackdrop(b)}>{label}</button>)}
          </div>
          <p className="fa-small">The Mars EVA preparation bay is an original, procedurally generated backdrop (no third-party assets). It is not to scale with the patch, which is shown as a magnified holographic display. {quality === 'lite' ? 'Lite quality is active on this device (fewer effects).' : ''}</p>
          <h3 className="fa-sub">Model</h3>
          <div className="fa-panel-actions">
            <button type="button" className="fa-pill" onClick={resetModel}>Reset model</button>
            <button type="button" className="fa-pill" onClick={() => setRender2D(r => (r ? (hasWebGL() ? null : r) : 'Switched to 2D by user.'))}>{render2D ? 'Try 3D view' : 'Use 2D schematic'}</button>
          </div>
        </>}
        {sheet === 'controls' && <dl className="fa-keys">
          {[['Drag / one finger', 'Rotate'], ['Scroll / pinch', 'Zoom'], ['← → ↑ ↓', 'Rotate and tilt (viewer focused)'], ['+ / −', 'Zoom'], ['1 – 6', 'Select layer'],
            ['E', 'Explode / assemble'], ['S', 'Presentation / engineering scale'], ['T', 'Top view'], ['R', 'Reset view'], ['F', 'Full screen'], ['Esc', 'Clear selection / close panel']]
            .map(([k, v]) => <div key={k}><dt><kbd>{k}</kbd></dt><dd>{v}</dd></div>)}
        </dl>}
        {disclaimer}
      </div>
    </div>
  </div>;

  return <div className={'fa-root fa-show' + (panelOpen && layer && !demoActive ? ' has-panel' : '') + (fullscreen ? ' is-fullscreen' : '') + (demoActive ? ' is-demo' : '')} ref={root}
    data-motion={reducedMotion ? 'reduced' : 'full'} onKeyDown={e => { if (e.key === 'Escape' && panelOpen && !sheet && (e.target as HTMLElement).closest('.fa-panel')) { setPanelOpen(false); } }}>
    <div className="sr-only" role="status" aria-live="polite">{announce}</div>
    {viewport}
    <div className="fa-top" role="banner">
      <div className="fa-brand">
        {onExit && <button type="button" className="fa-back" onClick={onExit} aria-label="Back to ASTRA mission console"><Icon d={I.back} /><span>ASTRA</span></button>}
        <h1 className="fa-title">ASTRA <span>FlexArray-MN</span></h1>
        <p className="fa-subtitle">Interactive 3D Layer Explorer</p>
        {scaleBadge}
      </div>
      {!demoActive && <div className="fa-top-actions">
        <button ref={demoButton} type="button" className="fa-pill fa-demo-start" onClick={startDemo}>
          <svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M8 5l11 7-11 7z" fill="currentColor" /></svg>Start demo
        </button>
        <div className="fa-seg" role="group" aria-label="Visualization scale">
          {(['presentation', 'engineering'] as ScaleMode[]).map(m => <button key={m} type="button" aria-pressed={scaleMode === m} onClick={() => changeScale(m)}>
            {m === 'presentation' ? 'Presentation' : 'Engineering'}<span className="sr-only"> scale</span></button>)}
        </div>
        <button type="button" className="fa-pill fa-research-btn" onClick={e => openSheet('references', e.currentTarget)}>Research &amp; References</button>
      </div>}
    </div>
    {demoActive
      ? <DemoPlayer reducedMotion={reducedMotion} onCue={onDemoCue} onExit={exitDemo} />
      : <>
        {rail}
        {panel}
        {skinControl}
        <div className={'fa-hint' + (touched ? ' is-faded' : '')} aria-hidden="true">{render2D ? 'Tab to a layer · Enter selects' : 'Drag to rotate · Scroll or pinch to zoom · Select a layer'}</div>
        <div className="fa-bottom">
          {dock}
          {readoutLine}
          {disclaimer}
        </div>
      </>}
    {demoActive && <div className="fa-demo-readout">{readoutLine}</div>}
    {sheetEl}
  </div>;
}

function ScaleDetails({ scaleMode }: { scaleMode: ScaleMode }) {
  const readout = scaleReadout(scaleMode), pres = scaleReadout('presentation');
  return <div className="fa-scale-card" role="region" aria-labelledby="fa-scale-title">
    <h3 id="fa-scale-title" className="fa-sub">Visualization scale &amp; dimension basis <span className={'fa-tag ' + (scaleMode === 'engineering' ? 'fa-tag-proposed-target' : 'fa-tag-pending-validation')}>{SCALE_PROFILES[scaleMode].label}</span></h3>
    <p className="fa-small"><strong>Presentation scale</strong> keeps the true 64 × 48 mm footprint and 5 mm pitch, but exaggerates layer thickness and draws microneedles {pres.renderedNeedleMm} mm long ({pres.needleExaggeration}× the {readout.candidateNeedleUm} µm candidate) so they can be seen. <strong>Engineering scale</strong> draws research-candidate dimensions where they exist; every other thickness is labelled an assumption. Neither is a manufacturing specification.</p>
    <div className="fa-table-wrap"><table className="fa-scale-table">
      <thead><tr><th scope="col">Layer</th><th scope="col">Presentation (drawn)</th><th scope="col">Engineering</th><th scope="col">Basis</th><th scope="col">Exaggeration</th></tr></thead>
      <tbody>{pres.thickness.map((t, i) => <tr key={t.id} data-thickness-id={t.id}>
        <th scope="row">{pad2(LAYERS[i].index)} {LAYERS[i].shortName}</th>
        <td>{t.renderedUm} µm</td><td>{t.engineeringUm} µm</td>
        <td><span className={'fa-basis fa-basis-' + t.basis} title={t.note}>{BASIS_LABELS[t.basis]}</span></td>
        <td>{t.exaggeration}×</td>
      </tr>)}
        <tr data-thickness-id="microneedle"><th scope="row">Microneedle length</th><td>{pres.renderedNeedleMm * 1000} µm</td><td>{readout.candidateNeedleUm} µm</td>
          <td><span className="fa-basis fa-basis-candidate">{BASIS_LABELS.candidate}</span></td><td>{pres.needleExaggeration}×</td></tr>
      </tbody>
    </table></div>
    <ul className="fa-scale-details">{ENGINEERING_DETAILS.map(d => <li key={d.label}><span className={'fa-basis fa-basis-' + d.basis}>{BASIS_LABELS[d.basis]}</span> {d.label}: {d.value}</li>)}</ul>
    <h3 className="fa-sub">Open design limitations</h3>
    <p className="fa-warn" data-testid="fa-reach-warning">Stack-order check (engineering scale): layers 3–6 add ≈ {readout.belowNeedleUm} µm (assumed) below the needle base. {readout.needleReachUm < 0
      ? `A ${readout.candidateNeedleUm} µm needle on layer 2 would end ≈ ${-readout.needleReachUm} µm short of the skin. Apertures or a re-ordered stack are needed; this is an open design issue.`
      : `A ${readout.candidateNeedleUm} µm needle would protrude ≈ ${readout.needleReachUm} µm.`}</p>
    <p className="fa-warn" data-testid="fa-component-warning">Height check (engineering scale): assumed component packages up to {readout.maxComponentMm} mm are taller than the assumed {readout.engineeringStackMm} mm laminate, so they protrude through layers 1–3 in this view. A real cover would need to dome over the electronics island. Open design issue.</p>
  </div>;
}

function ParameterTable({ params }: { params: Parameter[] }) {
  const groups = useMemo(() => parametersByCategory(params).filter(g => g.items.length), [params]);
  return <div className="fa-params">
    {groups.map(g => <div key={g.category} className={'fa-pgroup fa-cat-' + g.category}>
      <h4><span className={'fa-cat fa-cat-tag-' + g.category}>{g.category}</span> {g.label}</h4>
      <div className="fa-table-wrap"><table>
        <thead><tr><th scope="col">Parameter</th><th scope="col">Value</th><th scope="col">Status</th></tr></thead>
        <tbody>{g.items.map(p => { const r = referenceById(p.source_id); return <tr key={p.id} data-param-id={p.id}>
          <th scope="row">{p.label}<span className="fa-rationale">{p.rationale}{r && <> Source: {r.verification === 'verified' && r.url ? <a href={r.url} target="_blank" rel="noreferrer">{shortRef(r)}</a> : 'Reference verification pending'}</>}</span></th>
          <td>{p.value} <span className="fa-unit">{p.unit}</span></td>
          <td><span className={'fa-tag fa-tag-' + p.validation_status}>{STATUS_LABELS[p.validation_status]}</span></td>
        </tr>; })}</tbody>
      </table></div>
    </div>)}
  </div>;
}

const shortRef = (r: (typeof REFERENCES)[number]) => `${r.authors.split(',')[0]} ${r.year ?? ''}`.trim();
function RefLine({ r }: { r: (typeof REFERENCES)[number] }) {
  return <div className="fa-refline">
    <span className={'fa-tag ' + (r.verification === 'verified' ? 'fa-tag-verified' : 'fa-tag-pending-validation')}>{r.verification === 'verified' ? 'Verified' : 'Reference verification pending'}</span>
    {r.verification === 'verified' ? <> <cite>{r.title}</cite> · {r.authors} · {r.venue} ({r.year}){r.doi && <> · DOI <a href={r.url ?? `https://doi.org/${r.doi}`} target="_blank" rel="noreferrer">{r.doi}</a></>}{!r.doi && r.url && <> · <a href={r.url} target="_blank" rel="noreferrer">source</a></>}</> : <> {r.topic}</>}
  </div>;
}

function References() {
  return <div className="fa-refs" role="region" aria-labelledby="fa-refs-title">
    <h3 id="fa-refs-title" className="fa-sub">References &amp; validation status <span className="fa-small">Checked 2026-11-14 · Crossref, PubMed, nature.com, NASA</span></h3>
    <ol>{REFERENCES.map(r => <li key={r.id} data-ref-id={r.id}>
      <RefLine r={r} />
      <p className="fa-small">{r.summary}</p>
      <p className="fa-small"><strong>Use here:</strong> {r.relevance}</p>
    </li>)}</ol>
  </div>;
}
