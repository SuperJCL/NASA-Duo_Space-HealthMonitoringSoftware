// Geometry specification for the FlexArray-MN model. Pure math, no Three.js imports.
// Scene units: 1 unit = 10 mm. Two visualization scales: presentation (exaggerated) and engineering (candidate/assumed).
import type { LayerId } from './flexArrayData';

export const FOOTPRINT = { width: 6.4, depth: 4.8, radius: 0.7 }; // 64 × 48 mm conceptual outline
export const COLORS = {
  navy: '#060D19', cyan: '#4CE4F5', gold: '#D9B45A', goldDeep: '#A8822F',
  film: '#9FDDF5', substrate: '#5AA7E0', sweat: '#2D8BD8', pcb: '#1E5C7A', interconnect: '#3C6FA8', adhesive: '#E6EEF5',
  skin: '#D9A08A', dermis: '#C97F72', fat: '#E8C98A',
};

export type LayerGeometry = { id: LayerId; thickness: number; color: string; opacity: number; assembledY: number };
const STYLE: { id: LayerId; color: string; opacity: number }[] = [
  { id: 'protective-film', color: COLORS.film, opacity: 0.32 },
  { id: 'microneedle-array', color: COLORS.substrate, opacity: 0.45 },
  { id: 'sweat-management', color: COLORS.sweat, opacity: 0.38 },
  { id: 'flex-electronics', color: COLORS.pcb, opacity: 0.7 },
  { id: 'stretchable-interconnect', color: COLORS.interconnect, opacity: 0.4 },
  { id: 'adhesive-frame', color: COLORS.adhesive, opacity: 0.55 },
];
export const EXPLODE_GAP = 1.05; // viewing offset between exploded layers (10.5 mm), not a physical dimension

// ---------------- visualization scale ----------------
// 'presentation': legible, NOT to scale (thickness and microneedles exaggerated).
// 'engineering':  research-candidate dimensions where defined; every other thickness is an explicit ASSUMPTION.
// Neither profile is a validated manufacturing specification.
export type ScaleMode = 'presentation' | 'engineering';
export type DimensionBasis = 'design' | 'candidate' | 'assumption';
export const BASIS_LABELS: Record<DimensionBasis, string> = {
  design: 'Concept design value', candidate: 'Research candidate', assumption: 'Assumption (unknown)',
};
export const UNIT_MM = 10; // 1 scene unit = 10 mm
const um = (v: number) => v / 1000 / UNIT_MM; // micrometres → scene units
const mm = (v: number) => v / UNIT_MM;

/** Candidate figures shared by both modes (all unvalidated). */
export const CANDIDATE = { footprintMm: [64, 48] as const, pitchMm: 5, needleLengthUm: 200, needleBaseUm: 60, channelWidthUm: 200, traceWidthUm: 70 };

/** Engineering-scale layer thickness in µm and where each number comes from. */
export const ENGINEERING_THICKNESS: Record<LayerId, { um: number; basis: DimensionBasis; note: string }> = {
  'protective-film': { um: 30, basis: 'candidate', note: 'Mid-point of the proposed 20–50 µm film thickness.' },
  'microneedle-array': { um: 25, basis: 'assumption', note: 'Assumed thin polyimide-class substrate; not specified.' },
  'sweat-management': { um: 200, basis: 'assumption', note: 'Assumed elastomer microchannel layer; not specified.' },
  'flex-electronics': { um: 100, basis: 'assumption', note: 'Assumed flex-PCB thickness, excluding components.' },
  'stretchable-interconnect': { um: 50, basis: 'assumption', note: 'Assumed elastomer encapsulation; not specified.' },
  'adhesive-frame': { um: 100, basis: 'assumption', note: 'Assumed adhesive + carrier thickness; not specified.' },
};
const PRESENTATION_THICKNESS: Record<LayerId, number> = {
  'protective-film': 0.05, 'microneedle-array': 0.06, 'sweat-management': 0.08, 'flex-electronics': 0.06, 'stretchable-interconnect': 0.05, 'adhesive-frame': 0.05,
};

export type ScaleProfile = {
  mode: ScaleMode; label: string; badge: string;
  thickness: Record<LayerId, number>;      // scene units
  needle: { length: number; radius: number };
  pad: { radius: number; height: number };
  ringTube: number; channelRadius: number; traceRadius: number; serpentineRadius: number; poreLift: number; dotRadius: number;
  minDistance: number;                      // closest camera distance (scene units)
};
export const SCALE_PROFILES: Record<ScaleMode, ScaleProfile> = {
  presentation: {
    mode: 'presentation', label: 'Presentation scale', badge: 'NOT TO SCALE · thickness & microneedles exaggerated',
    thickness: PRESENTATION_THICKNESS,
    needle: { length: 0.36, radius: 0.055 }, pad: { radius: 0.1, height: 0.035 },
    ringTube: 0.018, channelRadius: 0.014, traceRadius: 0.01, serpentineRadius: 0.012, poreLift: 0.002, dotRadius: 0.035, minDistance: 4,
  },
  engineering: {
    mode: 'engineering', label: 'Engineering scale', badge: 'ENGINEERING SCALE · candidate + assumed dimensions · not a manufacturing spec',
    thickness: Object.fromEntries(Object.entries(ENGINEERING_THICKNESS).map(([k, v]) => [k, um(v.um)])) as Record<LayerId, number>,
    needle: { length: um(CANDIDATE.needleLengthUm), radius: um(CANDIDATE.needleBaseUm / 2) },
    pad: { radius: mm(1), height: um(20) },
    ringTube: um(50), channelRadius: um(CANDIDATE.channelWidthUm / 2), traceRadius: um(CANDIDATE.traceWidthUm / 2), serpentineRadius: um(CANDIDATE.traceWidthUm / 2),
    poreLift: um(2), dotRadius: um(80), minDistance: 0.12,
  },
};
/** Engineering-scale dimensions not covered above, each labelled. */
export const ENGINEERING_DETAILS: { label: string; value: string; basis: DimensionBasis }[] = [
  { label: 'Contact pad', value: '2 mm Ø × 20 µm', basis: 'assumption' },
  { label: 'Needles per electrode site', value: '1', basis: 'assumption' },
  { label: 'Microchannel width', value: '200 µm (range 100–300 µm)', basis: 'candidate' },
  { label: 'Trace width', value: '70 µm (range 50–100 µm)', basis: 'candidate' },
  { label: 'Component package heights', value: '0.7–1.2 mm', basis: 'assumption' },
  { label: 'Exploded-view layer spacing', value: '10.5 mm (viewing offset only)', basis: 'design' },
];

export function layerStack(mode: ScaleMode = 'presentation'): LayerGeometry[] {
  const t = SCALE_PROFILES[mode].thickness;
  let y = 0;
  const out: LayerGeometry[] = [];
  for (let i = STYLE.length - 1; i >= 0; i--) { out.unshift({ ...STYLE[i], thickness: t[STYLE[i].id], assembledY: y }); y += t[STYLE[i].id]; }
  return out;
}
const STACKS: Record<ScaleMode, LayerGeometry[]> = { presentation: layerStack('presentation'), engineering: layerStack('engineering') };
/** Presentation-scale stack (kept for existing callers). Layer 1 on top (index 0) → layer 6 at the skin (y = 0). */
export const LAYER_GEOMETRY: LayerGeometry[] = STACKS.presentation;

export function layerY(index0: number, explode: number, mode: ScaleMode = 'presentation') {
  const stack = STACKS[mode], g = stack[index0];
  const level = stack.length - 1 - index0; // 0 for skin-facing layer
  return g.assembledY + Math.max(0, Math.min(1, explode)) * level * EXPLODE_GAP;
}

/** Rendered-vs-candidate figures shown in the UI and written into GLB metadata. */
export function scaleReadout(mode: ScaleMode) {
  const prof = SCALE_PROFILES[mode];
  const renderedNeedleMm = +(prof.needle.length * UNIT_MM).toFixed(3);
  const needleExaggeration = +(renderedNeedleMm / (CANDIDATE.needleLengthUm / 1000)).toFixed(2);
  const totalMm = (m: ScaleMode) => STACKS[m].reduce((s, l) => s + l.thickness, 0) * UNIT_MM;
  const thickness = STYLE.map(({ id }) => {
    const eng = ENGINEERING_THICKNESS[id];
    const renderedUm = Math.round(prof.thickness[id] * UNIT_MM * 1000);
    return { id, renderedUm, engineeringUm: eng.um, basis: eng.basis, note: eng.note, exaggeration: +(renderedUm / eng.um).toFixed(1) };
  });
  // V2.1 stack order: needles sit on layer 2, so layers 3–6 lie between the needle base and the skin.
  const belowNeedleUm = STYLE.slice(2).reduce((s, { id }) => s + ENGINEERING_THICKNESS[id].um, 0);
  return {
    mode, footprintMm: CANDIDATE.footprintMm, pitchMm: CANDIDATE.pitchMm, candidateNeedleUm: CANDIDATE.needleLengthUm,
    renderedNeedleMm, needleExaggeration, renderedStackMm: +totalMm(mode).toFixed(3), engineeringStackMm: +totalMm('engineering').toFixed(3),
    thickness, belowNeedleUm, needleReachUm: CANDIDATE.needleLengthUm - belowNeedleUm,
    // Assumed component packages vs. the laminate they sit in (engineering scale): a flat cover cannot enclose them.
    maxComponentMm: Math.max(...COMPONENTS.map(c => c.h)) * UNIT_MM,
  };
}

/** Electrode centers on the XZ plane, centered on the patch. */
export function electrodeGrid(rows: number, cols: number, pitch = 0.5) {
  const pts: { row: number; col: number; x: number; z: number }[] = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++)
    pts.push({ row: r, col: c, x: (c - (cols - 1) / 2) * pitch, z: (r - (rows - 1) / 2) * pitch });
  return pts;
}

/**
 * Serpentine trace that straightens under strain while conserving arc length (numerically solved),
 * which is how serpentine interconnects accommodate stretch. strain: 0 … 0.6. Illustrative kinematics, not FEA.
 */
export function serpentine(length: number, periods: number, amplitude: number, strain: number, samples = 160) {
  const s = Math.max(0, Math.min(0.6, strain));
  const span = length * (1 + s);
  const wave = (a: number, w: number, n = 96) => { // arc length of one period of a·sin(2πx/w)
    let L = 0, px = 0, py = 0;
    for (let i = 1; i <= n; i++) { const x = (w * i) / n, y = a * Math.sin((2 * Math.PI * x) / w); L += Math.hypot(x - px, y - py); px = x; py = y; }
    return L;
  };
  const target = wave(amplitude, length / periods), wavelength = span / periods;
  let lo = 0, hi = amplitude; // straightening only: amplitude shrinks as span grows
  for (let i = 0; i < 40; i++) { const mid = (lo + hi) / 2; if (wave(mid, wavelength) < target) lo = mid; else hi = mid; }
  const a = target <= wavelength ? 0 : (lo + hi) / 2;
  const pts: [number, number][] = [];
  for (let i = 0; i <= samples; i++) {
    const x = -span / 2 + (span * i) / samples;
    pts.push([x, a * Math.sin((2 * Math.PI * (x + span / 2)) / wavelength)]);
  }
  return { points: pts, amplitude: a, span };
}
export function polylineLength(points: [number, number][]) {
  let L = 0;
  for (let i = 1; i < points.length; i++) L += Math.hypot(points[i][0] - points[i - 1][0], points[i][1] - points[i - 1][1]);
  return L;
}

/** Sweat channel routes: from each electrode column gap outward to the edge vents (XZ polylines). */
export function sweatRoutes(rows: number, cols: number, pitch = 0.5) {
  const routes: [number, number][][] = [];
  const halfW = FOOTPRINT.width / 2 - 0.35, halfD = FOOTPRINT.depth / 2 - 0.35;
  for (let r = 0; r < rows - 1; r++) {
    const z = (r - (rows - 2) / 2) * pitch;
    routes.push([[-halfW, z], [-((cols - 1) / 2) * pitch, z], [0, z + pitch * 0.12], [((cols - 1) / 2) * pitch, z], [halfW, z]]);
  }
  // perimeter collector
  routes.push([[-halfW, -halfD], [halfW, -halfD], [halfW, halfD], [-halfW, halfD], [-halfW, -halfD]]);
  return routes;
}

/** Flexible electronics component placement (conceptual). */
export const COMPONENTS = [
  { id: 'afe', label: 'Analog front end', x: -1.2, z: -0.4, w: 1.1, d: 0.8, h: 0.12, color: '#1a1f27' },
  { id: 'adc', label: 'ADC', x: 0.05, z: -0.6, w: 0.5, d: 0.5, h: 0.09, color: '#22303b' },
  { id: 'mcu', label: 'Microcontroller', x: 0.05, z: 0.35, w: 0.8, d: 0.8, h: 0.1, color: '#11161d' },
  { id: 'imu', label: 'IMU (6-axis)', x: 1.05, z: -0.55, w: 0.4, d: 0.4, h: 0.08, color: '#2b2f38' },
  { id: 'radio', label: 'Wireless radio', x: 1.15, z: 0.4, w: 0.55, d: 0.45, h: 0.08, color: '#283240' },
  { id: 'battery', label: 'Battery (conceptual)', x: 2.35, z: 0, w: 0.8, d: 2.6, h: 0.1, color: '#8a96a3' },
  { id: 'cond', label: 'Signal conditioning', x: -2.3, z: 0.6, w: 0.6, d: 0.6, h: 0.07, color: '#1d2630' },
] as const;

export const CAMERA_DEFAULT = { position: [9.6, 8.4, 11.2] as [number, number, number], target: [0, 2.7, 0] as [number, number, number], fov: 36 };
export const ZOOM_LIMITS = { min: 4, max: 24 };
export const clampDistance = (d: number, min: number = ZOOM_LIMITS.min) => Math.max(min, Math.min(ZOOM_LIMITS.max, d));

/** Illustrative skin layers (µm). Typical textbook orders of magnitude; strongly site- and person-dependent. */
export const SKIN_LAYERS = [
  { id: 'sc', label: 'Stratum corneum', thicknessUm: 15, color: '#E9C3A6' },
  { id: 'epi', label: 'Viable epidermis', thicknessUm: 80, color: COLORS.skin },
  { id: 'dermis', label: 'Dermis', thicknessUm: 1200, color: COLORS.dermis },
  { id: 'fat', label: 'Subcutaneous fat', thicknessUm: 800, color: COLORS.fat },
] as const;

/** Which illustrative skin layer a nominal needle tip would sit in, ignoring skin deformation (it is NOT a penetration estimate). */
export function nominalTipLayer(needleUm: number) {
  let depth = 0;
  for (const l of SKIN_LAYERS) { depth += l.thicknessUm; if (needleUm <= depth) return l.label; }
  return SKIN_LAYERS[SKIN_LAYERS.length - 1].label;
}
