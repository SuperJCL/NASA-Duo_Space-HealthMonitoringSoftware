import { forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState, type ReactNode } from 'react';
import { Canvas, useFrame, useThree, type ThreeEvent } from '@react-three/fiber';
import { Edges, Html, Line, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { LAYERS, type LayerId } from './flexArrayData';
import { FlexArrayEnvironment } from './FlexArrayEnvironment';
import { BAY, type Backdrop, type BayQuality } from './bayLayout';
import {
  CAMERA_DEFAULT, COLORS, COMPONENTS, FOOTPRINT, SCALE_PROFILES, SKIN_LAYERS, clampDistance, electrodeGrid, layerStack, layerY, scaleReadout, serpentine, sweatRoutes,
  type ScaleMode, type ScaleProfile,
} from './flexArrayGeometry';

export type ViewMode = 'stack' | 'skin' | 'thigh' | 'top';
export type SceneApi = { resetCamera: () => void; rotate: (dAzimuth: number) => void; tilt: (dPolar: number) => void; zoom: (factor: number) => void; focus: (position: [number, number, number], target: [number, number, number]) => void };
export type SceneProps = {
  mode: ViewMode;
  selected: LayerId | null;
  visible: Record<LayerId, boolean>;
  exploded: boolean;
  reducedMotion: boolean;
  grid: { rows: number; cols: number };
  stretch: number;
  animateStretch: boolean;
  needleUm: number;
  scaleMode: ScaleMode;
  /** Optional backdrop around the patch (does not change the model). */
  environment?: Backdrop;
  quality?: BayQuality;
  onSelect: (id: LayerId | null) => void;
  onProgress: (explodeProgress: number) => void;
  onContextLost: () => void;
};

const CAMERAS: Record<ViewMode, { position: [number, number, number]; target: [number, number, number] }> = {
  stack: { position: CAMERA_DEFAULT.position, target: CAMERA_DEFAULT.target },
  top: { position: [0, 15, 0.01], target: [0, 1.2, 0] },
  skin: { position: [4.2, 1.6, 9.6], target: [0, -0.9, 0] },
  thigh: { position: [3.4, 4.2, 9.8], target: [0, 0.4, 0] },
};

function roundedRect(w: number, d: number, r: number) {
  const s = new THREE.Shape();
  const x = -w / 2, y = -d / 2;
  s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + d - r); s.quadraticCurveTo(x + w, y + d, x + w - r, y + d);
  s.lineTo(x + r, y + d); s.quadraticCurveTo(x, y + d, x, y + d - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y);
  return s;
}
function slabGeometry(thickness: number, hole = 0) {
  const shape = roundedRect(FOOTPRINT.width, FOOTPRINT.depth, FOOTPRINT.radius);
  if (hole > 0) {
    const h = roundedRect(FOOTPRINT.width - hole * 2, FOOTPRINT.depth - hole * 2, Math.max(0.1, FOOTPRINT.radius - hole * 0.6));
    shape.holes.push(new THREE.Path(h.getPoints(24).reverse()));
  }
  const g = new THREE.ExtrudeGeometry(shape, { depth: thickness, bevelEnabled: false, curveSegments: 18 });
  g.rotateX(-Math.PI / 2); // extrusion now points +Y, shape lies in XZ
  return g;
}

/** Transparent material that the layer fader can scale. */
function fadeMat(color: string, opacity: number, extra: Partial<THREE.MeshStandardMaterialParameters> = {}) {
  const m = new THREE.MeshStandardMaterial({ color, transparent: true, opacity, roughness: 0.35, metalness: 0.1, depthWrite: opacity > 0.6, ...extra });
  m.userData.baseOpacity = opacity;
  return m;
}
const goldMat = () => fadeMat(COLORS.gold, 1, { metalness: 0.85, roughness: 0.28, emissive: new THREE.Color('#5a3d0c'), emissiveIntensity: 0.35, depthWrite: true });

// ---------------- layer contents ----------------

function FilmDetails({ prof }: { prof: ScaleProfile }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const pores = useMemo(() => { const out: [number, number][] = []; for (let r = 0; r < 9; r++) for (let c = 0; c < 13; c++) out.push([(c - 6) * 0.42, (r - 4) * 0.42]); return out; }, []);
  useEffect(() => {
    const m = new THREE.Matrix4();
    pores.forEach(([x, z], i) => { m.makeRotationX(-Math.PI / 2); m.setPosition(x, prof.poreLift, z); ref.current!.setMatrixAt(i, m); });
    ref.current!.instanceMatrix.needsUpdate = true;
  }, [pores, prof]);
  const mat = useMemo(() => fadeMat('#0b2a44', 0.75), []);
  const geo = useMemo(() => new THREE.CircleGeometry(0.045, 12), []);
  return <instancedMesh ref={ref} args={[geo, mat, pores.length]} />;
}

function ElectrodeArray({ rows, cols, prof, label }: { rows: number; cols: number; prof: ScaleProfile; label: string | null }) {
  const pads = useRef<THREE.InstancedMesh>(null), needles = useRef<THREE.InstancedMesh>(null);
  const pts = useMemo(() => electrodeGrid(rows, cols), [rows, cols]);
  const gold = useMemo(goldMat, []);
  const padGeo = useMemo(() => new THREE.CylinderGeometry(prof.pad.radius, prof.pad.radius, prof.pad.height, 20), [prof]);
  const needleGeo = useMemo(() => { const g = new THREE.ConeGeometry(prof.needle.radius, prof.needle.length, 16); g.rotateX(Math.PI); return g; }, [prof]);
  useEffect(() => {
    const m = new THREE.Matrix4();
    pts.forEach((p, i) => {
      m.makeTranslation(p.x, prof.pad.height / 2, p.z); pads.current!.setMatrixAt(i, m);
      m.makeTranslation(p.x, -prof.needle.length / 2, p.z); needles.current!.setMatrixAt(i, m); // base at layer top, tip toward skin
    });
    pads.current!.count = needles.current!.count = pts.length;
    pads.current!.instanceMatrix.needsUpdate = needles.current!.instanceMatrix.needsUpdate = true;
  }, [pts, padGeo, needleGeo]);
  const traces = useMemo(() => {
    const out: [number, number, number][][] = [];
    for (let r = 0; r < rows; r++) { const z = (r - (rows - 1) / 2) * 0.5 + 0.16; out.push([[-FOOTPRINT.width / 2 + 0.4, prof.traceRadius, z], [((cols - 1) / 2) * 0.5, prof.traceRadius, z]]); }
    return out;
  }, [rows, cols, prof]);
  return <group>
    <instancedMesh key={'p' + pts.length + prof.mode} ref={pads} args={[padGeo, gold, 64]} />
    <instancedMesh key={'n' + pts.length + prof.mode} ref={needles} args={[needleGeo, gold, 64]} />
    {label && <Html position={[((cols - 1) / 2) * 0.5 + 0.35, -prof.needle.length, ((rows - 1) / 2) * 0.5]} style={{ pointerEvents: 'none' }}>
      <span className={'fa-scale-tag fa-scale-tag-' + prof.mode} data-testid="fa-needle-tag">{label}</span>
    </Html>}
    {traces.map((t, i) => <Line key={i} points={t} color={COLORS.gold} lineWidth={1.2} transparent opacity={0.8} />)}
  </group>;
}

function SweatChannels({ rows, cols, reducedMotion, prof }: { rows: number; cols: number; reducedMotion: boolean; prof: ScaleProfile }) {
  const routes = useMemo(() => sweatRoutes(rows, cols), [rows, cols]);
  const rings = useMemo(() => electrodeGrid(rows, cols), [rows, cols]);
  const ringRef = useRef<THREE.InstancedMesh>(null);
  const ringMat = useMemo(() => fadeMat('#9ef6ff', 0.75, { emissive: new THREE.Color(COLORS.cyan), emissiveIntensity: 0.5 }), []);
  useEffect(() => {
    const m = new THREE.Matrix4();
    rings.forEach((p, i) => { m.makeRotationX(Math.PI / 2); m.setPosition(p.x, prof.ringTube, p.z); ringRef.current!.setMatrixAt(i, m); });
    ringRef.current!.count = rings.length; ringRef.current!.instanceMatrix.needsUpdate = true;
  }, [rings, prof]);
  const curves = useMemo(() => routes.map(r => new THREE.CatmullRomCurve3(r.map(([x, z]) => new THREE.Vector3(x, prof.channelRadius, z)), false, 'catmullrom', 0.2)), [routes, prof]);
  const ringGeo = useMemo(() => new THREE.TorusGeometry(0.14, prof.ringTube, 8, 24), [prof]);
  const dots = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (!dots.current) return;
    dots.current.visible = !reducedMotion;
    if (reducedMotion) return;
    dots.current.children.forEach((child, i) => {
      const curve = curves[i % curves.length];
      const t = (clock.elapsedTime * 0.08 + i * 0.137) % 1;
      child.position.copy(curve.getPointAt(t));
    });
  });
  const dotMat = useMemo(() => fadeMat('#c9fbff', 0.95, { emissive: new THREE.Color(COLORS.cyan), emissiveIntensity: 1 }), []);
  const dotGeo = useMemo(() => new THREE.SphereGeometry(prof.dotRadius, 8, 8), [prof]);
  return <group>
    {routes.map((r, i) => <Line key={i} points={r.map(([x, z]) => [x, prof.channelRadius, z] as [number, number, number])} color={COLORS.cyan} lineWidth={2} transparent opacity={0.9} />)}
    <instancedMesh key={rings.length + prof.mode} ref={ringRef} args={[ringGeo, ringMat, 64]} />
    <group ref={dots}>{Array.from({ length: 18 }, (_, i) => <mesh key={i} geometry={dotGeo} material={dotMat} />)}</group>
  </group>;
}

function Electronics({ showLabels }: { showLabels: boolean }) {
  const pinMat = useMemo(goldMat, []);
  const mats = useMemo(() => COMPONENTS.map(c => fadeMat(c.color, c.id === 'battery' ? 0.9 : 1, { metalness: c.id === 'battery' ? 0.6 : 0.2, roughness: 0.4, depthWrite: true })), []);
  return <group>
    {COMPONENTS.map((c, ci) => {
      const mat = mats[ci];
      return <group key={c.id} position={[c.x, c.h / 2, c.z]}>
        <mesh material={mat}><boxGeometry args={[c.w, c.h, c.d]} /></mesh>
        {c.id === 'afe' && Array.from({ length: 10 }, (_, i) => <mesh key={i} material={pinMat} position={[-c.w / 2 + 0.08 + i * 0.105, -c.h / 2 + 0.01, c.d / 2 + 0.03]}><boxGeometry args={[0.04, 0.02, 0.07]} /></mesh>)}
        {showLabels && <Html center distanceFactor={9} position={[0, c.h / 2 + 0.25, 0]} style={{ pointerEvents: 'none' }}>
          <span className="fa-chip-label" aria-hidden="true">{c.label}</span>
        </Html>}
      </group>;
    })}
    {[[-0.6, -0.4, -0.2, -0.6], [-0.6, 0, -0.35, 0.35], [0.45, 0.35, 0.85, 0.4], [0.35, -0.6, 0.85, -0.55], [1.45, 0.4, 1.95, 0.4]].map(([x1, z1, x2, z2], i) =>
      <Line key={i} points={[[x1, 0.002, z1], [x2, 0.002, z2]]} color="#d6b25d" lineWidth={1.5} />)}
    <Line points={serpentine(1.1, 4, 0.08, 0, 40).points.map(([x, z]) => [1.25 + z, 0.002, 0.9 + x * 0.6] as [number, number, number])} color="#d6b25d" lineWidth={1.5} />
  </group>;
}

function Interconnect({ stretch, animate, reducedMotion, prof }: { stretch: number; animate: boolean; reducedMotion: boolean; prof: ScaleProfile }) {
  const lines = useRef<any[]>([]);
  const base = useMemo(() => [-1.6, -0.95, -0.3, 0.35, 1.0, 1.65], []);
  const strainRef = useRef(stretch);
  const initial = useMemo(() => serpentine(4.4, 7, 0.16, 0).points, []);
  useFrame(({ clock }) => {
    const s = animate && !reducedMotion ? 0.2 * (1 - Math.cos(clock.elapsedTime * 1.4)) : stretch;
    if (Math.abs(s - strainRef.current) < 1e-4 && lines.current[0]?.userData.ready) return;
    strainRef.current = s;
    const pts = serpentine(4.4, 7, 0.16, s).points;
    base.forEach((z, i) => {
      const line = lines.current[i];
      if (!line) return;
      const flat: number[] = [];
      pts.forEach(([x, dz]) => flat.push(x, prof.serpentineRadius, z + dz));
      line.geometry.setPositions(flat);
      line.userData.ready = true;
    });
  });
  useEffect(() => { lines.current.forEach(l => { if (l) l.userData.ready = false; }); }, [prof]);
  return <group>
    {base.map((z, i) => <Line key={i} ref={(el: any) => { lines.current[i] = el; }} points={initial.map(([x, dz]) => [x, prof.serpentineRadius, z + dz] as [number, number, number])} color={COLORS.gold} lineWidth={2.4} />)}
  </group>;
}

// ---------------- layer wrapper (position, fade, highlight, picking) ----------------

function LayerGroup({ index0, id, explodeRef, selected, hovered, onSelect, onHover, children, hole = 0, scaleWithStretch, scaleMode }: {
  scaleMode: ScaleMode; index0: number; id: LayerId; explodeRef: React.MutableRefObject<number>; selected: LayerId | null; hovered: LayerId | null;
  onSelect: (id: LayerId) => void; onHover: (id: LayerId | null) => void; children?: ReactNode; hole?: number; scaleWithStretch?: React.MutableRefObject<number>;
}) {
  const g = useMemo(() => layerStack(scaleMode)[index0], [scaleMode, index0]);
  const group = useRef<THREE.Group>(null), slab = useRef<THREE.Mesh>(null);
  const geo = useMemo(() => slabGeometry(g.thickness, hole), [g.thickness, hole]);
  const mat = useMemo(() => fadeMat(g.color, g.opacity, { emissive: new THREE.Color(COLORS.cyan), emissiveIntensity: 0 }), [g.color, g.opacity]);
  const fade = useRef(1);
  const isSel = selected === id, dim = selected !== null && !isSel;
  useFrame((_, dt) => {
    if (!group.current) return;
    group.current.position.y = layerY(index0, explodeRef.current, scaleMode);
    const target = dim ? 0.12 : 1;
    fade.current += (target - fade.current) * Math.min(1, dt * 8);
    group.current.traverse(o => {
      const m = (o as THREE.Mesh).material as THREE.MeshStandardMaterial | undefined;
      if (m && m.userData && typeof m.userData.baseOpacity === 'number') m.opacity = m.userData.baseOpacity * fade.current;
      else if (m && (o as any).isLine2) { m.transparent = true; (m as any).opacity = 0.9 * fade.current; }
    });
    mat.emissiveIntensity += ((isSel ? 0.35 : hovered === id ? 0.15 : 0) - mat.emissiveIntensity) * Math.min(1, dt * 10);
    if (scaleWithStretch && slab.current) slab.current.scale.x = 1 + scaleWithStretch.current;
  });
  const click = (e: ThreeEvent<MouseEvent>) => { e.stopPropagation(); if (e.delta > 6) return; onSelect(id); };
  return <group ref={group} name={id} onClick={click}
    onPointerOver={e => { e.stopPropagation(); onHover(id); }} onPointerOut={() => onHover(null)}>
    <mesh ref={slab} geometry={geo} material={mat} renderOrder={index0}>
      <Edges threshold={30} color={isSel ? COLORS.cyan : '#3d7ea6'} />
    </mesh>
    <group position={[0, g.thickness, 0]}>{children}</group>
  </group>;
}

function StackModel(p: SceneProps & { explodeRef: React.MutableRefObject<number> }) {
  const hovered = useRef<LayerId | null>(null);
  const hoverState = useHover();
  const onHover = (id: LayerId | null) => { hovered.current = id; hoverState.set(id); document.body.style.cursor = id ? 'pointer' : ''; };
  useEffect(() => () => { document.body.style.cursor = ''; }, []);
  const stretchScale = useRef(0);
  useFrame(({ clock }) => { stretchScale.current = (p.animateStretch && !p.reducedMotion ? 0.2 * (1 - Math.cos(clock.elapsedTime * 1.4)) : p.stretch) * (4.4 / FOOTPRINT.width); });
  const prof = SCALE_PROFILES[p.scaleMode];
  const readout = scaleReadout(p.scaleMode);
  const needleLabel = p.mode !== 'stack' ? null : p.scaleMode === 'presentation'
    ? `Not to scale: needles drawn ${readout.renderedNeedleMm} mm = ${readout.needleExaggeration}× the ${readout.candidateNeedleUm} µm candidate`
    : `Candidate needle ${readout.candidateNeedleUm} µm (unvalidated) · drawn to scale`;
  const common = { scaleMode: p.scaleMode, explodeRef: p.explodeRef, selected: p.selected, hovered: hoverState.value, onSelect: (id: LayerId) => p.onSelect(id), onHover };
  const content: Record<LayerId, ReactNode> = {
    'protective-film': <FilmDetails prof={prof} />,
    'microneedle-array': <ElectrodeArray rows={p.grid.rows} cols={p.grid.cols} prof={prof} label={needleLabel} />,
    'sweat-management': <SweatChannels rows={p.grid.rows} cols={p.grid.cols} reducedMotion={p.reducedMotion} prof={prof} />,
    'flex-electronics': <Electronics showLabels={p.selected === 'flex-electronics'} />,
    'stretchable-interconnect': <Interconnect stretch={p.stretch} animate={p.animateStretch} reducedMotion={p.reducedMotion} prof={prof} />,
    'adhesive-frame': null,
  };
  return <group>
    {LAYERS.map((l, i) => p.visible[l.id] && <LayerGroup key={l.id} index0={i} id={l.id} {...common}
      hole={l.id === 'adhesive-frame' ? 0.8 : 0} scaleWithStretch={l.id === 'stretchable-interconnect' ? stretchScale : undefined}>
      {content[l.id]}
      {p.mode === 'stack' && <Html position={[FOOTPRINT.width / 2 + 0.45, 0, -FOOTPRINT.depth / 2 + 0.6]} center style={{ pointerEvents: 'none' }}>
        <span aria-hidden="true" className={'fa-badge' + (p.selected === l.id ? ' is-on' : '')}>{l.index}</span>
      </Html>}
    </LayerGroup>)}
  </group>;
}

// small hover state helper that triggers re-render only on change
function useHover() { const [value, set] = useState<LayerId | null>(null); return { value, set }; }

// ---------------- skin cross-section ----------------
const UM = 1 / 120; // 1 scene unit = 120 µm in the cross-section
function SkinSection({ needleUm }: { needleUm: number }) {
  const width = 7, depth = 3.2;
  let y = 0;
  const blocks = SKIN_LAYERS.map(l => {
    const shown = l.id === 'dermis' ? 2.4 : l.id === 'fat' ? 0.9 : Math.max(0.06, l.thicknessUm * UM);
    const b = { ...l, top: y, h: shown, truncated: l.id === 'dermis' || l.id === 'fat' };
    y -= shown;
    return b;
  });
  const gold = useMemo(goldMat, []);
  const h = needleUm * UM;
  const needles = [-2.2, -1.1, 0, 1.1, 2.2];
  return <group>
    {blocks.map(b => <mesh key={b.id} position={[0, b.top - b.h / 2, 0]}>
      <boxGeometry args={[width, b.h, depth]} />
      <meshStandardMaterial color={b.color} roughness={0.85} transparent opacity={b.id === 'sc' ? 0.7 : 0.5} depthWrite={false} />
      <Html position={[width / 2 + 0.2, 0, depth / 2]} style={{ pointerEvents: 'none' }}>
        <span className="fa-skin-label">{b.label}<small>{b.truncated ? '~' + b.thicknessUm + ' µm · truncated' : '~' + b.thicknessUm + ' µm'}</small></span>
      </Html>
    </mesh>)}
    {/* patch substrate and needles above the surface, tip at nominal length */}
    <mesh position={[0, 0.5 + 0.06, 0]}><boxGeometry args={[width - 0.6, 0.12, depth - 0.6]} /><meshStandardMaterial color={COLORS.substrate} transparent opacity={0.55} /></mesh>
    {needles.map(x => <group key={x}>
      <mesh material={gold} position={[x, 0.5 - (0.5 + h) / 2, depth / 2 - 0.35]} renderOrder={2}><cylinderGeometry args={[0.025, 30 * UM * 1.2, 0.5 + h, 20]} /></mesh>
    </group>)}
    <Line points={[[-width / 2, -h, depth / 2 + 0.01], [width / 2, -h, depth / 2 + 0.01]]} color={COLORS.cyan} lineWidth={1.5} dashed dashSize={0.15} gapSize={0.1} />
    <Html position={[-width / 2, -h - 0.05, depth / 2]} style={{ pointerEvents: 'none' }}>
      <span className="fa-skin-tip">Nominal tip at {needleUm} µm (no skin deformation) — not a penetration measurement</span>
    </Html>
  </group>;
}

// ---------------- thigh attachment ----------------
function ThighModel({ rows, cols }: { rows: number; cols: number }) {
  const rTop = 1.65, rBot = 1.2, len = 7;
  const r = (yy: number) => (rTop + rBot) / 2 + yy * ((rTop - rBot) / len);
  const patchH = 1.28, theta = 0.96 / 1.44;
  const gold = useMemo(goldMat, []);
  const dots = useMemo(() => {
    const out: [number, number, number][] = [];
    for (let i = 0; i < rows; i++) for (let j = 0; j < cols; j++) {
      const yy = ((i - (rows - 1) / 2) / Math.max(1, rows - 1)) * patchH * 0.62;
      const th = ((j - (cols - 1) / 2) / Math.max(1, cols - 1)) * theta * 0.62;
      const rr = r(yy) + 0.035;
      out.push([rr * Math.sin(th), yy, rr * Math.cos(th)]);
    }
    return out;
  }, [rows, cols]);
  return <group rotation={[0, 0, Math.PI / 2]}>
    <mesh><cylinderGeometry args={[rTop, rBot, len, 64, 1, true]} /><meshStandardMaterial color={COLORS.skin} roughness={0.75} transparent opacity={0.88} side={THREE.DoubleSide} /></mesh>
    <mesh position={[0, -len / 2, 0]}><sphereGeometry args={[rBot * 1.02, 40, 20]} /><meshStandardMaterial color={COLORS.skin} roughness={0.8} transparent opacity={0.88} /></mesh>
    <mesh><cylinderGeometry args={[r(patchH / 2) + 0.012, r(-patchH / 2) + 0.012, patchH, 40, 1, true, -theta / 2, theta]} /><meshStandardMaterial color={COLORS.adhesive} transparent opacity={0.85} side={THREE.DoubleSide} /></mesh>
    <mesh><cylinderGeometry args={[r(patchH / 2) + 0.025, r(-patchH / 2) + 0.025, patchH * 0.78, 40, 1, true, -theta * 0.39, theta * 0.78]} /><meshStandardMaterial color={COLORS.substrate} transparent opacity={0.75} side={THREE.DoubleSide} emissive={COLORS.cyan} emissiveIntensity={0.15} /></mesh>
    {dots.map((d, i) => <mesh key={i} position={d} material={gold}><sphereGeometry args={[0.022, 10, 8]} /></mesh>)}
    <Html position={[0.2, 0, r(0) + 0.4]} style={{ pointerEvents: 'none' }}>
      <span className="fa-skin-tip">Candidate placement: anterior thigh (quadriceps). Placement protocol pending.</span>
    </Html>
  </group>;
}

// ---------------- camera rig ----------------
function Rig({ mode, reducedMotion, apiRef, minDistance, maxDistance, maxPolarAngle = Math.PI }: { mode: ViewMode; reducedMotion: boolean; apiRef: React.MutableRefObject<SceneApi | null>; minDistance: number; maxDistance: number; maxPolarAngle?: number }) {
  const controls = useRef<any>(null);
  const { camera, size } = useThree();
  const goal = useRef<{ position: THREE.Vector3; target: THREE.Vector3 } | null>(null);
  // Responsive framing only (geometry untouched): pull the camera back on narrow / portrait viewports so the whole patch fits.
  const fit = () => { const aspect = size.width / Math.max(1, size.height); return aspect >= 1.35 ? 1 : Math.min(2.4, Math.max(1, Math.pow(1.35 / aspect, 0.55))); };
  const goTo = (m: ViewMode) => {
    const c = CAMERAS[m], t = new THREE.Vector3(...c.target), p = new THREE.Vector3(...c.position).sub(t).multiplyScalar(fit()).add(t);
    if (p.distanceTo(t) > maxDistance) p.sub(t).setLength(maxDistance).add(t);
    flyTo(p.toArray() as [number, number, number], c.target);
  };
  const flyTo = (position: [number, number, number], target: [number, number, number]) => {
    goal.current = { position: new THREE.Vector3(...position), target: new THREE.Vector3(...target) };
    if (reducedMotion) { camera.position.copy(goal.current.position); controls.current?.target.copy(goal.current.target); controls.current?.update(); goal.current = null; }
  };
  useEffect(() => { goTo(mode); }, [mode, size.width > size.height]); // eslint-disable-line react-hooks/exhaustive-deps
  useFrame((_, dt) => {
    if (!goal.current || !controls.current) return;
    const k = Math.min(1, dt * 4);
    camera.position.lerp(goal.current.position, k);
    controls.current.target.lerp(goal.current.target, k);
    controls.current.update();
    if (camera.position.distanceTo(goal.current.position) < 0.02) goal.current = null;
  });
  const orbit = (dAz: number, dPol: number) => {
    const c = controls.current; if (!c) return; goal.current = null;
    const offset = camera.position.clone().sub(c.target);
    const sph = new THREE.Spherical().setFromVector3(offset);
    sph.theta += dAz; sph.phi = Math.max(0.08, Math.min(Math.min(Math.PI - 0.08, maxPolarAngle), sph.phi + dPol));
    camera.position.copy(c.target).add(new THREE.Vector3().setFromSpherical(sph)); c.update();
  };
  useImperativeHandle(apiRef, () => ({
    resetCamera: () => goTo(mode),
    rotate: d => orbit(d, 0),
    tilt: d => orbit(0, d),
    zoom: f => {
      const c = controls.current; if (!c) return; goal.current = null;
      const offset = camera.position.clone().sub(c.target);
      offset.setLength(Math.min(maxDistance, clampDistance(offset.length() * f, minDistance))); camera.position.copy(c.target).add(offset); c.update();
    },
    focus: (position, target) => flyTo(position, target),
  }));
  return <OrbitControls ref={controls} makeDefault enableDamping={!reducedMotion} dampingFactor={0.08} minDistance={minDistance} maxDistance={maxDistance} maxPolarAngle={maxPolarAngle}
    target={CAMERAS.stack.target} onStart={() => { goal.current = null; }} />;
}

function ExplodeDriver({ exploded, reducedMotion, explodeRef, onProgress }: { exploded: boolean; reducedMotion: boolean; explodeRef: React.MutableRefObject<number>; onProgress: (v: number) => void }) {
  const last = useRef(-1);
  useFrame((_, dt) => {
    const target = exploded ? 1 : 0;
    if (reducedMotion) explodeRef.current = target;
    else { const d = target - explodeRef.current; explodeRef.current = Math.abs(d) < 0.002 ? target : explodeRef.current + d * Math.min(1, Math.min(dt, 1 / 20) * 3.2); } // capped step: smooth even on slow devices
    const rounded = Math.round(explodeRef.current * 100) / 100;
    if (rounded !== last.current) { last.current = rounded; onProgress(rounded); }
  });
  return null;
}

function Holo() {
  return <group position={[0, -0.02, 0]}>
    {[3.6, 4.6, 5.6].map((r, i) => <mesh key={r} rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[r, r + 0.02 + i * 0.01, 96]} /><meshBasicMaterial color={COLORS.cyan} transparent opacity={0.28 - i * 0.07} /></mesh>)}
    <gridHelper args={[16, 32, '#0f3146', '#0b2236']} position={[0, -0.01, 0]} />
  </group>;
}

export const FlexArrayScene = forwardRef<SceneApi | null, SceneProps>(function FlexArrayScene(props, ref) {
  const apiRef = useRef<SceneApi | null>(null);
  useImperativeHandle(ref, () => ({
    resetCamera: () => apiRef.current?.resetCamera(), rotate: d => apiRef.current?.rotate(d),
    tilt: d => apiRef.current?.tilt(d), zoom: f => apiRef.current?.zoom(f), focus: (a, b) => apiRef.current?.focus(a, b),
  }));
  const explodeRef = useRef(props.exploded ? 1 : 0);
  const showStack = props.mode === 'stack' || props.mode === 'top';
  return <Canvas
    camera={{ position: CAMERAS.stack.position, fov: CAMERA_DEFAULT.fov, near: 0.1, far: 200 }}
    dpr={props.environment === 'bay' ? [1, 1.5] : [1, 2]} gl={{ // bay: cap pixel ratio to keep retina frame rates high
      antialias: true, preserveDrawingBuffer: true, alpha: true }}
    onCreated={({ gl }) => {
      gl.setClearColor(0x000000, 0);
      gl.domElement.addEventListener('webglcontextlost', e => { e.preventDefault(); props.onContextLost(); }, { once: true });
    }}
    onPointerMissed={() => props.onSelect(null)}
    style={{ touchAction: 'none' }}
  >
    <ambientLight intensity={0.55} />
    <hemisphereLight args={['#bfefff', '#0a1424', 0.6]} />
    <directionalLight position={[6, 10, 6]} intensity={1.6} />
    <pointLight position={[-6, 4, -4]} intensity={40} color={COLORS.cyan} />
    <pointLight position={[5, 2, 6]} intensity={18} color="#ffd9a0" />
    {props.environment === 'bay' && <FlexArrayEnvironment quality={props.quality ?? 'full'} reducedMotion={props.reducedMotion} />}
    <ExplodeDriver exploded={props.exploded && props.mode === 'stack'} reducedMotion={props.reducedMotion} explodeRef={explodeRef} onProgress={props.onProgress} />
    {showStack && <StackModel {...props} explodeRef={explodeRef} />}
    {showStack && <Holo />}
    {props.mode === 'skin' && <SkinSection needleUm={props.needleUm} />}
    {props.mode === 'thigh' && <ThighModel rows={props.grid.rows} cols={props.grid.cols} />}
    <Rig mode={props.mode} reducedMotion={props.reducedMotion} apiRef={apiRef} minDistance={props.mode === 'stack' || props.mode === 'top' ? SCALE_PROFILES[props.scaleMode].minDistance : 4}
      maxDistance={props.environment === 'bay' ? BAY.maxCameraDistance : 60} maxPolarAngle={props.environment === 'bay' ? BAY.maxPolarAngle : Math.PI} />
  </Canvas>;
});
