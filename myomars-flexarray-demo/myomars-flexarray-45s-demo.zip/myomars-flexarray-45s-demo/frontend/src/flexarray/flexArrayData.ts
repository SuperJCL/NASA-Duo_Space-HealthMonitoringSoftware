// ASTRA FlexArray-MN V2.1 — engineering specification data.
// Pure data + helpers: no React, no Three.js. Presentation components read from here.
// Nothing in this file is a validated device specification.

export const DISCLAIMER = 'Conceptual engineering design — not manufactured, clinically validated, or flight-qualified.';
export const MODEL_VERSION = 'FlexArray-MN V2.1';

/** A. conventional sEMG measurement settings · B. proposed device targets · C. claims that need evidence. */
export type ParameterCategory = 'A' | 'B' | 'C';
export type ValidationStatus = 'established-practice' | 'proposed-target' | 'pending-validation';

export const CATEGORY_LABELS: Record<ParameterCategory, string> = {
  A: 'Established Measurement Parameters',
  B: 'Proposed Engineering Targets',
  C: 'Pending Validation',
};
export const CATEGORY_NOTES: Record<ParameterCategory, string> = {
  A: 'Conventional sEMG acquisition/analysis settings. Common practice — not proof that this patch meets them.',
  B: 'Design intent for the prototype. Not built, not measured.',
  C: 'Claims that require bench, human-subject, and environmental testing before they can be stated.',
};
export const STATUS_LABELS: Record<ValidationStatus, string> = {
  'established-practice': 'Established practice',
  'proposed-target': 'Proposed target',
  'pending-validation': 'Pending validation',
};

export type Parameter = {
  id: string;
  label: string;
  value: string;
  unit: string;
  category: ParameterCategory;
  rationale: string;
  source_id: string | null;
  validation_status: ValidationStatus;
};

export type ReferenceVerification = 'verified' | 'pending';
export type Reference = {
  id: string;
  topic: string;
  title: string;
  authors: string;
  venue: string;
  year: number | null;
  doi: string | null;
  url: string | null;
  verification: ReferenceVerification;
  summary: string;
  relevance: string;
};

export type LayerId = 'protective-film' | 'microneedle-array' | 'sweat-management' | 'flex-electronics' | 'stretchable-interconnect' | 'adhesive-frame';

export type Layer = {
  id: LayerId;
  index: number; // 1 = outermost (away from skin), 6 = skin-facing
  shortName: string;
  name: string;
  purpose: string;
  material: string;
  rationale: string;
  evidence: { source_id: string; note: string }[];
  limitations: string[];
  validation_status: ValidationStatus;
  validation_summary: string;
  parameters: Parameter[];
};

const p = (id: string, label: string, value: string, unit: string, category: ParameterCategory, rationale: string, source_id: string | null = null): Parameter => ({
  id, label, value, unit, category, rationale, source_id,
  validation_status: category === 'A' ? 'established-practice' : category === 'B' ? 'proposed-target' : 'pending-validation',
});

/** System-wide research settings (shared across layers; shown in the KPI strip). */
export const SYSTEM_PARAMETERS: Parameter[] = [
  p('semg-fs', 'sEMG sampling rate', '2000', 'Hz / channel', 'A', 'At least 2× the 500 Hz upper analysis band edge, with margin for anti-alias filter roll-off.', 'ref-seniam'),
  p('semg-band', 'sEMG analysis band', '20–500', 'Hz', 'A', 'Typical surface EMG band; the 20 Hz high-pass reduces motion artifact.', 'ref-seniam'),
  p('rms-window', 'RMS window', '500', 'ms', 'A', 'Analysis window for amplitude trends. This is a processing setting, not a hardware property.', null),
  p('adc-res', 'ADC resolution', '16', 'bit', 'B', 'Proposed resolution, giving dynamic range for µV-level signals plus offset. Noise floor not yet characterized.', null),
  p('imu', 'IMU', '6-axis, 100', 'Hz', 'B', 'Accelerometer + gyroscope for motion context and artifact flagging. Proposed, not integrated.', null),
  p('grid', 'Electrode grid', '8 × 8', 'candidate sites', 'B', '64 electrode sites. Independent recording channels depend on AFE channel count, referencing scheme, and spatial correlation. Not 64 by default.', null),
  p('runtime', 'EVA runtime', '≥ 8', 'h (design target)', 'B', 'Covers a long EVA plus margin. Battery capacity and power budget not yet measured.', null),
];

export const LAYERS: Layer[] = [
  {
    id: 'protective-film', index: 1, shortName: 'Protective film', name: 'Protective & Breathable Film',
    purpose: 'Outer membrane that shields the electronics from abrasion and suit-interior contact while allowing water vapor to escape.',
    material: 'Concept: microporous breathable elastomer membrane (e.g., thin polyurethane-class film) with conformal sealing over the electronics region.',
    rationale: 'Trapped sweat raises skin hydration and can degrade adhesion and electrode stability over long wear. A vapor-permeable cover is the proposed mitigation.',
    evidence: [{ source_id: 'ref-nasa-monitoring', note: 'NASA spinoff precedent identifying electrode contact and sweat/motion artifacts as practical wearable EMG problems.' }],
    limitations: ['Vapor transmission rate not measured.', 'Not tested against suit liquid-cooling garment interface.', 'No EMI shielding performance data.'],
    validation_status: 'proposed-target',
    validation_summary: 'Material concept only. No sample fabricated or tested.',
    parameters: [
      p('film-thickness', 'Film thickness', '20–50', 'µm', 'B', 'Thin enough to stay conformal, thick enough to handle. Proposed range.'),
      p('film-mvtr', 'Moisture vapor transmission', 'TBD', 'g/m²/day', 'C', 'Needs a standardized permeability test before any breathability claim.'),
      p('film-protection', 'Electronics ingress protection', 'TBD', '—', 'C', 'Sweat/condensate ingress protection not evaluated.'),
    ],
  },
  {
    id: 'microneedle-array', index: 2, shortName: 'Microneedle array', name: 'Microneedle Microelectrode Array (MN-sEMG)',
    purpose: 'Configurable grid of gold-coated microneedle electrodes intended to contact below the stratum corneum to lower skin–electrode impedance.',
    material: 'Concept: biocompatible polymer microneedles with gold (Au) conductive coating on a flexible polyimide-class substrate; conductive polymer interface under study.',
    rationale: 'Dry surface electrodes on unprepared skin show high, drifting impedance. Microneedle electrodes are a research direction reported to reduce contact impedance. Benefit for this design is unproven.',
    evidence: [
      { source_id: 'ref-bb-2025', note: 'Microneedle EMG electrode research (Biosensors and Bioelectronics, 2025).' },
      { source_id: 'ref-npj-2025', note: 'Tunable-stiffness microneedle electrode (npj Flexible Electronics, 2025): EMG recorded in volunteers with ~800 µm needles, a different geometry from this concept.' },
    ],
    limitations: [
      'Needle geometry below is a research-stage candidate, not a fabricated design.',
      'Penetration depth has not been measured; skin deforms on insertion, so needle length ≠ penetration depth.',
      'Skin safety, infection risk, sterility, and biocompatibility not evaluated.',
      'An 8 × 8 grid gives 64 electrode sites, not automatically 64 independent channels.',
      'The V2.1 stack order puts this layer above layers 3–6. Needles must pass through aligned apertures to reach skin; that alignment is not yet engineered.',
    ],
    validation_status: 'pending-validation',
    validation_summary: 'Geometry, impedance, and SNR benefits all pending. No human-subject testing.',
    parameters: [
      p('mn-grid', 'Electrode grid', '8 × 8', 'candidate sites', 'B', 'Configurable (4 × 4 to 8 × 8). Channel count depends on the AFE and referencing.'),
      p('mn-pitch', 'Inter-electrode pitch', '5.0 (range 3–10)', 'mm', 'B', 'Candidate spacing for HD-sEMG-style spatial sampling over the thigh.'),
      p('mn-length', 'Needle length (candidate)', '200 (range 100–300)', 'µm', 'B', 'Research-stage candidate intended to pass the stratum corneum without reaching deep dermis. No cited study validates this value.'),
      p('mn-diameter', 'Needle base diameter (candidate)', '60 (range 30–80)', 'µm', 'B', 'Candidate value only.'),
      p('mn-depth', 'Penetration depth', 'Not measured', '—', 'C', 'Requires imaging/histology-based measurement under controlled insertion force.'),
      p('mn-impedance', 'Contact impedance reduction', 'Not measured', '—', 'C', 'Must be compared against conventional Ag/AgCl gel and dry electrodes on matched sites.', 'ref-bb-2025'),
      p('mn-snr', 'SNR improvement vs. conventional', 'Not established', 'dB', 'C', 'Earlier concept graphics showed “6–10 dB”. That figure is unsupported and withdrawn until measured.'),
      p('mn-safety', 'Skin safety / biocompatibility', 'Not evaluated', '—', 'C', 'Needs biocompatibility assessment and ethics-approved human testing.'),
    ],
  },
  {
    id: 'sweat-management', index: 3, shortName: 'Sweat management', name: 'Sweat Management Layer',
    purpose: 'Proposed microfluidic channel network that routes sweat away from electrode sites toward peripheral evaporation/absorption zones.',
    material: 'Concept: soft elastomer (PDMS-class) microchannel layer with hydrophilic channel walls and hydrophobic isolation rings around each electrode opening.',
    rationale: 'Sweat bridging between adjacent electrodes can short-circuit or blur spatial signals and shift baselines. Isolation rings are intended to keep each contact electrically separate.',
    evidence: [{ source_id: 'ref-nasa-monitoring', note: 'Sweat-related artifacts identified as a wearable EMG challenge.' }],
    limitations: ['Channel routing is a conceptual layout, not a fluid simulation.', 'Wicking rate and capacity under EVA sweat rates unknown.', 'Signal drift reduction (<10 % target) not demonstrated.'],
    validation_status: 'pending-validation',
    validation_summary: 'Routing concept only; flow and electrical isolation untested.',
    parameters: [
      p('sw-channel', 'Channel width', '100–300', 'µm', 'B', 'Proposed capillary-scale channels.'),
      p('sw-isolation', 'Electrode isolation ring', 'Hydrophobic annulus per site', '—', 'B', 'Intended to prevent sweat bridges between adjacent electrodes.'),
      p('sw-drift', 'Signal drift under sweating', '< 10 % (target)', 'of baseline RMS', 'C', 'Target only; needs controlled sweating protocol.'),
    ],
  },
  {
    id: 'flex-electronics', index: 4, shortName: 'Flexible electronics', name: 'Flexible Electronics',
    purpose: 'Acquire, condition, digitize, timestamp and wirelessly transmit sEMG and motion data.',
    material: 'Concept: flexible polyimide PCB islands carrying rigid ICs, joined by stretchable interconnects (Layer 5).',
    rationale: 'Keeping the AFE close to the electrodes shortens high-impedance leads and reduces motion-induced cable artifact. The battery is shown at a conceptual position only.',
    evidence: [{ source_id: 'ref-nasa-delsys', note: 'NASA-supported wireless EMG sensor development precedent.' }],
    limitations: ['No schematic, power budget, or thermal analysis yet.', 'Wireless link not evaluated inside a pressurized suit.', 'Battery chemistry/safety for suit use not assessed.'],
    validation_status: 'proposed-target',
    validation_summary: 'Block-level architecture only.',
    parameters: [
      p('fe-afe', 'Analog front end', 'Multi-channel biopotential AFE', '—', 'B', 'Instrumentation amplification + band-pass for 20–500 Hz. Channel count TBD; it sets how many electrode sites are recorded at once.', 'ref-seniam'),
      p('fe-adc', 'ADC', '16', 'bit', 'B', 'Proposed. Effective resolution depends on noise; not measured.'),
      p('fe-fs', 'Sampling', '2000', 'Hz / channel', 'A', 'Conventional setting for a 20–500 Hz band.', 'ref-seniam'),
      p('fe-imu', 'IMU', '6-axis, 100', 'Hz', 'B', 'Motion context and artifact flagging.'),
      p('fe-mcu', 'Microcontroller', 'Low-power MCU', '—', 'B', 'Timestamping, buffering, quality flags. No on-patch diagnosis.'),
      p('fe-radio', 'Wireless link', 'Low-energy radio (concept)', '—', 'B', 'Link budget and suit RF environment not studied.'),
      p('fe-battery', 'Battery placement', 'Peripheral, conceptual', '—', 'B', 'Placed away from electrodes in the model. Capacity not sized.'),
      p('fe-runtime', 'Runtime', '≥ 8', 'h (target)', 'B', 'Design target pending a measured power budget.'),
    ],
  },
  {
    id: 'stretchable-interconnect', index: 5, shortName: 'Stretchable interconnect', name: 'Stretchable Interconnect',
    purpose: 'Serpentine conductive traces that let the patch stretch with muscle and skin while keeping electrical continuity.',
    material: 'Concept: serpentine metal (Cu/Au) traces encapsulated in a soft elastomer substrate.',
    rationale: 'Serpentine geometry converts in-plane strain into trace unbending/rotation, lowering peak strain in the conductor. The animation shows this straightening behavior.',
    evidence: [{ source_id: 'ref-nasa-techport-6447', note: 'NASA-funded flexible/stretchable wearable sensor materials precedent (not this design).' }],
    limitations: ['Stretch animation is illustrative kinematics, not FEA.', 'Fatigue life (≥ 5,000 cycles target) not tested.', 'Resistance change under strain not measured.'],
    validation_status: 'pending-validation',
    validation_summary: 'Geometry concept; no mechanical testing.',
    parameters: [
      p('si-stretch', 'Stretchability', '30–50', '% strain (target)', 'B', 'Covers typical skin strain over the thigh during flexion, with margin.'),
      p('si-cycles', 'Cyclic durability', '≥ 5,000', 'cycles (target)', 'C', 'Needs cyclic tensile testing with in-situ resistance monitoring.'),
      p('si-width', 'Trace width', '50–100', 'µm', 'B', 'Proposed.'),
    ],
  },
  {
    id: 'adhesive-frame', index: 6, shortName: 'Adhesive frame', name: 'Skin-Friendly Adhesive Frame',
    purpose: 'Peripheral adhesive ring that holds the patch to the thigh while leaving the electrode field free for skin contact.',
    material: 'Concept: medical-grade silicone gel or acrylic adhesive on a breathable carrier, perimeter-only.',
    rationale: 'Perimeter-only adhesion keeps the adhesive away from the electrode field, so the electrodes keep direct skin contact. It also limits the adhesive area that has to come off after a long wear.',
    evidence: [{ source_id: 'ref-nasa-monitoring', note: 'Practical wearable EMG experience on electrode contact maintenance.' }],
    limitations: ['Adhesion under suit pressure/temperature and sweat not tested.', 'Skin irritation over 8 h wear not evaluated.', 'Placement protocol on the thigh not defined.'],
    validation_status: 'pending-validation',
    validation_summary: 'Concept only; wear testing required.',
    parameters: [
      p('ad-width', 'Frame border width', '6–10', 'mm', 'B', 'Proposed perimeter band.'),
      p('ad-wear', 'Wear duration', '≥ 8', 'h (target)', 'B', 'Matches EVA runtime target.'),
      p('ad-skin', 'Skin tolerance', 'Not evaluated', '—', 'C', 'Requires irritation/sensitization assessment.'),
      p('ad-placement', 'Placement site', 'Anterior thigh (candidate)', '—', 'B', 'Quadriceps region selected for EVA locomotion relevance; protocol pending.'),
    ],
  },
];

// Reference metadata. Only entries confirmed against publisher / DOI / agency pages are marked 'verified'.
export const REFERENCES: Reference[] = [
  // Verified 2026-11-14 against Crossref, PubMed (PMID 40929786), nature.com, spinoff.nasa.gov, techport.nasa.gov API.
  {
    id: 'ref-bb-2025', topic: 'Microneedle EMG electrodes (review)', title: 'Microneedle electrodes for electromyography',
    authors: 'Krieger KJ, Lijnse TM, Lowery MM, O’Cearbhaill ED', venue: 'Biosensors and Bioelectronics 290:117945', year: 2025,
    doi: '10.1016/j.bios.2025.117945', url: 'https://doi.org/10.1016/j.bios.2025.117945', verification: 'verified',
    summary: 'Review of theory, fabrication and recording performance of dry microneedle sEMG electrodes. The abstract reports lower contact impedance and long-term stability, and says they could potentially improve SNR. Being a review, it summarizes earlier studies. One author discloses microneedle patents/equity.',
    relevance: 'Motivates the Layer 2 microneedle approach. It does not validate this design’s geometry or depth.',
  },
  {
    id: 'ref-npj-2025', topic: 'Tunable-stiffness microneedle electrode', title: 'Modulus-adjustable and mechanically adaptive dry microneedle electrodes for personalized electrophysiological recording',
    authors: 'Zhou C, Yao G, Gan X, et al. (15 authors)', venue: 'npj Flexible Electronics 9:77', year: 2025,
    doi: '10.1038/s41528-025-00458-9', url: 'https://www.nature.com/articles/s41528-025-00458-9', verification: 'verified',
    summary: 'PEDOT:PSS-coated shape-memory-polymer microneedles (~800 ± 50 µm tall) that soften near 37 °C; modulus tunable 88.2 → 1.98 MPa. Reports 1.2 kΩ at 10 Hz vs 2.5 kΩ for Ag/AgCl gel. EMG/ECG/EEG recorded in 5 volunteers. Penetration shown only qualitatively on animal skin; depth not measured.',
    relevance: 'Shows flexible microneedle EMG is feasible. Its ~800 µm needles differ from this concept’s 100–300 µm candidate.',
  },
  {
    id: 'ref-nasa-delsys', topic: 'NASA wearable EMG', title: 'Electrical Body Signals Help Researchers Restore Movement and More',
    authors: 'NASA Spinoff', venue: 'NASA Spinoff', year: 2022, doi: null,
    url: 'https://spinoff.nasa.gov/Electrical-Body-Signals-Help-Researchers-Restore-Movement-and-More', verification: 'verified',
    summary: 'Delsys wireless EMG sensors, rooted in early Johnson Space Center SBIR contracts, now used in prosthetics and paralysis research.',
    relevance: 'Precedent for wearable wireless EMG. Does not involve microneedles.',
  },
  {
    id: 'ref-nasa-monitoring', topic: 'NASA wearable EMG', title: 'Monitoring on the Move',
    authors: 'NASA Spinoff', venue: 'NASA Spinoff 2000', year: 2000, doi: null,
    url: 'https://spinoff.nasa.gov/spinoff2000/hm2.htm', verification: 'verified',
    summary: 'Delsys MyoMonitor: a wearable, battery-powered 4-channel EMG system developed with Johnson Space Center SBIR funding.',
    relevance: 'Early NASA-linked portable EMG precedent. Does not involve microneedles.',
  },
  {
    id: 'ref-nasa-techport-6447', topic: 'NASA flexible sensors', title: 'Lightweight, Wearable Metal Rubber-Textile Sensor for In-Situ Lunar Autonomous Health Monitoring, Phase II',
    authors: 'NASA TechPort project 6447 (NanoSonic; JSC lead)', venue: 'NASA TechPort', year: 2009, doi: null,
    url: 'https://techport.nasa.gov/projects/6447', verification: 'verified',
    summary: 'SBIR Phase II (2007–2009, completed): garments with Metal Rubber sheet/fabric sensors and electrodes for astronaut monitoring. Not EMG-specific.',
    relevance: 'Flexible-materials precedent only. Not patch qualification.',
  },
  {
    id: 'ref-seniam', topic: 'sEMG acquisition practice', title: 'Development of recommendations for SEMG sensors and sensor placement procedures',
    authors: 'Hermens HJ, Freriks B, Disselhorst-Klug C, Rau G', venue: 'Journal of Electromyography and Kinesiology 10(5):361–374', year: 2000,
    doi: '10.1016/S1050-6411(00)00027-4', url: 'https://doi.org/10.1016/S1050-6411(00)00027-4', verification: 'verified',
    summary: 'SENIAM recommendations on sEMG sensors and sensor placement.',
    relevance: 'Basis for conventional acquisition settings (category A).',
  },
];

// ---------- helpers (unit-tested) ----------

export const layerById = (id: LayerId) => LAYERS.find(l => l.id === id)!;
export const referenceById = (id: string | null) => (id ? REFERENCES.find(r => r.id === id) ?? null : null);
export const parametersByCategory = (params: Parameter[]) =>
  (['A', 'B', 'C'] as ParameterCategory[]).map(category => ({ category, label: CATEGORY_LABELS[category], items: params.filter(x => x.category === category) }));

export type Referencing = 'monopolar' | 'single-differential';
/**
 * Electrode sites vs. channels. Independence is never implied: the result is an
 * upper bound on *simultaneously digitized* signals, limited by the AFE channel count.
 */
export function channelEstimate(rows: number, cols: number, referencing: Referencing, afeChannels: number) {
  const sites = rows * cols;
  const derivations = referencing === 'monopolar' ? sites : rows * Math.max(0, cols - 1);
  const digitized = Math.min(derivations, Math.max(0, afeChannels));
  return {
    sites,
    derivations,
    digitized,
    note: `${sites} electrode sites → ${derivations} ${referencing === 'monopolar' ? 'monopolar' : 'single-differential'} derivations → ≤ ${digitized} digitized with a ${afeChannels}-channel AFE. Neighboring signals are spatially correlated (crosstalk, volume conduction), so they are not independent.`,
  };
}
