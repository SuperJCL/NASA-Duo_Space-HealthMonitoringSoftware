// Cinematic Mars EVA preparation bay — an original, fully procedural backdrop (no imported or third-party assets).
// The bay never receives pointer events (raycast disabled), so layer picking on the patch is unaffected.
// It is a backdrop only: not to scale with the patch, which is shown as a magnified holographic display.
import { useEffect, useLayoutEffect, useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { BAY, BAY_SETTINGS, bayProps, type BayQuality, type Vec3 } from './bayLayout';
import { drawFloor, drawHazard, drawMarsLandscape, drawMonitor, makeCanvas } from './bayTextures';

const { room: RM, floorY: F, ceilingY: C } = BAY;
const W = RM.x1 - RM.x0, D = RM.z1 - RM.z0, CX = (RM.x0 + RM.x1) / 2, CZ = (RM.z0 + RM.z1) / 2;
const noRaycast = () => {};

function canvasTexture(w: number, h: number, draw: (ctx: CanvasRenderingContext2D) => void, repeat?: [number, number]) {
  const { canvas, ctx } = makeCanvas(w, h); draw(ctx);
  const t = new THREE.CanvasTexture(canvas); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...repeat); }
  return t;
}

function useBayMaterials() {
  const gl = useThree(s => s.gl);
  return useMemo(() => {
    // Procedural studio environment map, applied ONLY to bay materials (the patch's materials are untouched).
    const pmrem = new THREE.PMREMGenerator(gl);
    const env = pmrem.fromScene(new RoomEnvironment(), 0.04).texture; pmrem.dispose();
    const metal = (color: string, metalness = 0.75, roughness = 0.38, extra: Partial<THREE.MeshStandardMaterialParameters> = {}) =>
      new THREE.MeshStandardMaterial({ color, metalness, roughness, envMap: env, envMapIntensity: 0.5, ...extra });
    return {
      env,
      panel: metal('#2a333d'), panelDark: metal('#131a21', 0.7, 0.5), rib: metal('#3a4552', 0.85, 0.3), trim: metal('#66727e', 0.9, 0.25),
      floor: new THREE.MeshStandardMaterial({ map: canvasTexture(1024, 1024, c => drawFloor(c, 1024, 1024), [7, 7]), metalness: 0.55, roughness: 0.5, envMap: env, envMapIntensity: 0.3 }),
      fabric: new THREE.MeshStandardMaterial({ color: '#bdb8ae', roughness: 0.9, metalness: 0, emissive: '#3a2412', emissiveIntensity: 0.35 }),
      fabricShade: new THREE.MeshStandardMaterial({ color: '#a8a296', roughness: 0.9, metalness: 0 }),
      accent: new THREE.MeshStandardMaterial({ color: '#c96a2c', roughness: 0.6 }),
      visor: metal('#b8862f', 1, 0.12, { envMapIntensity: 1.2 }),
      cyanGlow: new THREE.MeshStandardMaterial({ color: '#0b2a33', emissive: '#4CE4F5', emissiveIntensity: 1.5 }),
      warmGlow: new THREE.MeshStandardMaterial({ color: '#2b1a0c', emissive: '#ffb46b', emissiveIntensity: 1.7 }),
      amberGlow: new THREE.MeshStandardMaterial({ color: '#2b1a0c', emissive: '#ffcf86', emissiveIntensity: 2.2 }),
      white: new THREE.MeshStandardMaterial({ color: '#aeb6be', roughness: 0.55, metalness: 0.25, envMap: env, envMapIntensity: 0.35 }),
      hazard: new THREE.MeshStandardMaterial({ map: canvasTexture(512, 64, c => drawHazard(c, 512, 64), [4, 1]), roughness: 0.6, metalness: 0.3 }),
      glass: new THREE.MeshStandardMaterial({ color: '#9fd8ff', transparent: true, opacity: 0.07, roughness: 0.05, metalness: 0, envMap: env, envMapIntensity: 1, depthWrite: false }),
    };
  }, [gl]);
}
type Mats = ReturnType<typeof useBayMaterials>;

/** Instanced panel wall. axis 'z': wall in the XY plane at z = at; axis 'x': wall in the ZY plane at x = at. span is along the wall. */
function PanelWall({ m, axis, at, span, opening }: { m: Mats; axis: 'x' | 'z'; at: number; span: [number, number]; opening?: { a0: number; a1: number; y0: number; y1: number } }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const pw = 8, ph = 7;
  const cells = useMemo(() => {
    const out: { a: number; y: number }[] = [];
    for (let a = span[0] + pw / 2; a < span[1]; a += pw) for (let y = F + ph / 2; y < C; y += ph) {
      if (opening && a + pw / 2 > opening.a0 && a - pw / 2 < opening.a1 && y + ph / 2 > opening.y0 && y - ph / 2 < opening.y1) continue;
      out.push({ a, y });
    }
    return out;
  }, [span, opening]);
  useLayoutEffect(() => {
    const mtx = new THREE.Matrix4(), q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, axis === 'x' ? Math.PI / 2 : 0, 0)), s = new THREE.Vector3(1, 1, 1);
    cells.forEach((c, i) => ref.current!.setMatrixAt(i, mtx.compose(axis === 'z' ? new THREE.Vector3(c.a, c.y, at) : new THREE.Vector3(at, c.y, c.a), q, s)));
    ref.current!.instanceMatrix.needsUpdate = true;
  }, [cells, axis, at]);
  const geo = useMemo(() => new THREE.BoxGeometry(pw - 0.3, ph - 0.3, 0.8), []);
  const inward = at > 0 ? -1 : 1, mid = (span[0] + span[1]) / 2, len = span[1] - span[0];
  const pos = (y: number, off: number): Vec3 => (axis === 'z' ? [mid, y, at + inward * off] : [at + inward * off, y, mid]);
  const rot: Vec3 = axis === 'z' ? [0, 0, 0] : [0, Math.PI / 2, 0];
  return <group>
    <instancedMesh ref={ref} args={[geo, m.panel, cells.length]} />
    <mesh position={pos(F + 1.2, 0.6)} rotation={rot} material={m.cyanGlow}><boxGeometry args={[len, 0.18, 0.2]} /></mesh>
    <mesh position={pos(C - 3, 0.6)} rotation={rot} material={m.rib}><boxGeometry args={[len, 0.8, 0.9]} /></mesh>
  </group>;
}

function SpaceSuit({ m, p }: { m: Mats; p: Vec3 }) {
  return <group position={p} scale={BAY.suitScale}>
    {/* locker alcove */}
    <mesh position={[0, 12, -3.4]} material={m.panelDark}><boxGeometry args={[11, 24, 0.6]} /></mesh>
    {[-5.4, 5.4].map(x => <mesh key={x} position={[x, 12, -1.6]} material={m.trim}><boxGeometry args={[0.5, 24, 3.6]} /></mesh>)}
    {[-4.9, 4.9].map(x => <mesh key={'g' + x} position={[x, 12, -1.3]} material={m.cyanGlow}><boxGeometry args={[0.14, 22, 0.14]} /></mesh>)}
    <mesh position={[0, 23.6, -1.4]} material={m.warmGlow}><boxGeometry args={[9, 0.2, 0.6]} /></mesh>
    <mesh position={[0, 0.3, -0.5]} material={m.rib}><boxGeometry args={[9, 0.6, 5]} /></mesh>
    {/* stylised suit (original) */}
    {[-1.15, 1.15].map(x => <group key={x}>
      <mesh position={[x, 1.2, 0.3]} material={m.white}><boxGeometry args={[1.7, 1.2, 2.6]} /></mesh>
      <mesh position={[x, 5.2, 0]} material={m.fabric}><capsuleGeometry args={[1.05, 5.2, 6, 12]} /></mesh>
      <mesh position={[x, 5.3, 0.05]} rotation={[Math.PI / 2, 0, 0]} material={m.fabricShade}><torusGeometry args={[1.08, 0.12, 6, 16]} /></mesh>
    </group>)}
    <mesh position={[0, 11.4, 0]} material={m.fabric}><capsuleGeometry args={[2.5, 3.2, 8, 16]} /></mesh>
    <mesh position={[0, 11.6, 2.25]} material={m.accent}><boxGeometry args={[2.4, 1.6, 0.6]} /></mesh>
    <mesh position={[0, 11.6, 2.6]} material={m.cyanGlow}><boxGeometry args={[1.6, 0.2, 0.1]} /></mesh>
    <mesh position={[0, 12, -2.6]} material={m.white}><boxGeometry args={[4.6, 6, 2.2]} /></mesh>
    {[-1, 1].map(sd => <group key={sd} position={[sd * 3.2, 12.6, 0]} rotation={[0, 0, sd * 0.18]}>
      <mesh position={[0, -2.6, 0]} material={m.fabric}><capsuleGeometry args={[0.9, 4.6, 6, 12]} /></mesh>
      <mesh position={[0, -5.9, 0.2]} material={m.white}><sphereGeometry args={[0.95, 12, 10]} /></mesh>
    </group>)}
    <mesh position={[0, 14.7, 0]} rotation={[Math.PI / 2, 0, 0]} material={m.trim}><torusGeometry args={[1.7, 0.32, 8, 24]} /></mesh>
    <mesh position={[0, 16.6, -0.1]} material={m.white}><sphereGeometry args={[1.95, 20, 14]} /></mesh>
    <mesh position={[0, 16.6, 0.25]} material={m.visor}><sphereGeometry args={[2.0, 24, 16, -Math.PI / 2 + 0.35, Math.PI - 0.7, Math.PI * 0.22, Math.PI * 0.45]} /></mesh>
    <mesh position={[0, 16.6, 0]} material={m.glass}><sphereGeometry args={[2.2, 24, 16]} /></mesh>
  </group>;
}

function Monitor({ m, p, variant, w = 9, h = 5.4 }: { m: Mats; p: Vec3; variant: 'wave' | 'patch' | 'airlock'; w?: number; h?: number }) {
  const tex = useMemo(() => canvasTexture(768, 460, c => drawMonitor(c, 768, 460, variant)), [variant]);
  return <group position={p}>
    <mesh material={m.panelDark}><boxGeometry args={[w + 0.6, h + 0.6, 0.5]} /></mesh>
    <mesh position={[0, 0, 0.27]}><planeGeometry args={[w, h]} /><meshBasicMaterial map={tex} toneMapped={false} /></mesh>
  </group>;
}

function MedicalStation({ m }: { m: Mats }) {
  const { bed, cabinet, ivPole, monitors } = BAY.medical;
  return <group>
    <group position={bed}>
      {[-5, 5].map(x => <mesh key={x} position={[x, 1.6, 0]} material={m.rib}><boxGeometry args={[1, 3.2, 3]} /></mesh>)}
      <mesh position={[0, 3.6, 0]} material={m.white}><boxGeometry args={[13, 0.9, 5]} /></mesh>
      <mesh position={[0, 4.25, 0]} material={m.fabricShade}><boxGeometry args={[12, 0.45, 4.2]} /></mesh>
      <mesh position={[2, 4, 0]} rotation={[0, Math.PI / 2, 0]} material={m.white}><torusGeometry args={[5, 0.75, 10, 40, Math.PI]} /></mesh>
      <mesh position={[2, 4, 0]} rotation={[0, Math.PI / 2, 0]} material={m.cyanGlow}><torusGeometry args={[4.25, 0.07, 6, 40, Math.PI]} /></mesh>
    </group>
    <group position={cabinet}>
      <mesh position={[0, 5, 0]} material={m.white}><boxGeometry args={[5, 10, 4]} /></mesh>
      {[2, 4.5, 7, 9].map(y => <mesh key={y} position={[0, y, 2.02]} material={m.panelDark}><boxGeometry args={[4.4, 0.12, 0.05]} /></mesh>)}
      <mesh position={[0, 8.2, 2.05]} material={m.cyanGlow}><boxGeometry args={[1.6, 0.35, 0.05]} /></mesh>
      <mesh position={[0, 8.2, 2.06]} material={m.cyanGlow}><boxGeometry args={[0.35, 1.6, 0.05]} /></mesh>
    </group>
    <group position={ivPole}>
      <mesh position={[0, 0.2, 0]} material={m.rib}><cylinderGeometry args={[1.3, 1.3, 0.4, 16]} /></mesh>
      <mesh position={[0, 6, 0]} material={m.trim}><cylinderGeometry args={[0.12, 0.12, 12, 8]} /></mesh>
      <mesh position={[0, 11.6, 0]} material={m.trim}><boxGeometry args={[3, 0.15, 0.15]} /></mesh>
      <mesh position={[1.2, 10.2, 0]} material={m.glass}><boxGeometry args={[0.9, 2.2, 0.5]} /></mesh>
    </group>
    <Monitor m={m} p={monitors[0]} variant="wave" />
    <Monitor m={m} p={monitors[1]} variant="patch" />
  </group>;
}

function WindowAndMars({ m, quality }: { m: Mats; quality: BayQuality }) {
  const { x0, x1, y0, y1, wallZ } = BAY.window;
  const size = BAY_SETTINGS[quality].marsTexture;
  const mars = useMemo(() => canvasTexture(size, size / 2, c => drawMarsLandscape(c, size, size / 2, 7)), [size]);
  const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, w = x1 - x0, h = y1 - y0;
  return <group>
    {/* landscape far outside the window; unaffected by interior fog */}
    <mesh position={[cx, -6, wallZ - 40]}><planeGeometry args={[150, 75]} /><meshBasicMaterial map={mars} color="#d9c7c0" toneMapped={false} fog={false} /></mesh>
    {[[cx, y1 + 0.6, w + 2.4, 1.2], [cx, y0 - 0.6, w + 2.4, 1.2]].map(([x, y, ww, hh], i) =>
      <mesh key={'h' + i} position={[x, y, wallZ + 0.2]} material={m.trim}><boxGeometry args={[ww, hh, 1.6]} /></mesh>)}
    {[x0 - 0.6, x0 + w / 3, x0 + (2 * w) / 3, x1 + 0.6].map((x, i) =>
      <mesh key={'v' + i} position={[x, cy, wallZ + 0.2]} material={m.trim}><boxGeometry args={[i === 0 || i === 3 ? 1.2 : 0.35, h + 2.4, 1.2]} /></mesh>)}
    <mesh position={[cx, cy, wallZ - 0.2]} material={m.glass}><planeGeometry args={[w, h]} /></mesh>
    <mesh position={[cx, y1 + 1.6, wallZ + 1.2]} material={m.warmGlow}><boxGeometry args={[w, 0.15, 0.15]} /></mesh>
    <mesh position={[cx, y0 - 1.8, wallZ + 2]} material={m.rib}><boxGeometry args={[w + 4, 1.6, 4]} /></mesh>
  </group>;
}

function Airlock({ m }: { m: Mats }) {
  const { wallZ, x, y, radius } = BAY.airlock;
  const tex = useMemo(() => canvasTexture(512, 200, c => drawMonitor(c, 512, 200, 'airlock')), []);
  return <group position={[x, y, wallZ - 0.6]} rotation={[0, Math.PI, 0]}>
    <mesh rotation={[Math.PI / 2, 0, Math.PI / 8]} material={m.hazard}><cylinderGeometry args={[radius + 1.4, radius + 1.4, 1.2, 8, 1, true]} /></mesh>
    <mesh rotation={[Math.PI / 2, 0, Math.PI / 8]} material={m.panelDark}><cylinderGeometry args={[radius, radius, 0.8, 8]} /></mesh>
    <mesh position={[0, 0, 0.45]} material={m.trim}><boxGeometry args={[0.5, radius * 1.8, 0.2]} /></mesh>
    <mesh position={[0, radius + 2.6, 0.2]}><planeGeometry args={[7, 2.7]} /><meshBasicMaterial map={tex} toneMapped={false} /></mesh>
    <mesh position={[radius + 2.2, 0, 0.3]} material={m.amberGlow}><cylinderGeometry args={[0.45, 0.45, 0.3, 16]} /></mesh>
  </group>;
}

function Racks({ m }: { m: Mats }) {
  return <group>{BAY.racks.map((p, i) => <group key={i} position={p} rotation={[0, -Math.PI / 2, 0]}>
    <mesh position={[0, 7, -0.5]} material={m.panelDark}><boxGeometry args={[9, 14, 4]} /></mesh>
    {[2, 5, 8, 11].map(y => <mesh key={y} position={[0, y, 1.6]} material={m.trim}><boxGeometry args={[8, 0.3, 0.3]} /></mesh>)}
    {[3.5, 6.5, 9.5].map(y => <mesh key={y} position={[(i % 2 ? -1 : 1) * 2, y, 1.2]} material={m.white}><boxGeometry args={[2.6, 2.2, 1.6]} /></mesh>)}
    <mesh position={[-4.2, 7, 1.6]} material={m.cyanGlow}><boxGeometry args={[0.12, 12, 0.12]} /></mesh>
  </group>)}</group>;
}

function Ceiling({ m }: { m: Mats }) {
  return <group>
    <mesh position={[CX, C, CZ]} rotation={[Math.PI / 2, 0, 0]} material={m.panelDark}><planeGeometry args={[W, D]} /></mesh>
    {Array.from({ length: 7 }, (_, i) => RM.z0 + 6 + i * ((D - 12) / 6)).map(z => <mesh key={z} position={[CX, C - 0.8, z]} material={m.rib}><boxGeometry args={[W, 1.6, 1.4]} /></mesh>)}
    {BAY.lamps.map((p, i) => <group key={i} position={p}>
      <mesh material={m.trim}><boxGeometry args={[9, 0.6, 3]} /></mesh>
      <mesh position={[0, -0.35, 0]} material={i % 2 ? m.warmGlow : m.cyanGlow}><boxGeometry args={[8, 0.12, 2.2]} /></mesh>
    </group>)}
  </group>;
}

/** Holographic projector column under the patch. */
function Pedestal({ m }: { m: Mats }) {
  const { radius, height, top } = BAY.pedestal;
  const colH = top - height - F;
  return <group>
    <mesh position={[0, top - height / 2, 0]} material={m.rib}><cylinderGeometry args={[radius, radius + 0.6, height, 48]} /></mesh>
    <mesh position={[0, top + 0.02, 0]} rotation={[Math.PI / 2, 0, 0]} material={m.cyanGlow}><torusGeometry args={[radius - 0.4, 0.08, 6, 64]} /></mesh>
    <mesh position={[0, F + colH / 2, 0]} material={m.panelDark}><cylinderGeometry args={[radius - 2.2, radius + 1.5, colH, 32]} /></mesh>
    {[0.25, 0.55, 0.85].map(k => <mesh key={k} position={[0, F + colH * k, 0]} rotation={[Math.PI / 2, 0, 0]} material={m.cyanGlow}>
      <torusGeometry args={[radius + 1.5 - (3.7 * k) + 0.05, 0.05, 6, 48]} /></mesh>)}
    <mesh position={[0, F + 0.3, 0]} material={m.rib}><cylinderGeometry args={[radius + 3, radius + 3.4, 0.6, 48]} /></mesh>
    <mesh position={[0, top / 2, 0]}><cylinderGeometry args={[6.2, radius - 1, -top, 48, 1, true]} />
      <meshBasicMaterial color="#4CE4F5" transparent opacity={0.03} side={THREE.DoubleSide} depthWrite={false} blending={THREE.AdditiveBlending} /></mesh>
  </group>;
}

function LightShafts() {
  const { x0, x1, y1, wallZ } = BAY.window;
  const mat = useMemo(() => new THREE.MeshBasicMaterial({ color: '#ffb48a', transparent: true, opacity: 0.04, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }), []);
  return <group>
    {[0.2, 0.5, 0.8].map((k, i) => <mesh key={i} position={[x0 + (x1 - x0) * k, (y1 + F) / 2 - 2, wallZ + 12]} rotation={[0.7, 0.1 * (i - 1), 0]} material={mat}><planeGeometry args={[6, 34]} /></mesh>)}
    {BAY.lamps.map((p, i) => <mesh key={'l' + i} position={[p[0], (p[1] + F) / 2, p[2]]} material={mat}><cylinderGeometry args={[3.5, 10, p[1] - F, 24, 1, true]} /></mesh>)}
  </group>;
}

function Dust({ count, reducedMotion }: { count: number; reducedMotion: boolean }) {
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry(), a = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) { a[i * 3] = RM.x0 + 4 + Math.random() * (W - 8); a[i * 3 + 1] = F + Math.random() * (C - F); a[i * 3 + 2] = RM.z0 + 4 + Math.random() * (D - 8); }
    g.setAttribute('position', new THREE.BufferAttribute(a, 3)); return g;
  }, [count]);
  useFrame((_, dt) => {
    if (reducedMotion) return;
    const a = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < count; i++) { let y = a.getY(i) + Math.min(dt, 0.1) * 0.35; if (y > C) y = F; a.setY(i, y); }
    a.needsUpdate = true;
  });
  return <points geometry={geo}><pointsMaterial color="#ffd9b0" size={0.16} transparent opacity={0.32} depthWrite={false} blending={THREE.AdditiveBlending} /></points>;
}

// No extra dynamic lights: the bay's warm/cyan mood comes from emissive strips, lamp panels, the Mars window and
// environment-map reflections. This keeps per-pixel cost low and leaves the patch's own lighting exactly as before.

export function FlexArrayEnvironment({ quality, reducedMotion }: { quality: BayQuality; reducedMotion: boolean }) {
  const m = useBayMaterials();
  const root = useRef<THREE.Group>(null);
  const settings = BAY_SETTINGS[quality];
  const suits = bayProps(quality).filter(p => p.kind === 'suit');
  const { x0, x1, y0, y1 } = BAY.window;
  // Backdrop must never intercept pointer events meant for the patch.
  useLayoutEffect(() => { root.current?.traverse(o => { (o as THREE.Mesh).raycast = noRaycast; }); });
  useEffect(() => () => { m.env.dispose(); }, [m]);
  return <>
    <color attach="background" args={['#05090f']} />
    <fog attach="fog" args={['#060d17', 34, 110]} />
    <group ref={root} name="mars-eva-bay" rotation={[0, BAY.yaw, 0]}>
      <mesh position={[CX, F, CZ]} rotation={[-Math.PI / 2, 0, 0]} material={m.floor}><planeGeometry args={[W, D]} /></mesh>
      <mesh position={[0, F + 0.02, RM.z1 - 10]} rotation={[-Math.PI / 2, 0, 0]} material={m.hazard}><planeGeometry args={[28, 1.2]} /></mesh>
      <PanelWall m={m} axis="z" at={RM.z0} span={[RM.x0, RM.x1]} opening={{ a0: x0 - 1.2, a1: x1 + 1.2, y0: y0 - 1.2, y1: y1 + 1.2 }} />
      <PanelWall m={m} axis="z" at={RM.z1} span={[RM.x0, RM.x1]} opening={{ a0: -11.5, a1: 11.5, y0: F, y1: 7 }} />
      <PanelWall m={m} axis="x" at={RM.x0} span={[RM.z0, RM.z1]} />
      <PanelWall m={m} axis="x" at={RM.x1} span={[RM.z0, RM.z1]} />
      <Ceiling m={m} />
      <WindowAndMars m={m} quality={quality} />
      {suits.map((s, i) => <SpaceSuit key={i} m={m} p={s.p} />)}
      <MedicalStation m={m} />
      <Airlock m={m} />
      <Racks m={m} />
      <Pedestal m={m} />
      {settings.shafts && <LightShafts />}
      <Dust count={settings.dust} reducedMotion={reducedMotion} />
    </group>
  </>;
}
