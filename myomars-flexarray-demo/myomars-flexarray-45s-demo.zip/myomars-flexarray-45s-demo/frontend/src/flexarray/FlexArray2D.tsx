// Functional 2D fallback: same selection / visibility / explode / view state as the 3D scene, rendered with SVG.
import { LAYERS, type LayerId } from './flexArrayData';
import { COLORS, LAYER_GEOMETRY, SKIN_LAYERS, nominalTipLayer, serpentine } from './flexArrayGeometry';
import type { ViewMode } from './FlexArrayScene';

type Props = {
  mode: ViewMode; selected: LayerId | null; visible: Record<LayerId, boolean>; exploded: boolean; stretch: number; needleUm: number;
  grid: { rows: number; cols: number }; onSelect: (id: LayerId | null) => void; reason: string;
};

const W = 640, H = 360;
// isometric-ish parallelogram for a layer
const para = (cx: number, cy: number, w: number, d: number) => {
  const dx = d * 0.55, dy = d * 0.32;
  return `M${cx - w / 2 - dx / 2},${cy + dy / 2} L${cx + w / 2 - dx / 2},${cy + dy / 2} L${cx + w / 2 + dx / 2},${cy - dy / 2} L${cx - w / 2 + dx / 2},${cy - dy / 2} Z`;
};
const iso = (cx: number, cy: number, u: number, v: number, w: number, d: number) => [cx + u * w / 2 + v * d * 0.55 / 2, cy - v * d * 0.32 / 2] as const;

export function FlexArray2D(p: Props) {
  return <div className="fa-fallback" data-testid="fa-fallback">
    <p className="fa-fallback-note" role="status">2D schematic mode · {p.reason}</p>
    {p.mode === 'skin' ? <Skin2D needleUm={p.needleUm} /> : p.mode === 'thigh' ? <Thigh2D /> : <Stack2D {...p} />}
  </div>;
}

function Stack2D({ selected, visible, exploded, stretch, grid, onSelect }: Props) {
  const gap = exploded ? 50 : 10, w = 330, d = 210, cx = W / 2 - 20;
  return <svg viewBox={`0 0 ${W} ${H}`} className="fa-svg" role="group" aria-label="2D exploded layer schematic. Use Tab to reach a layer and Enter to select it.">
    {LAYERS.map((l, i) => ({ l, i })).reverse().map(({ l, i }) => {
      if (!visible[l.id]) return null;
      const level = LAYERS.length - 1 - i;
      const cy = H - 70 - level * gap;
      const g = LAYER_GEOMETRY[i];
      const sel = selected === l.id, dim = selected !== null && !sel;
      const stretchW = l.id === 'stretchable-interconnect' ? w * (1 + stretch * 0.69) : w;
      return <g key={l.id} role="button" tabIndex={0} aria-pressed={sel} aria-label={`Layer ${l.index}: ${l.name}`}
        className="fa-svg-layer" style={{ opacity: dim ? 0.18 : 1, transition: 'transform .6s ease, opacity .3s' }}
        onClick={() => onSelect(l.id)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onSelect(l.id); } }}>
        <path d={para(cx, cy, stretchW, d)} fill={g.color} fillOpacity={Math.min(0.85, g.opacity + 0.2)} stroke={sel ? COLORS.cyan : '#3d7ea6'} strokeWidth={sel ? 2.5 : 1} />
        {l.id === 'adhesive-frame' && <path d={para(cx, cy, w * 0.75, d * 0.62)} fill={COLORS.navy} fillOpacity={0.9} stroke="#3d7ea6" />}
        {l.id === 'microneedle-array' && Array.from({ length: grid.rows * grid.cols }, (_, k) => {
          const r = Math.floor(k / grid.cols), c = k % grid.cols;
          const [x, y] = iso(cx, cy, (c - (grid.cols - 1) / 2) / 4.6, (r - (grid.rows - 1) / 2) / 4.6, w, d);
          return <g key={k}><path d={`M${x - 2},${y} L${x + 2},${y} L${x},${y + 11} Z`} fill={COLORS.goldDeep} /><circle cx={x} cy={y} r={3} fill={COLORS.gold} /></g>;
        })}
        {l.id === 'sweat-management' && Array.from({ length: grid.rows - 1 }, (_, r) => {
          const a = iso(cx, cy, -0.9, (r - (grid.rows - 2) / 2) / 4.6, w, d), b = iso(cx, cy, 0.9, (r - (grid.rows - 2) / 2) / 4.6, w, d);
          return <line key={r} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={COLORS.cyan} strokeWidth={1.5} />;
        })}
        {l.id === 'flex-electronics' && [[-0.4, 0, 46, 'AFE'], [0.05, -0.3, 26, 'ADC'], [0.1, 0.3, 34, 'MCU'], [0.45, -0.35, 20, 'IMU'], [0.5, 0.35, 24, 'RF'], [0.78, 0, 40, 'BAT']].map(([u, v, s, t]) => {
          const [x, y] = iso(cx, cy, u as number, v as number, w, d);
          return <g key={t as string}><rect x={x - (s as number) / 2} y={y - 8} width={s as number} height={14} rx={2} fill={t === 'BAT' ? '#8a96a3' : '#11161d'} /><text x={x} y={y + 3} fontSize={8} textAnchor="middle" fill="#cfe9f5">{t}</text></g>;
        })}
        {l.id === 'stretchable-interconnect' && [-0.5, 0, 0.5].map(v => {
          const pts = serpentine(4.4, 7, 0.16, stretch, 60).points;
          const dpath = pts.map(([x, z], k) => { const [px, py] = iso(cx, cy, (x / (2.2 * (1 + stretch))) * 0.85, v + z / 2.4, stretchW, d); return (k ? 'L' : 'M') + px.toFixed(1) + ',' + py.toFixed(1); }).join(' ');
          return <path key={v} d={dpath} fill="none" stroke={COLORS.gold} strokeWidth={1.6} />;
        })}
        <circle cx={cx + w / 2 + 70} cy={cy} r={11} fill={COLORS.navy} stroke={sel ? COLORS.cyan : '#7fb6d1'} strokeWidth={1.5} />
        <text x={cx + w / 2 + 70} y={cy + 4} fontSize={11} textAnchor="middle" fill="#e7f6ff">{l.index}</text>
      </g>;
    })}
  </svg>;
}

function Skin2D({ needleUm }: { needleUm: number }) {
  const scale = 0.55; // px per µm (layers truncated)
  let y = 120;
  return <svg viewBox={`0 0 ${W} ${H}`} className="fa-svg" role="img" aria-label={`Skin cross-section. Candidate needle ${needleUm} micrometers; nominal tip in ${nominalTipLayer(needleUm)}. Penetration depth not validated.`}>
    <rect x={120} y={70} width={400} height={14} fill={COLORS.substrate} fillOpacity={0.6} />
    {SKIN_LAYERS.map(l => {
      const h = l.id === 'dermis' ? 130 : l.id === 'fat' ? 50 : Math.max(5, l.thicknessUm * scale);
      const el = <g key={l.id}><rect x={80} y={y} width={480} height={h} fill={l.color} /><text x={566} y={y + Math.min(h, 14) - 2} fontSize={10} fill="#cfe2ee">{l.label} ~{l.thicknessUm} µm</text></g>;
      y += h; return el;
    })}
    {[180, 260, 340, 420, 500].map(x => <path key={x} d={`M${x - 6},84 L${x + 6},84 L${x},${120 + needleUm * scale} Z`} fill={COLORS.gold} />)}
    <line x1={80} x2={560} y1={120 + needleUm * scale} y2={120 + needleUm * scale} stroke={COLORS.cyan} strokeDasharray="5 4" />
    <text x={80} y={60} fontSize={11} fill="#ffd58a">Illustrative only — penetration depth not validated; skin deforms on insertion.</text>
  </svg>;
}

function Thigh2D() {
  return <svg viewBox={`0 0 ${W} ${H}`} className="fa-svg" role="img" aria-label="Simplified thigh with patch on the anterior thigh (candidate placement).">
    <path d="M90,120 Q320,80 560,130 L560,250 Q320,280 90,240 Z" fill={COLORS.skin} fillOpacity={0.85} />
    <ellipse cx={560} cy={190} rx={30} ry={62} fill={COLORS.skin} />
    <rect x={270} y={135} width={110} height={80} rx={14} fill={COLORS.adhesive} fillOpacity={0.9} />
    <rect x={282} y={146} width={86} height={58} rx={9} fill={COLORS.substrate} />
    {Array.from({ length: 24 }, (_, k) => <circle key={k} cx={292 + (k % 6) * 13} cy={155 + Math.floor(k / 6) * 13} r={2.6} fill={COLORS.gold} />)}
    <text x={90} y={300} fontSize={11} fill="#cfe2ee">Candidate placement: anterior thigh (quadriceps). Placement protocol pending.</text>
  </svg>;
}
