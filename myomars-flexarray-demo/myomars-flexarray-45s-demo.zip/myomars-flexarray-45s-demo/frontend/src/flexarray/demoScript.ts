// Guided demonstration: script, synthetic data and timeline logic (pure, unit-tested).
// All data are SYNTHETIC and come from the existing MuscleSense simulation (src/muscleSense.ts) for the fictional
// crew profile A01. Nothing here is a clinical assessment, and the demo never creates a real authorization.
import { muscleBaseline, muscleSample, muscleSummary, type MuscleSample } from '../muscleSense';
import type { LayerId } from './flexArrayData';
import { CAMERA_DEFAULT } from './flexArrayGeometry';
import type { Vec3 } from './bayLayout';

export type CameraShot = 'wide' | 'wide-close' | 'patch';
export type Overlay = 'hud' | 'review' | null;
export type ReviewStep = 'evidence' | 'gate' | 'instruction' | 'ack' | 'reassess';
export type Cue = { camera?: CameraShot; explode?: boolean; select?: LayerId | null; overlay?: Overlay; review?: ReviewStep };
export type Beat = { id: string; at: number; caption: string; sub: string; cue: Cue; gate?: boolean; confirmedCaption?: string; confirmedSub?: string };
export type Scene = { id: 'before-eva' | 'technology' | 'during-eva' | 'medical-review'; title: string; start: number; end: number; beats: Beat[] };

// ---------- synthetic data (existing MuscleSense logic) ----------
export const DEMO_CREW = { id: 'a01', label: 'Crew A01 · Maya Chen (fictional profile)' } as const;
export const EVA_SECONDS = 30;
export const leftBaseline = muscleBaseline(DEMO_CREW.id, 'left');
export const rightBaseline = muscleBaseline(DEMO_CREW.id, 'right');
export const leftSeries: MuscleSample[] = Array.from({ length: EVA_SECONDS }, (_, i) => muscleSample(DEMO_CREW.id, 'left', i + 1, 'fatigue'));
export const rightSeries: MuscleSample[] = Array.from({ length: EVA_SECONDS }, (_, i) => muscleSample(DEMO_CREW.id, 'right', i + 1, 'nominal'));
export const isReviewFlag = (status: string) => status.startsWith('Fatigue-related trend');
/** First synthetic sample at which the EXISTING MuscleSense demo rule requests human review. */
export const flagSecond = (() => {
  for (let s = 1; s <= EVA_SECONDS; s++) if (isReviewFlag(muscleSummary(leftSeries.slice(0, s), leftBaseline).status)) return s;
  return -1;
})();
export const evidenceSummary = muscleSummary(leftSeries, leftBaseline);
export const reassessSeries: MuscleSample[] = Array.from({ length: 8 }, (_, i) => muscleSample(DEMO_CREW.id, 'left', i + 1, 'nominal'));
export const reassessSummary = muscleSummary(reassessSeries, leftBaseline);
export const RETEST_INSTRUCTION = 'Pause strenuous tasks. After rest, repeat the left-quadriceps check under comparable conditions and report back.';
export const DEMO_REVIEWER = 'Demo reviewer (simulated)';

// ---------- timeline (45 s of scripted content; the clock pauses at the reviewer gate) ----------
const S1 = 0, S2 = 7000, S3 = 18000, S4 = 32000, END = 45000;
/** Scene-3 time over which the 30 synthetic samples play (the HUD then holds the last sample). */
export const HUD_WINDOW = 10000;
/** Scene-3 time → synthetic sample second (1…30). */
export const hudSecond = (t: number) => Math.max(1, Math.min(EVA_SECONDS, 1 + Math.floor(((t - S3) / HUD_WINDOW) * EVA_SECONDS)));
/** The event caption is timed from the data: shortly after the sample at which the existing rule first flags. */
export const EVENT_AT = flagSecond > 0 ? S3 + Math.ceil(((flagSecond - 1) * HUD_WINDOW) / EVA_SECONDS) + 200 : -1;
/** Maximum words per caption line (caption and sub), for a fast-paced presentation. */
export const MAX_CAPTION_WORDS = 10;
export const wordCount = (text: string) => text.split(/\s+/).filter(w => /[\p{L}\p{N}]/u.test(w)).length;

const eventBeats: Beat[] = EVENT_AT > 0 ? [
  { id: 'event', at: EVENT_AT, caption: 'Left quadriceps · fatigue-related trend flagged for review', sub: 'Not a diagnosis · existing MuscleSense demo rule triggered',
    cue: { overlay: 'hud' } },
  { id: 'sent', at: EVENT_AT + 4000, caption: 'Evidence sent to Mars base medical (simulated)', sub: 'No automatic instruction to the crew',
    cue: { overlay: 'hud' } },
] : []; // if the rule never triggers, no alert is scripted

export const SCENES: Scene[] = [
  { id: 'before-eva', title: 'Before EVA', start: S1, end: S2, beats: [
    { id: 'bay', at: 0, caption: 'Sol 142 · Crew A01 prepares for a Mars EVA', sub: 'Fictional astronaut · all data synthetic',
      cue: { camera: 'wide', explode: false, select: null, overlay: null } },
  ] },
  { id: 'technology', title: 'FlexArray Technology', start: S2, end: S3, beats: [
    { id: 'layers', at: S2, caption: 'Six flexible layers · exploded view', sub: 'Magnified for clarity · not to scale',
      cue: { camera: 'patch', explode: true, select: null, overlay: null } },
    { id: 'microneedle', at: 9500, caption: 'Layer 02 · Microneedle array', sub: '8 × 8 candidate sites · geometry not validated',
      cue: { select: 'microneedle-array' } },
    { id: 'sweat', at: 12300, caption: 'Layer 03 · Sweat management', sub: 'Proposed microchannels route sweat away · untested concept',
      cue: { select: 'sweat-management' } },
    { id: 'electronics', at: 15100, caption: 'Layer 04 · Flexible electronics', sub: 'sEMG front end, ADC, IMU, radio · concept only',
      cue: { select: 'flex-electronics' } },
  ] },
  { id: 'during-eva', title: 'AI Muscle Monitoring', start: S3, end: S4, beats: [
    { id: 'hud', at: S3, caption: 'Simulated EVA telemetry · sEMG and IMU, both quadriceps', sub: 'Compared with a fictional personal baseline',
      cue: { camera: 'wide', explode: false, select: null, overlay: 'hud' } },
    ...eventBeats,
  ] },
  { id: 'medical-review', title: 'Mars Base Medical Review', start: S4, end: END, beats: [
    { id: 'evidence', at: S4, caption: 'Mars base medical review · evidence and baseline', sub: 'Trend, personal baseline and sensor quality',
      cue: { camera: 'wide', select: null, overlay: 'review', review: 'evidence' } },
    { id: 'gate', at: 35000, gate: true, caption: 'Human reviewer confirmation required', sub: 'Paused for review · elapsed time may exceed 45 s',
      confirmedCaption: 'Review confirmed by demo reviewer (simulated)', confirmedSub: 'No real authorization is created',
      cue: { overlay: 'review', review: 'gate' } },
    { id: 'instruction', at: 36500, caption: 'Approved retest instruction sent (simulated)', sub: 'No treatment or recovery duration prescribed',
      cue: { overlay: 'review', review: 'instruction' } },
    { id: 'ack', at: 39500, caption: 'Crew acknowledges the instruction (simulated)', sub: 'Crew A01 confirms and pauses strenuous tasks',
      cue: { overlay: 'review', review: 'ack' } },
    { id: 'reassess', at: 42000, caption: 'Reassessment · no demo trend flag', sub: 'Return-to-EVA decision stays with medical team and mission control',
      cue: { overlay: 'review', review: 'reassess' } },
  ] },
];
export const DEMO_TOTAL = END;
/** Captions for the ended state (also checked against the word limit). */
export const END_CAPTION = { caption: 'Demo complete', sub: 'Replay, or return to the interactive explorer' };
export const GATE_AT = SCENES[3].beats.find(b => b.gate)!.at;
const ALL_BEATS = SCENES.flatMap(s => s.beats);

export function sceneAt(t: number) { return SCENES.findIndex(s => t >= s.start && t < s.end) === -1 ? SCENES.length - 1 : SCENES.findIndex(s => t >= s.start && t < s.end); }
export function beatAt(t: number) { let b = ALL_BEATS[0]; for (const x of ALL_BEATS) if (x.at <= t) b = x; return b; }
/** Accumulated cue state at time t (later beats override earlier ones). */
export function cueAt(t: number): Required<Pick<Cue, 'overlay'>> & Cue {
  const c: Cue = { overlay: null };
  for (const b of ALL_BEATS) if (b.at <= t) Object.assign(c, b.cue);
  return c as Required<Pick<Cue, 'overlay'>> & Cue;
}
/** Clamp a time so it never passes the reviewer gate without confirmation. */
export const clampToGate = (t: number, confirmed: boolean) => (confirmed ? Math.min(t, DEMO_TOTAL) : Math.min(t, GATE_AT, DEMO_TOTAL));
/** Advance the clock; reports when it stopped at the gate or reached the end. */
export function advance(t: number, dt: number, confirmed: boolean) {
  const next = clampToGate(t + dt, confirmed);
  return { t: next, atGate: !confirmed && next >= GATE_AT, ended: next >= DEMO_TOTAL };
}
export function nextStop(t: number, confirmed: boolean) {
  const i = sceneAt(t);
  const target = i + 1 < SCENES.length ? SCENES[i + 1].start : DEMO_TOTAL;
  return clampToGate(target, confirmed);
}
export function prevStop(t: number) {
  const i = sceneAt(t);
  return t - SCENES[i].start > 1500 || i === 0 ? SCENES[i].start : SCENES[i - 1].start;
}

// ---------- camera shots (world coordinates) ----------
const target: Vec3 = [0, 2.7, 0];
const dir = (() => { const [x, y, z] = CAMERA_DEFAULT.position.map((v, i) => v - target[i]); const l = Math.hypot(x, y, z); return [x / l, y / l, z / l]; })();
const along = (d: number, lift = 0, swing = 0): Vec3 => {
  const c = Math.cos(swing), s = Math.sin(swing), x = dir[0] * c + dir[2] * s, z = -dir[0] * s + dir[2] * c;
  return [target[0] + x * d, target[1] + dir[1] * d + lift, target[2] + z * d];
};
export const DEMO_SHOTS: Record<Exclude<CameraShot, 'patch'>, { position: Vec3; target: Vec3 }> = {
  wide: { position: along(29, 2.5, -0.18), target: [0, 3.2, 0] },
  'wide-close': { position: along(23, 1.2, 0.12), target: [0, 2.9, 0] },
};
export const fmtTime = (ms: number) => { const s = Math.round(ms / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
