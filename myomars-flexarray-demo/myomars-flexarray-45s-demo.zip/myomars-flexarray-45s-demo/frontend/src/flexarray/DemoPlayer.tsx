// Guided 45-second demonstration overlay for the FlexArray page (45 s of scripted content; the clock pauses at the
// reviewer gate, so real elapsed time can be longer).
// Synthetic data only. The demo makes no network requests, writes nothing to storage, and never auto-confirms the
// medical-review gate: the retest instruction is shown only after a person clicks "Confirm review".
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { MuscleSample } from '../muscleSense';
import { muscleSummary } from '../muscleSense';
import {
  DEMO_CREW, DEMO_REVIEWER, DEMO_TOTAL, END_CAPTION, GATE_AT, RETEST_INSTRUCTION, SCENES, advance, beatAt, clampToGate, cueAt, evidenceSummary, fmtTime,
  hudSecond, isReviewFlag, leftBaseline, leftSeries, nextStop, prevStop, reassessSeries, reassessSummary, rightBaseline, rightSeries, sceneAt, type Cue,
} from './demoScript';
import { DISCLAIMER } from './flexArrayData';

type Props = { reducedMotion: boolean; onCue: (cue: Cue, t: number) => void; onExit: () => void };

const Icon = ({ d }: { d: string }) => <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d={d} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>;
const P = { play: 'M8 5l11 7-11 7z', pause: 'M8 5v14M16 5v14', prev: 'M18 6l-8 6 8 6M6 6v12', next: 'M6 6l8 6-8 6M18 6v12', replay: 'M4 12a8 8 0 1 0 2.4-5.7M4 4v4.5h4.5', close: 'M6 6l12 12M18 6L6 18' };

/** Tiny SVG trend chart: series vs baseline (dashed) and demo threshold (amber). */
function Spark({ samples, field, baseline, threshold, w = 220, h = 54, color = '#4CE4F5', label, fit = false }: { samples: MuscleSample[]; field: 'medianHz' | 'rms'; baseline: number; threshold?: number; w?: number; h?: number; color?: string; label: string; fit?: boolean }) {
  const vals = samples.map(s => s[field] ?? baseline);
  const lo = Math.min(baseline * 0.7, ...vals), hi = Math.max(baseline * 1.1, ...vals);
  const y = (v: number) => h - 4 - ((v - lo) / (hi - lo || 1)) * (h - 8), x = (i: number) => 4 + (i / Math.max(1, 29)) * (w - 8);
  // fit: fill a fixed-height box (stretched horizontally, strokes kept at constant width)
  const ve = fit ? 'non-scaling-stroke' : undefined;
  return <svg viewBox={`0 0 ${w} ${h}`} className={'fa-spark' + (fit ? ' is-fit' : '')} preserveAspectRatio={fit ? 'none' : undefined} role="img" aria-label={label}>
    <line x1={4} x2={w - 4} y1={y(baseline)} y2={y(baseline)} stroke="#8a9fb3" strokeDasharray="3 3" strokeWidth={1} vectorEffect={ve} />
    {threshold !== undefined && <line x1={4} x2={w - 4} y1={y(threshold)} y2={y(threshold)} stroke="#ffcf86" strokeOpacity={0.7} strokeWidth={1} vectorEffect={ve} />}
    <polyline fill="none" stroke={color} strokeWidth={1.8} vectorEffect={ve} points={vals.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ')} />
  </svg>;
}

function Hud({ t }: { t: number }) {
  const s = hudSecond(t), left = leftSeries.slice(0, s), right = rightSeries.slice(0, s), cur = left.at(-1)!, curR = right.at(-1)!;
  const summary = muscleSummary(left, leftBaseline), flagged = isReviewFlag(summary.status);
  return <div className="fa-hud" data-testid="fa-demo-hud" aria-label="Simulated astronaut HUD">
    <div className="fa-hud-top"><span>EVA-042 · MET 01:{String(10 + s).padStart(2, '0')}:00</span><span className="fa-synth">SIMULATED HUD · SYNTHETIC DATA</span><span>{DEMO_CREW.label}</span></div>
    <div className="fa-hud-col fa-hud-left" data-testid="fa-hud-left">
      <h3>Left quadriceps</h3>
      <dl>
        <div><dt>sEMG RMS</dt><dd>{cur.rms?.toFixed(1)} <small>µV</small></dd><span>baseline {leftBaseline.rms}</span></div>
        <div><dt>Median freq.</dt><dd data-testid="fa-hud-median">{cur.medianHz?.toFixed(1)} <small>Hz</small></dd><span>baseline {leftBaseline.medianHz}</span></div>
        <div><dt>Signal quality</dt><dd>{cur.quality}%</dd><span>{cur.contact ? 'contact OK' : 'poor contact'}{cur.artifact ? ' · artifact' : ''}</span></div>
      </dl>
      <Spark samples={left} field="medianHz" baseline={leftBaseline.medianHz} threshold={leftBaseline.medianHz * 0.85} color={flagged ? '#ffcf86' : '#4CE4F5'} label="Left median-frequency trend versus personal baseline" />
    </div>
    <div className="fa-hud-col fa-hud-right">
      <h3>Right quadriceps</h3>
      <dl>
        <div><dt>sEMG RMS</dt><dd>{curR.rms?.toFixed(1)} <small>µV</small></dd><span>baseline {rightBaseline.rms}</span></div>
        <div><dt>Median freq.</dt><dd>{curR.medianHz?.toFixed(1)} <small>Hz</small></dd><span>baseline {rightBaseline.medianHz}</span></div>
        <div><dt>IMU</dt><dd>{cur.accel?.toFixed(2)} <small>g</small></dd><span>{cur.gyro?.toFixed(0)} °/s</span></div>
      </dl>
      <Spark samples={right} field="medianHz" baseline={rightBaseline.medianHz} label="Right median-frequency trend versus personal baseline" />
    </div>
    {flagged && <div className="fa-hud-event" role="status" data-testid="fa-hud-event">
      <strong>Left quadriceps · fatigue-related trend</strong>
      <span className="fa-hud-event-line">Flagged for human review <b className="fa-nodx">Not a diagnosis</b></span>
      <small>{summary.drop?.toFixed(0)} % median-frequency decrease vs fictional baseline · demo rule ≥ 15 %, quality ≥ 80 %</small>
    </div>}
  </div>;
}

function Review({ step, confirmed, onConfirm, confirmRef, reducedMotion }: { step: string; confirmed: boolean; onConfirm: () => void; confirmRef: React.RefObject<HTMLButtonElement>; reducedMotion: boolean }) {
  const order = ['evidence', 'gate', 'instruction', 'ack', 'reassess'], k = order.indexOf(step);
  const sent = confirmed && k >= 2;
  const qMin = Math.min(...leftSeries.map(s => s.quality)), qMax = Math.max(...leftSeries.map(s => s.quality));
  const qualityRange = qMin === qMax ? `${qMin}` : `${qMin}–${qMax}`;
  const box = useRef<HTMLDivElement>(null);
  // keep the newest review message in view (instant when reduced motion is requested)
  useEffect(() => {
    const el = box.current; if (!el) return;
    const msgs = el.querySelectorAll<HTMLElement>('.fa-review-msg');
    const last = msgs.length ? msgs[msgs.length - 1] : el.querySelector<HTMLElement>('.fa-review-gate');
    last?.scrollIntoView({ block: 'nearest', behavior: reducedMotion ? 'auto' : 'smooth' });
  }, [step, confirmed, reducedMotion]);
  return <div className="fa-review" ref={box} data-testid="fa-demo-review" aria-label="Simulated Mars base medical review">
    <div className="fa-review-head"><span className="fa-kicker">Mars base medical review</span><span className="fa-synth">SIMULATED · SYNTHETIC DATA</span></div>
    <div className="fa-review-grid">
      <section aria-label="Evidence"><h3>Evidence · left quadriceps</h3>
        <Spark samples={leftSeries} field="medianHz" baseline={leftBaseline.medianHz} threshold={leftBaseline.medianHz * 0.85} w={300} h={70} fit color="#ffcf86" label="Left median-frequency trend over the synthetic EVA window" />
        <p data-testid="fa-review-status">{evidenceSummary.status}: {evidenceSummary.drop?.toFixed(1)} % median-frequency decrease over the last 5 valid samples.</p>
      </section>
      <section aria-label="Personal baseline"><h3>Personal baseline</h3>
        <p data-testid="fa-review-baseline">{DEMO_CREW.label}: sEMG RMS {leftBaseline.rms} µV · median frequency {leftBaseline.medianHz} Hz (fictional).</p>
      </section>
      <section aria-label="Sensor quality"><h3>Sensor quality</h3>
        <p data-testid="fa-review-quality">Quality {qualityRange} % · contact {leftSeries.every(s => s.contact) ? 'connected' : 'intermittent'} · artifacts {leftSeries.some(s => s.artifact) ? 'present' : 'none'} · {leftSeries.length} samples.</p>
      </section>
    </div>
    <p className="fa-review-note">Demo rule: ≥ 15 % decrease over 5 valid samples. Illustrative software threshold, not a NASA or clinical limit. A frequency decrease alone cannot establish fatigue or injury.</p>
    <div className={'fa-review-gate' + (confirmed ? ' is-done' : '')} data-testid="fa-review-gate">
      {!confirmed
        ? k >= 1
          ? <><strong>Reviewer confirmation required</strong><span>Nothing is sent to the crew until a person confirms. Autoplay will not confirm for you.</span>
              <span className="fa-gate-timing" data-testid="fa-gate-timing">Scripted timeline paused at {fmtTime(GATE_AT)} of {fmtTime(DEMO_TOTAL)}. Actual elapsed time may exceed {DEMO_TOTAL / 1000} s while waiting for review.</span>
              <button ref={confirmRef} type="button" className="fa-confirm" onClick={onConfirm}>Confirm review as demo reviewer</button></>
          : <span>Awaiting reviewer…</span>
        : <span data-testid="fa-review-confirmed">✓ Confirmed by {DEMO_REVIEWER}. Demo only: no authorization record is created and no data leave this page.</span>}
    </div>
    {sent && <div className="fa-review-msg" data-testid="fa-demo-instruction"><strong>Approved retest instruction (simulated) → crew A01</strong><span>{RETEST_INSTRUCTION}</span></div>}
    {sent && k >= 3 && <div className="fa-review-msg fa-ack" data-testid="fa-demo-ack"><strong>Crew acknowledgment (simulated)</strong><span>A01: “Acknowledged. Pausing strenuous tasks; ready for the retest.”</span></div>}
    {sent && k >= 4 && <div className="fa-review-msg fa-reassess" data-testid="fa-demo-reassess"><strong>Reassessment (synthetic, {reassessSeries.length} samples)</strong>
      <span>{reassessSummary.status}. Return-to-EVA decisions remain with the human medical team and mission control.</span></div>}
  </div>;
}

export function DemoPlayer({ reducedMotion, onCue, onExit }: Props) {
  const [t, setTState] = useState(0);
  const tRef = useRef(0);
  const setT = useCallback((v: number) => { tRef.current = v; setTState(v); }, []);
  const [playing, setPlaying] = useState(true);
  const [confirmed, setConfirmed] = useState(false);
  const playBtn = useRef<HTMLButtonElement>(null), confirmBtn = useRef<HTMLButtonElement>(null);
  const atGate = !confirmed && t >= GATE_AT, ended = t >= DEMO_TOTAL;
  const sceneIndex = sceneAt(t), scene = SCENES[sceneIndex], beat = beatAt(t), cue = useMemo(() => cueAt(beat.at), [beat.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // clock
  useEffect(() => {
    if (!playing) return;
    let last = performance.now(), raf = 0;
    const tick = (now: number) => {
      const dt = Math.min(250, now - last); last = now;
      const r = advance(tRef.current, dt, confirmed);
      setT(r.t);
      if (r.atGate || r.ended) { setPlaying(false); return; }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, confirmed, setT]);

  // drive the 3D scene when the active beat changes
  useEffect(() => { onCue(cue, t); }, [beat.id]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { playBtn.current?.focus(); }, []);
  useEffect(() => { if (atGate) confirmBtn.current?.focus(); }, [atGate]);
  useEffect(() => {
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.preventDefault(); onExit(); } };
    window.addEventListener('keydown', esc); return () => window.removeEventListener('keydown', esc);
  }, [onExit]);

  const seek = useCallback((to: number) => { setT(clampToGate(Math.max(0, to), confirmed)); }, [confirmed, setT]);
  const confirm = () => { setConfirmed(true); setPlaying(true); };
  const replay = () => { setConfirmed(false); setT(0); setPlaying(true); onCue(cueAt(0), 0); };
  const state = ended ? 'ended' : atGate ? 'gate' : playing ? 'playing' : 'paused';
  const caption = ended ? END_CAPTION.caption : beat.gate && confirmed ? beat.confirmedCaption ?? beat.caption : beat.caption;
  const sub = ended ? END_CAPTION.sub : beat.gate && confirmed ? beat.confirmedSub ?? beat.sub : beat.sub;

  return <div className={'fa-demo' + (reducedMotion ? ' is-reduced' : '')} role="region" aria-label="Guided demonstration"
    data-demo-scene={scene.id} data-demo-state={state} data-demo-beat={beat.id} data-demo-highlight={cue.select ?? ''}>
    <div className="fa-demo-badge" data-testid="fa-demo-badge">Guided demo · synthetic data · not a clinical diagnosis</div>
    {cue.overlay === 'hud' && <Hud t={t} />}
    {cue.overlay === 'review' && <Review step={atGate ? 'gate' : cue.review ?? 'evidence'} confirmed={confirmed} onConfirm={confirm} confirmRef={confirmBtn} reducedMotion={reducedMotion} />}
    <div className="fa-demo-caption" key={reducedMotion ? 'static' : beat.id + (beat.gate && confirmed ? '-ok' : '')}>
      <span className="fa-kicker">Scene {sceneIndex + 1} / {SCENES.length} · {scene.title}</span>
      <h2 data-testid="fa-demo-caption">{caption}</h2>
      {sub && <p data-testid="fa-demo-sub">{sub}</p>}
    </div>
    <div className="sr-only" role="status" aria-live="polite">{`Scene ${sceneIndex + 1}: ${scene.title}. ${caption}.${atGate ? ` Reviewer confirmation required. Timeline paused; elapsed time may exceed ${DEMO_TOTAL / 1000} seconds.` : ''}`}</div>
    <div className="fa-demo-bar" role="toolbar" aria-label="Demo controls">
      <button type="button" className="fa-icon-btn" aria-label="Previous scene" onClick={() => seek(prevStop(t))}><Icon d={P.prev} /></button>
      <button ref={playBtn} type="button" className="fa-icon-btn fa-demo-play" aria-label={playing ? 'Pause demo' : 'Play demo'} disabled={atGate || ended}
        onClick={() => setPlaying(p => !p)}><Icon d={playing ? P.pause : P.play} /></button>
      <button type="button" className="fa-icon-btn" aria-label="Next scene" disabled={atGate || ended} title={atGate ? 'Reviewer confirmation required' : undefined}
        onClick={() => { const to = nextStop(t, confirmed); seek(to); if (!confirmed && to >= GATE_AT) setPlaying(false); }}><Icon d={P.next} /></button>
      <div className="fa-demo-track">
        <div className="fa-demo-segments" aria-hidden="true">{SCENES.map((s, i) => <span key={s.id} className={i < sceneIndex ? 'is-done' : i === sceneIndex ? 'is-on' : ''}
          style={{ flexGrow: s.end - s.start }}><i style={{ width: i === sceneIndex ? `${((t - s.start) / (s.end - s.start)) * 100}%` : undefined }} /></span>)}</div>
        <input type="range" className="fa-demo-scrub" min={0} max={DEMO_TOTAL} step={1000} value={Math.round(t)} aria-label="Demo position"
          aria-valuetext={`${fmtTime(t)} of ${fmtTime(DEMO_TOTAL)} scripted, scene ${sceneIndex + 1} ${scene.title}${atGate ? ', paused for review' : ''}`} onChange={e => seek(Number(e.target.value))} />
      </div>
      <span className="fa-demo-time" data-testid="fa-demo-time" aria-hidden="true" title={`${DEMO_TOTAL / 1000} s scripted. The timeline pauses for the human reviewer, so real elapsed time may be longer.`}>
        {fmtTime(t)} / {fmtTime(DEMO_TOTAL)}{atGate && <em> · review</em>}</span>
      <button type="button" className="fa-icon-btn" aria-label="Replay demo" onClick={replay}><Icon d={P.replay} /></button>
      <button type="button" className="fa-pill fa-demo-skip" onClick={onExit}>Skip demo</button>
    </div>
    <p className="fa-disclaimer fa-demo-disclaimer">{DISCLAIMER}</p>
  </div>;
}
