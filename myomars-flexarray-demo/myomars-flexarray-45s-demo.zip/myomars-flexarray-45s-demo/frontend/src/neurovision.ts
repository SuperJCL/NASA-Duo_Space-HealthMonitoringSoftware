import type {Alert, Crew} from './rules';
export const cognitiveBaselines={a01:{reaction_ms:280,visual_ms:450,miss_rate:0,error_rate:0},a02:{reaction_ms:310,visual_ms:480,miss_rate:0,error_rate:0}};
export const sectors=['NW','N','NE','E','SE','S','SW','W'] as const;
export type Kind='reaction'|'visual';
export type Trial={stimulus_at:string;response_ms:number|null;false_starts:number;sector:typeof sectors[number]|null};
export type Screening={session_id:string;astronaut_id:Crew;mission_id:string;kind:Kind;started_at:string;completed_at:string|null;interrupted:boolean;unassigned_errors?:number;trials:Trial[]};
export type ScreeningEvent={event_id:string;event:'started'|'completed'|'interrupted';screening:Screening};
export type Summary={quality:string;status:string;median_ms:number|null;missed_stimuli:number;false_starts:number;miss_rate:number|null;error_rate:number|null;baseline_ms:number;delta_ms:number|null;recorded_trials:number;expected_trials:number;non_diagnostic:true};
const median=(a:number[])=>{a.sort((x,y)=>x-y);const n=a.length;return n? n%2?a[Math.floor(n/2)]:(a[n/2-1]+a[n/2])/2:null};
export function summarize(s:Screening,at=Date.now()):Summary{
 const expected=s.kind==='reaction'?3:8, baseline=cognitiveBaselines[s.astronaut_id]?.[s.kind==='reaction'?'reaction_ms':'visual_ms']??0;
 const trials=Array.isArray(s.trials)?s.trials:[],n=trials.length;
 const validLayout=s.kind==='reaction'?trials.every(t=>t.sector===null):trials.every(t=>sectors.includes(t.sector!))&&new Set(trials.map(t=>t.sector)).size===n;
 let previous=Date.parse(s.started_at);
 const valid=Number.isInteger(s.unassigned_errors??0)&&(s.unassigned_errors??0)>=0&&(s.unassigned_errors??0)<=100&&Number.isFinite(previous)&&Number.isFinite(at)&&!!baseline&&['reaction','visual'].includes(s.kind)&&trials.every(t=>{
 const stamp=Date.parse(t.stimulus_at),ok=Number.isFinite(stamp)&&stamp>=previous&&(!s.completed_at||stamp<=Date.parse(s.completed_at))&&(t.response_ms===null||(Number.isFinite(t.response_ms)&&t.response_ms>=100&&t.response_ms<=1500))&&Number.isInteger(t.false_starts)&&t.false_starts>=0&&t.false_starts<=100;previous=stamp;return ok;
 })&&(!s.completed_at||(Number.isFinite(Date.parse(s.completed_at))&&Date.parse(s.completed_at)>=Date.parse(s.started_at)))&&n<=8;
 const missed=trials.filter(t=>t.response_ms===null).length,errors=trials.reduce((a,t)=>a+t.false_starts,0)+(s.unassigned_errors??0),value=median(trials.flatMap(t=>t.response_ms===null?[]:[t.response_ms]));
 const complete=!!s.completed_at&&n===expected&&!s.interrupted&&validLayout;
 const future=Date.parse(s.started_at)>at||!!(s.completed_at&&Date.parse(s.completed_at)>at);
 const stale=!!(s.completed_at&&at-Date.parse(s.completed_at)>300000);
 const quality=!valid||future||!validLayout?'invalid':!complete?'incomplete':stale?'stale':missed||errors?'degraded':'complete';
 return {quality,status:quality!=='complete'||value===null||value>baseline*1.5?'hold':'within_demo_baseline',median_ms:value,missed_stimuli:missed,false_starts:errors,miss_rate:n?missed/n:null,error_rate:n+errors?(missed+errors)/(n+errors):null,baseline_ms:baseline,delta_ms:value===null?null:value-baseline,recorded_trials:n,expected_trials:expected,non_diagnostic:true};
}
export function latest(history:Screening[],crew:Crew,mission:string,kind:Kind){
 // Latest attempt wins, including interruptions: an older good test must not mask a failed retest.
 return history.filter(s=>s.astronaut_id===crew&&s.mission_id===mission&&s.kind===kind).reverse().sort((a,b)=>{const av=Date.parse(a.started_at),bv=Date.parse(b.started_at);return (Number.isFinite(bv)?bv:Infinity)-(Number.isFinite(av)?av:Infinity)})[0]??null;
}
export function cognitiveReadiness(reaction:Screening|null,visual:Screening|null,crew:Crew,mission:string,at=Date.now()){
 const summaries:Record<string,Summary|{quality:string;status:string}>= {},alerts:Alert[]=[];
 for(const [kind,s] of [['reaction',reaction],['visual',visual]] as const){
 const value=!s?{quality:'missing',status:'hold'}:s.kind!==kind||s.astronaut_id!==crew||s.mission_id!==mission?{quality:'invalid',status:'hold'}:summarize(s,at);
 summaries[kind]=value;
 if(value.status==='hold')alerts.push({code:'NEURO_'+kind.toUpperCase(),severity:'hold',message:kind[0].toUpperCase()+kind.slice(1)+' screening requires review',action:'Complete fresh, valid NeuroVision screening and request human review. Non-diagnostic demo only.'});
 }
 return {summaries,alerts};
}
export const HISTORY_KEY='astra-neurovision-v1',OUTBOX_KEY='astra-neuro-outbox-v1';
function screeningShape(value:unknown):value is Screening {
 if(!value||typeof value!=='object')return false;const s=value as Screening;
 return typeof s.session_id==='string'&&['a01','a02'].includes(s.astronaut_id)&&['eva-042','eva-043'].includes(s.mission_id)&&['reaction','visual'].includes(s.kind)&&typeof s.started_at==='string'&&(s.completed_at===null||typeof s.completed_at==='string')&&typeof s.interrupted==='boolean'&&Array.isArray(s.trials)&&s.trials.every(t=>!!t&&typeof t==='object'&&typeof t.stimulus_at==='string'&&(t.response_ms===null||typeof t.response_ms==='number')&&typeof t.false_starts==='number'&&(t.sector===null||sectors.includes(t.sector)));
}
export function readList<T>(storage:Pick<Storage,'getItem'>,key:string):T[]{
 const raw=storage.getItem(key);if(raw===null)return [];const data=JSON.parse(raw);if(!Array.isArray(data))throw Error('Invalid local screening records');
 if(key===HISTORY_KEY&&!data.every(screeningShape))throw Error('Corrupt screening history');
 if(key===OUTBOX_KEY&&!data.every(e=>e&&typeof e.event_id==='string'&&['started','completed','interrupted'].includes(e.event)&&screeningShape(e.screening)))throw Error('Corrupt screening audit queue');return data;
}
// Save events before acknowledging completion; failed storage must be visible to the operator.
export function persistEvent(storage:Pick<Storage,'getItem'|'setItem'>,event:ScreeningEvent){
 const queue=readList<ScreeningEvent>(storage,OUTBOX_KEY);
 if(!queue.some(e=>e.event_id===event.event_id))queue.push(event);
 storage.setItem(OUTBOX_KEY,JSON.stringify(queue));
 const history=readList<Screening>(storage,HISTORY_KEY).filter(s=>s.session_id!==event.screening.session_id);
 history.push(event.screening);storage.setItem(HISTORY_KEY,JSON.stringify(history));return history;
}
let syncing:Promise<number>|null=null;
export function syncEvents(storage:Pick<Storage,'getItem'|'setItem'>=localStorage,request:typeof fetch=fetch):Promise<number>{
 if(syncing)return syncing;
 syncing=(async()=>{const pending=readList<ScreeningEvent>(storage,OUTBOX_KEY);for(const event of pending){
 const response=await request('/api/neurovision/events',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(event),signal:AbortSignal.timeout(2500)});
 if(!response.ok)throw Error('NeuroVision audit sync failed: '+response.status);
 // Re-read so new events added while the request was pending are retained.
 storage.setItem(OUTBOX_KEY,JSON.stringify(readList<ScreeningEvent>(storage,OUTBOX_KEY).filter(e=>e.event_id!==event.event_id)));
 }return readList<ScreeningEvent>(storage,OUTBOX_KEY).length;})().finally(()=>{syncing=null});return syncing;
}
