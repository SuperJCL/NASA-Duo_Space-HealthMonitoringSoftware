import * as THREE from 'three';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js';
import {cameraTargets,clampZoom,type Region} from './bodyData';
export type SceneHandle={quadriceps:(side:string)=>void;select:(region:Region)=>void;zoom:(delta:number)=>void;rotate:(delta:number)=>void;reset:()=>void;dispose:()=>void};
export function createBodyScene(host:HTMLDivElement,onSelect:(region:Region)=>void,onFailure:()=>void,reducedMotion:boolean):SceneHandle {
 const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});
 renderer.setPixelRatio(Math.min(window.devicePixelRatio,1.7));renderer.setClearColor(0x060d19,0);host.appendChild(renderer.domElement);
 renderer.domElement.setAttribute('aria-label','Interactive schematic 3D human body. Drag to rotate; use the region buttons and zoom controls for keyboard access.');
 renderer.domElement.setAttribute('role','img');
 const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(36,1,.1,100);camera.position.set(0,.4,9.5);
 const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(0,.4,0);controls.enableDamping=!reducedMotion;controls.dampingFactor=.1;controls.enablePan=false;controls.enableZoom=false;controls.minPolarAngle=.25;controls.maxPolarAngle=Math.PI-.25;
 scene.add(new THREE.AmbientLight(0xa8e6ff,1.4));const light=new THREE.DirectionalLight(0x4ce4f5,3);light.position.set(3,4,5);scene.add(light);const rim=new THREE.DirectionalLight(0xff9a62,2.5);rim.position.set(-4,1,-2);scene.add(rim);
 const body=new THREE.Group();scene.add(body);
 const cyan=new THREE.MeshPhongMaterial({color:0x319ab8,emissive:0x092c40,transparent:true,opacity:.18,shininess:110,side:THREE.DoubleSide,depthWrite:false});
 const bone=new THREE.MeshPhongMaterial({color:0x96d9ed,emissive:0x164760,transparent:true,opacity:.65,shininess:80});
 const orange=new THREE.MeshPhongMaterial({color:0xff9a62,emissive:0x6c2b11,transparent:true,opacity:.95});
 const organ=new THREE.MeshPhongMaterial({color:0x4ce4f5,emissive:0x145668,transparent:true,opacity:.5,depthWrite:false});
 const objects:THREE.Object3D[]=[];const regionMeshes:Record<Region,THREE.Mesh[]>={brain:[],cardiovascular:[],respiratory:[],musculoskeletal:[]};
 function ellipsoid(position:number[],scale:number[],material:THREE.Material,region:Region,rotation=0){const mesh=new THREE.Mesh(new THREE.SphereGeometry(1,24,18),material.clone());mesh.position.set(...position as [number,number,number]);mesh.scale.set(...scale as [number,number,number]);mesh.rotation.z=rotation;mesh.userData.region=region;body.add(mesh);objects.push(mesh);regionMeshes[region].push(mesh);return mesh}
 function tube(points:number[][],radius:number,material:THREE.Material,region:Region){const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p as [number,number,number])));const mesh=new THREE.Mesh(new THREE.TubeGeometry(curve,24,radius,6,false),material.clone());mesh.userData.region=region;body.add(mesh);objects.push(mesh);regionMeshes[region].push(mesh);return mesh}
 // Procedural anatomical schematic: full body, internal organs, ribs, spine and long bones.
 ellipsoid([0,2.68,0],[.35,.46,.3],cyan,'brain');ellipsoid([0,2.45,.13],[.26,.22,.23],cyan,'brain');ellipsoid([0,2.12,0],[.16,.2,.16],cyan,'musculoskeletal');
 ellipsoid([0,1.45,0],[.66,.68,.28],cyan,'cardiovascular');ellipsoid([0,.68,0],[.45,.45,.25],cyan,'respiratory');ellipsoid([0,.17,0],[.53,.34,.28],cyan,'musculoskeletal');
 for(const side of [-1,1]){
 ellipsoid([side*.81,1.35,0],[.17,.58,.17],cyan,'musculoskeletal',side*.2);ellipsoid([side*1.0,.42,.01],[.13,.49,.13],cyan,'musculoskeletal',side*.12);ellipsoid([side*1.08,-.13,.04],[.14,.22,.09],cyan,'musculoskeletal');
 for(let i=0;i<5;i++)ellipsoid([side*(.98+i*.045),-.39+(i===0?.09:0),.05],[.023,.14,.026],cyan,'musculoskeletal',side*(i-2)*.08);
 ellipsoid([side*.28,-.58,0],[.23,.7,.23],cyan,'musculoskeletal',side*-.03);ellipsoid([side*.3,-1.76,0],[.16,.6,.17],cyan,'musculoskeletal');ellipsoid([side*.3,-2.4,.12],[.17,.13,.31],cyan,'musculoskeletal');
 tube([[side*.55,1.87,0],[side*.88,.89,0],[side*1.03,.0,.02]],.032,bone,'musculoskeletal');tube([[side*.25,.16,0],[side*.29,-1.15,0],[side*.31,-2.3,.02]],.045,bone,'musculoskeletal');
 for(const y of [.89,-1.15])ellipsoid([side*(y>0?.88:.29),y,0],[.09,.09,.09],bone,'musculoskeletal');
 ellipsoid([side*.29,1.48,.06],[.24,.44,.18],organ,'respiratory',side*.07);
 ellipsoid([side*.14,2.77,.04],[.15,.24,.2],organ,'brain');ellipsoid([side*.13,2.62,.26],[.057,.038,.045],orange,'brain');
 for(let i=0;i<6;i++){const y=1.84-i*.13;tube([[0,y,.22],[side*.33,y+.025,.27],[side*.53,y-.1,.12],[side*.31,y-.17,-.12]],.012,bone,'musculoskeletal')}
 // Branching vessels and simplified brain folds.
 tube([[side*.12,2.18,.03],[side*.19,1.75,.04],[side*.35,.82,.07],[side*.27,-.2,.07],[side*.28,-1.85,.1]],.014,orange,'cardiovascular');
 for(let i=0;i<5;i++)tube([[side*.04,2.59+i*.06,.2],[side*.14,2.61+i*.06,.23],[side*.25,2.57+i*.06,.12]],.01,bone,'brain');
 }
 tube([[0,2.0,-.08],[0,1.3,-.1],[0,.6,-.12],[0,.2,-.1]],.04,bone,'musculoskeletal');
 for(let i=0;i<13;i++)ellipsoid([0,1.98-i*.14,-.13],[.07,.035,.07],bone,'musculoskeletal');
 ellipsoid([-.12,1.28,.24],[.16,.22,.12],orange,'cardiovascular',-.4);ellipsoid([-.19,1.42,.23],[.09,.09,.1],orange,'cardiovascular');ellipsoid([-.04,1.43,.23],[.09,.09,.1],orange,'cardiovascular');
 tube([[0,2.12,.1],[0,1.74,.15],[-.2,1.55,.15]],.025,organ,'respiratory');tube([[0,1.74,.15],[.2,1.55,.15]],.025,organ,'respiratory');
 const ring=new THREE.Mesh(new THREE.TorusGeometry(1.1,.007,8,128),new THREE.MeshBasicMaterial({color:0x4ce4f5,transparent:true,opacity:.6}));ring.rotation.x=Math.PI/2;ring.position.y=-2.58;scene.add(ring);
 const ring2=ring.clone();ring2.scale.setScalar(1.35);scene.add(ring2);
 const grid=new THREE.GridHelper(7,28,0x184459,0x0e2639);grid.position.y=-2.6;scene.add(grid);
 let disposed=false,frame=0,last=0,transition=false;
 const goalTarget=new THREE.Vector3(0,.4,0);let goalDistance=9.5;
 function select(next:Region){const t=cameraTargets[next];goalTarget.set(0,t.y,0);goalDistance=t.distance;transition=true;for(const key of Object.keys(regionMeshes) as Region[])for(const mesh of regionMeshes[key]){const material=mesh.material as THREE.MeshPhongMaterial;if(!mesh.userData.originalEmissive)mesh.userData.originalEmissive=material.emissive.clone();material.emissive.copy(key===next?new THREE.Color(0x695024):mesh.userData.originalEmissive);}if(reducedMotion){const dir=camera.position.clone().sub(controls.target).normalize();controls.target.copy(goalTarget);camera.position.copy(goalTarget).addScaledVector(dir,goalDistance);transition=false;controls.update();render()}}
 function render(){renderer.render(scene,camera)}
 function animate(time:number){if(disposed)return;frame=requestAnimationFrame(animate);if(time-last<32)return;last=time;if(transition){const offset=camera.position.clone().sub(controls.target).normalize();controls.target.lerp(goalTarget,.12);const distance=THREE.MathUtils.lerp(camera.position.distanceTo(controls.target),goalDistance,.12);camera.position.copy(controls.target).addScaledVector(offset,distance);if(controls.target.distanceTo(goalTarget)<.005&&Math.abs(distance-goalDistance)<.02)transition=false}controls.update();render()}
 const resize=()=>{const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();render()};const observer=new ResizeObserver(resize);observer.observe(host);resize();frame=requestAnimationFrame(animate);
 let down={x:0,y:0};const pointerDown=(e:PointerEvent)=>{down={x:e.clientX,y:e.clientY}};
 const pick=(e:PointerEvent)=>{if(Math.hypot(e.clientX-down.x,e.clientY-down.y)>8)return;const rect=renderer.domElement.getBoundingClientRect(),ray=new THREE.Raycaster();ray.setFromCamera(new THREE.Vector2((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1),camera);const hit=ray.intersectObjects(objects)[0];if(hit){const next=hit.object.userData.region as Region;select(next);onSelect(next)}};
 const lost=(e:Event)=>{e.preventDefault();onFailure()};renderer.domElement.addEventListener('webglcontextlost',lost);renderer.domElement.addEventListener('pointerdown',pointerDown);renderer.domElement.addEventListener('pointerup',pick);
 controls.addEventListener('start',()=>{transition=false});
 return {quadriceps(side){select('musculoskeletal');goalTarget.set(side==='left'?.28:-.28,-.58,0);goalDistance=4;for(const mesh of regionMeshes.musculoskeletal){if(Math.abs(mesh.position.y+.58)<.02){const mat=mesh.material as THREE.MeshPhongMaterial;mat.emissive.setHex((side==='left'?mesh.position.x>0:mesh.position.x<0)?0xff7733:0x092c40)}}if(reducedMotion){controls.target.copy(goalTarget);camera.position.set(goalTarget.x,goalTarget.y,goalDistance);controls.update();render()}},select,zoom(delta){goalDistance=clampZoom(camera.position.distanceTo(controls.target)+delta);goalTarget.copy(controls.target);transition=true;if(reducedMotion){const offset=camera.position.clone().sub(controls.target).normalize();camera.position.copy(controls.target).addScaledVector(offset,goalDistance);transition=false;render()}},rotate(delta){const offset=camera.position.clone().sub(controls.target);offset.applyAxisAngle(new THREE.Vector3(0,1,0),delta);camera.position.copy(controls.target).add(offset);controls.update();render()},reset(){goalTarget.set(0,.4,0);goalDistance=9.5;camera.position.set(0,.4,9.5);controls.target.copy(goalTarget);transition=false;controls.update();render()},dispose(){disposed=true;cancelAnimationFrame(frame);observer.disconnect();controls.dispose();renderer.domElement.removeEventListener('webglcontextlost',lost);renderer.domElement.removeEventListener('pointerdown',pointerDown);renderer.domElement.removeEventListener('pointerup',pick);scene.traverse(obj=>{if(obj instanceof THREE.Mesh||obj instanceof THREE.LineSegments){obj.geometry.dispose();const mats=Array.isArray(obj.material)?obj.material:[obj.material];mats.forEach(m=>m.dispose())}});renderer.dispose();renderer.domElement.remove()}};
}
