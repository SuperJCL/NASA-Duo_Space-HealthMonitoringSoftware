export const baselines = {
 a01:{name:'Maya Chen',role:'EVA Commander',heart_rate:62,systolic:116,diastolic:74,reaction_ms:280},
 a02:{name:'Alex Rivera',role:'Field Geologist',heart_rate:70,systolic:122,diastolic:78,reaction_ms:310}
};
export type Crew=keyof typeof baselines;
export type Assessment={astronaut_id:Crew;mission_id:string;sleep:number|null;stress:number|null;heart_rate:number|null;systolic:number|null;diastolic:number|null;symptoms:string[];reaction_ms:number|null;age_seconds:number};
export type Alert={code:string;severity:'critical'|'hold'|'caution'|'info';message:string;action:string};
export type Result={status:string;alerts:Alert[];rules_version:string;id?:number};
export const rank={critical:0,hold:1,caution:2,info:3};
export const sort=(a:Alert[])=>a.sort((x,y)=>rank[x.severity]-rank[y.severity]||x.code.localeCompare(y.code));
export function assess(d:Assessment):Result {
 const b=baselines[d.astronaut_id], a:Alert[]=[];
 const add=(code:string,severity:Alert['severity'],message:string,action:string)=>a.push({code,severity,message,action});
 if([d.sleep,d.stress,d.heart_rate,d.systolic,d.diastolic,d.reaction_ms].some(x=>x===null)||!d.symptoms.length)add('MISSING_DATA','hold','Required assessment data missing','Complete all measures and symptom check.');
 if(d.age_seconds>300)add('STALE_DATA','hold','Assessment measurements are stale','Repeat assessment with fresh measurements.');
 if(d.symptoms.includes('none')&&d.symptoms.length>1)add('INVALID_SYMPTOMS','hold','Conflicting symptom entries','Correct symptom selection.');
 if(d.systolic!==null&&d.diastolic!==null&&d.systolic<=d.diastolic)add('INVALID_BP','hold','Blood pressure values inconsistent','Repeat blood pressure measurement.');
 if(d.symptoms.some(s=>['chest pain','shortness of breath'].includes(s)))add('SEVERE_SYMPTOM','critical','Serious symptom reported','Do not start EVA. Seek human medical review.');
 else if(d.symptoms.some(s=>s!=='none'))add('SYMPTOM','hold','Symptom reported','Human medical review required before EVA.');
 if(d.sleep!==null&&d.sleep<6)add('SLEEP','hold','Sleep below demo readiness threshold','Rest and reassess with a human reviewer.');
 if(d.stress!==null&&d.stress>=7)add('STRESS','hold','Elevated reported stress','Pause and request human review.');
 if(d.heart_rate!==null&&Math.abs(d.heart_rate-b.heart_rate)>25)add('HR','hold','Heart rate differs from individual baseline','Rest, repeat measure, and request review.');
 if(d.systolic!==null&&d.diastolic!==null&&(Math.abs(d.systolic-b.systolic)>25||Math.abs(d.diastolic-b.diastolic)>15))add('BP','hold','Blood pressure differs from baseline','Repeat measurement and request human review.');
 if(d.reaction_ms!==null&&d.reaction_ms>b.reaction_ms*1.5)add('REACTION','hold','Reaction time slower than individual baseline','Rest and repeat reaction test.');
 return {status:a.length?'hold':'awaiting_human',alerts:sort(a),rules_version:'demo-v1'};
}
export function telemetry(vo2:number|null,vco2:number|null,oxygen:number|null,co2:number|null,stale=false){
 const rer=vo2!==null&&vo2>0&&vco2!==null?Math.round(vco2/vo2*1000)/1000:null;
 const a:Alert[]=[];
 if([vo2,vco2,oxygen,co2].includes(null)||stale)a.push({code:'SENSOR_QUALITY',severity:'hold',message:'Missing or stale sensor data',action:'Pause activity and verify sensors with mission control.'});
 if(oxygen!==null&&oxygen<20)a.push({code:'O2_LOW',severity:'critical',message:'Simulated suit oxygen reserve low',action:'Stop task; contact mission control and begin simulated return protocol.'});
 if(co2!==null&&co2>=1)a.push({code:'CO2_HIGH',severity:'critical',message:'Simulated suit CO₂ elevated',action:'Stop task; verify scrubber and request mission control guidance.'});
 if(rer!==null&&rer>1.1)a.push({code:'RER_CONTEXT',severity:'info',message:'RER elevated; contextual signal only',action:'Review workload and sensor quality. RER alone never triggers abort.'});
 return {rer,alerts:sort(a)};
}
