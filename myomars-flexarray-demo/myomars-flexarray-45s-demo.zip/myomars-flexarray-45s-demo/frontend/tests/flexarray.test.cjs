const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),ts=require('typescript');
const cache={};function load(file){file=path.resolve(file);if(cache[file])return cache[file].exports;const mod={exports:{}};cache[file]=mod;const code=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText;new Function('exports','module','require',code)(mod.exports,mod,n=>n.startsWith('.')?load(path.resolve(path.dirname(file),n+'.ts')):require(n));return mod.exports}
const D=load(path.join(__dirname,'../src/flexarray/flexArrayData.ts'));
const G=load(path.join(__dirname,'../src/flexarray/flexArrayGeometry.ts'));
const allParams=()=>[...D.SYSTEM_PARAMETERS,...D.LAYERS.flatMap(l=>l.parameters)];

test('disclaimer is the exact required statement',()=>assert.equal(D.DISCLAIMER,'Conceptual engineering design — not manufactured, clinically validated, or flight-qualified.'));

test('six layers, ordered 1–6, with every inspector field populated',()=>{
 assert.equal(D.LAYERS.length,6);
 D.LAYERS.forEach((l,i)=>{assert.equal(l.index,i+1);for(const k of ['name','purpose','material','rationale','validation_summary'])assert.ok(l[k].length>10,l.id+'.'+k);
  assert.ok(l.limitations.length>0);assert.ok(l.evidence.length>0);assert.ok(l.parameters.length>0);assert.ok(['established-practice','proposed-target','pending-validation'].includes(l.validation_status))});
});

test('every parameter has the required typed fields and a consistent category/status',()=>{
 const map={A:'established-practice',B:'proposed-target',C:'pending-validation'};
 for(const p of allParams()){for(const k of ['id','label','value','unit','category','rationale','validation_status'])assert.ok(k in p,p.id+' missing '+k);
  assert.ok('source_id' in p);assert.equal(p.validation_status,map[p.category],p.id)}
 const ids=allParams().map(p=>p.id);assert.equal(new Set(ids).size,ids.length,'parameter ids unique');
});

test('initial research settings match the brief',()=>{
 const byId=Object.fromEntries(D.SYSTEM_PARAMETERS.map(p=>[p.id,p]));
 assert.equal(byId['semg-fs'].value,'2000');assert.equal(byId['semg-band'].value,'20–500');assert.equal(byId['rms-window'].value,'500');
 assert.equal(byId['adc-res'].value,'16');assert.equal(byId['adc-res'].category,'B');assert.match(byId['imu'].value,/6-axis, 100/);
 assert.equal(byId['grid'].value,'8 × 8');assert.equal(byId['runtime'].category,'B');
});

test('every source_id and evidence link resolves to a reference',()=>{
 for(const p of allParams())if(p.source_id)assert.ok(D.referenceById(p.source_id),p.id+' → '+p.source_id);
 for(const l of D.LAYERS)for(const e of l.evidence)assert.ok(D.referenceById(e.source_id),l.id+' evidence '+e.source_id);
});

test('verified references carry full metadata; unverified ones say so',()=>{
 for(const r of D.REFERENCES){
  if(r.verification==='verified'){assert.ok(r.title!=='Reference verification pending'&&r.title.length>10,r.id);assert.ok(r.url&&/^https:\/\//.test(r.url),r.id);assert.ok(r.year,r.id);if(r.doi)assert.match(r.doi,/^10\.\d{4,}\//)}
  else assert.equal(r.title,'Reference verification pending',r.id);
 }
 const topics=D.REFERENCES.map(r=>r.venue+' '+r.topic).join(' ');
 assert.match(topics,/Biosensors and Bioelectronics/);assert.match(topics,/npj Flexible Electronics/);assert.match(topics,/NASA/);
});

test('needle geometry, penetration depth, SNR, skin safety are never presented as established or validated',()=>{
 const risky=/penetration|depth|snr|safety|biocompat|impedance|skin tolerance|drift|durab|cycles/i;
 for(const p of allParams())if(risky.test(p.label))assert.notEqual(p.category,'A',p.id+' must not be category A');
 const needle=D.LAYERS[1].parameters;
 for(const id of ['mn-depth','mn-snr','mn-safety','mn-impedance'])assert.equal(needle.find(p=>p.id===id).validation_status,'pending-validation');
 for(const id of ['mn-length','mn-diameter'])assert.match(needle.find(p=>p.id===id).label,/candidate/i);
 const text=JSON.stringify(D.LAYERS)+JSON.stringify(D.SYSTEM_PARAMETERS);
 assert.doesNotMatch(text,/\bvalidated (penetration|depth|safety)|clinically proven|flight[- ]ready|EVA[- ]ready/i);
 assert.doesNotMatch(needle.find(p=>p.id==='mn-snr').value,/\d/,'withdrawn SNR figure must not appear as a value');
});

test('8×8 grid is never equated with 64 independent channels',()=>{
 const text=JSON.stringify(D.LAYERS)+JSON.stringify(D.SYSTEM_PARAMETERS);
 assert.doesNotMatch(text,/64[- ]channels?(?! by default| automatically)(?![^"]*not)/i);
 const mono=D.channelEstimate(8,8,'monopolar',32);assert.equal(mono.sites,64);assert.equal(mono.derivations,64);assert.equal(mono.digitized,32);
 const diff=D.channelEstimate(8,8,'single-differential',64);assert.equal(diff.derivations,56);assert.equal(diff.digitized,56);
 assert.match(diff.note,/not independent/);
 assert.equal(D.channelEstimate(4,4,'monopolar',64).digitized,16);
});

test('parameters group into the three explicit categories',()=>{
 const groups=D.parametersByCategory(D.LAYERS[1].parameters);
 assert.deepEqual(groups.map(g=>g.label),['Established Measurement Parameters','Proposed Engineering Targets','Pending Validation']);
 assert.equal(groups.reduce((n,g)=>n+g.items.length,0),D.LAYERS[1].parameters.length);
});

test('assembled layers stack without gaps; exploded view separates them monotonically',()=>{
 const n=G.LAYER_GEOMETRY.length;assert.equal(n,6);assert.equal(G.layerY(n-1,0),0);
 for(let i=0;i<n-1;i++){assert.ok(Math.abs(G.layerY(i,0)-(G.layerY(i+1,0)+G.LAYER_GEOMETRY[i+1].thickness))<1e-9,'touching '+i);
  assert.ok(G.layerY(i,1)-G.layerY(i+1,1)>1,'exploded gap '+i)}
 assert.equal(G.layerY(0,2),G.layerY(0,1),'explode factor clamped');
 for(let t=0;t<=1;t+=.25)assert.ok(G.layerY(0,t)<=G.layerY(0,t+.25)+1e-9);
});

test('electrode grid uses the configured pitch and is centered',()=>{
 const pts=G.electrodeGrid(8,8,.5);assert.equal(pts.length,64);
 assert.ok(Math.abs(pts.reduce((s,p)=>s+p.x,0))<1e-9);assert.ok(Math.abs(pts[1].x-pts[0].x-.5)<1e-9);
 assert.ok(Math.max(...pts.map(p=>Math.abs(p.x)))<G.FOOTPRINT.width/2);
});

test('serpentine interconnect straightens under strain while conserving trace length',()=>{
 const L0=G.polylineLength(G.serpentine(4.4,7,.16,0,800).points);
 const s=G.serpentine(4.4,7,.16,.3,800);
 assert.ok(s.span>4.4*1.29);assert.ok(s.amplitude<.16);
 assert.ok(Math.abs(G.polylineLength(s.points)-L0)/L0<.03,'arc length within 3%');
});

test('skin model reports a nominal tip layer, not a penetration measurement',()=>{
 assert.equal(G.nominalTipLayer(10),'Stratum corneum');assert.equal(G.nominalTipLayer(200),'Dermis');
 assert.ok(G.clampDistance(1)>=4&&G.clampDistance(100)<=24);
});

// ---------- visualization scale (presentation vs engineering) ----------
test('presentation scale readout: 64×48 mm, 5 mm pitch, 200 µm candidate, 3.6 mm drawn = 18×',()=>{
 const r=G.scaleReadout('presentation');
 assert.deepEqual([...r.footprintMm],[64,48]);assert.equal(r.pitchMm,5);assert.equal(r.candidateNeedleUm,200);
 assert.equal(r.renderedNeedleMm,3.6);assert.equal(r.needleExaggeration,18);
 assert.ok(r.thickness.every(t=>t.exaggeration>1),'every presentation thickness is exaggerated');
 assert.match(G.SCALE_PROFILES.presentation.badge,/NOT TO SCALE/);
});
test('engineering scale draws the candidate needle at 1× and keeps footprint and pitch',()=>{
 const r=G.scaleReadout('engineering');
 assert.equal(r.renderedNeedleMm,0.2);assert.equal(r.needleExaggeration,1);
 assert.ok(r.thickness.every(t=>Math.abs(t.renderedUm-t.engineeringUm)<=1));
 assert.ok(Math.abs(G.SCALE_PROFILES.engineering.needle.radius*2*G.UNIT_MM*1000-60)<1e-9,'60 µm base diameter');
 assert.equal(G.electrodeGrid(8,8)[1].x-G.electrodeGrid(8,8)[0].x,0.5,'5 mm pitch in both modes');
 assert.match(G.SCALE_PROFILES.engineering.badge,/not a manufacturing spec/i);
});
test('every engineering dimension is labelled candidate, assumption or design — never validated',()=>{
 const bases=[...Object.values(G.ENGINEERING_THICKNESS).map(t=>t.basis),...G.ENGINEERING_DETAILS.map(d=>d.basis)];
 assert.ok(bases.every(b=>['candidate','assumption','design'].includes(b)));
 assert.ok(Object.values(G.ENGINEERING_THICKNESS).filter(t=>t.basis==='assumption').length>=4,'unknown thicknesses stay assumptions');
 const text=JSON.stringify([G.ENGINEERING_THICKNESS,G.ENGINEERING_DETAILS,G.BASIS_LABELS]);
 assert.doesNotMatch(text,/validated|qualified|manufacturing spec(?!ification)/i);
 assert.equal(G.ENGINEERING_THICKNESS['protective-film'].basis,'candidate');
});
test('engineering stack geometry follows the profile; explode spacing unchanged',()=>{
 const n=6;assert.equal(G.layerY(n-1,0,'engineering'),0);
 assert.ok(Math.abs(G.layerY(0,0,'engineering')*G.UNIT_MM-(25+200+100+50+100)/1000)<1e-9,'layer 1 sits on 475 µm of layers 2–6');
 assert.ok(Math.abs((G.layerY(0,1,'engineering')-G.layerY(0,0,'engineering'))-(G.layerY(0,1)-G.layerY(0,0)))<1e-9);
 assert.equal(G.layerY(2,0),G.LAYER_GEOMETRY[2].assembledY,'presentation default preserved');
});
test('stack-order check reports that a 200 µm needle on layer 2 does not reach skin through assumed layers 3–6',()=>{
 const r=G.scaleReadout('engineering');assert.equal(r.belowNeedleUm,450);assert.equal(r.needleReachUm,-250);
 assert.ok(r.maxComponentMm>r.engineeringStackMm,'assumed chips taller than laminate is reported');
});

// ---------- Mars EVA preparation bay backdrop ----------
const B=load(path.join(__dirname,'../src/flexarray/bayLayout.ts'));
test('bay props never enter the hologram keep-out cylinder (both qualities)',()=>{
 for(const q of ['full','lite'])for(const p of B.bayProps(q)){
  const radial=Math.hypot(p.p[0],p.p[2]);assert.ok(radial-p.r>=B.BAY.keepOut.radius,`${p.kind} at ${p.p} intrudes (radial ${radial.toFixed(1)})`);
 }
 assert.ok(B.BAY.pedestal.top<G.layerY(5,0),'pedestal sits below the skin-facing layer');
 assert.ok(B.BAY.pedestal.top>B.BAY.floorY);
});
test('every allowed camera position stays inside the room (distance + tilt limits)',()=>{
 const R=B.BAY.room,t=B.BAY.cameraTarget,dmax=B.BAY.maxCameraDistance,m=1;
 for(let phi=0;phi<=B.BAY.maxPolarAngle+1e-9;phi+=0.04)for(let th=0;th<Math.PI*2;th+=0.05){
  const x=t[0]+dmax*Math.sin(phi)*Math.sin(th),y=t[1]+dmax*Math.cos(phi),z=t[2]+dmax*Math.sin(phi)*Math.cos(th);
  // room is rotated by yaw about Y; the target sits on the axis, so test in the bay-local frame
  const c=Math.cos(-B.BAY.yaw),s=Math.sin(-B.BAY.yaw),lx=x*c+z*s,lz=-x*s+z*c;
  assert.ok(lx>R.x0+m&&lx<R.x1-m&&lz>R.z0+m&&lz<R.z1-m,`outside walls at phi ${phi.toFixed(2)} theta ${th.toFixed(2)}`);
  assert.ok(y>B.BAY.floorY+m&&y<B.BAY.ceilingY-m,`outside floor/ceiling at phi ${phi.toFixed(2)}`);
 }
 const d=Math.hypot(...G.CAMERA_DEFAULT.position.map((v,i)=>v-t[i]));assert.ok(d<dmax,'default framing within the limit');
});
test('bay is turned to face the default camera; Mars window is behind the hologram',()=>{
 const [cx,,cz]=G.CAMERA_DEFAULT.position;
 const back=[-Math.sin(B.BAY.yaw),-Math.cos(B.BAY.yaw)],view=[-cx/Math.hypot(cx,cz),-cz/Math.hypot(cx,cz)];
 assert.ok(Math.abs(back[0]*view[0]+back[1]*view[1]-1)<1e-9,'back wall faces the camera');
 const w=B.BAY.window;assert.ok(w.x0<0&&w.x1>0,'window spans the view axis');assert.equal(w.wallZ,B.BAY.room.z0);
});
test('lite quality: fewer suits and particles, no light shafts, smaller textures; picks lite on phones',()=>{
 assert.ok(B.bayProps('lite').filter(p=>p.kind==='suit').length<B.bayProps('full').filter(p=>p.kind==='suit').length);
 assert.ok(B.BAY_SETTINGS.lite.dust<B.BAY_SETTINGS.full.dust);assert.equal(B.BAY_SETTINGS.lite.shafts,false);
 assert.ok(B.BAY_SETTINGS.lite.marsTexture<B.BAY_SETTINGS.full.marsTexture);
 assert.equal(B.bayQuality(390,8),'lite');assert.equal(B.bayQuality(1600,8),'full');assert.equal(B.bayQuality(1600,4),'lite');
});
test('generated Mars landscape is deterministic (seeded PRNG + normalised ridges)',()=>{
 const a=B.ridge(B.mulberry32(7),8,0.6),b=B.ridge(B.mulberry32(7),8,0.6);
 assert.deepEqual(a,b);assert.equal(a.length,257);assert.equal(Math.min(...a),0);assert.equal(Math.max(...a),1);
 assert.notDeepEqual(B.ridge(B.mulberry32(8),8,0.6),a);
});

// ---------- guided demo ----------
const DM=load(path.join(__dirname,'../src/flexarray/demoScript.ts'));
const MS=load(path.join(__dirname,'../src/muscleSense.ts'));
const BOUNDS=[[0,7000],[7000,18000],[18000,32000],[32000,45000]];
test('demo is exactly 45 s of scripted content in four contiguous scenes at the agreed boundaries',()=>{
 assert.equal(DM.DEMO_TOTAL,45000);
 assert.deepEqual(DM.SCENES.map(s=>s.id),['before-eva','technology','during-eva','medical-review']);
 assert.deepEqual(DM.SCENES.map(s=>s.title),['Before EVA','FlexArray Technology','AI Muscle Monitoring','Mars Base Medical Review']);
 assert.deepEqual(DM.SCENES.map(s=>[s.start,s.end]),BOUNDS,'0:00–0:07, 0:07–0:18, 0:18–0:32, 0:32–0:45');
 DM.SCENES.forEach((s,i)=>{assert.equal(s.start,i?DM.SCENES[i-1].end:0);assert.ok(s.beats.length>0);
  s.beats.forEach((b,j)=>{assert.ok(b.at>=s.start&&b.at<s.end,`${b.id} inside ${s.id}`);if(j)assert.ok(b.at>s.beats[j-1].at)})});
 assert.equal(DM.SCENES.reduce((n,s)=>n+s.end-s.start,0),45000);
 for(const [i,[a,b]] of BOUNDS.entries()){assert.equal(DM.sceneAt(a),i);assert.equal(DM.sceneAt(b-1),i)}
 assert.equal(DM.sceneAt(45000),3);
 assert.equal(DM.SCENES[0].beats.length,1,'scene 1 keeps one short caption');
 // the scripted clock: 45 000 ms of playback time from start to end once the reviewer has confirmed
 let t=0,ms=0,r;while(!(r=DM.advance(t,250,true)).ended){t=r.t;ms+=250}
 assert.equal(ms+250,45000);
});
test('scene 2 explodes the patch and highlights microneedle, sweat-management and electronics layers in order',()=>{
 const s=DM.SCENES[1];assert.equal(s.beats[0].cue.explode,true);assert.equal(s.beats[0].cue.camera,'patch');
 assert.deepEqual(s.beats.map(b=>b.cue.select).filter(Boolean),['microneedle-array','sweat-management','flex-electronics']);
 s.beats.forEach((b,j)=>{const next=j+1<s.beats.length?s.beats[j+1].at:s.end;assert.ok(next-b.at>=2500,`${b.id} is on screen for ≥ 2.5 s`)});
 assert.equal(DM.cueAt(DM.SCENES[2].start).explode,false,'scene 3 returns to the assembled patch');
});
test('demo data come from the existing MuscleSense simulation; the alert appears only once its rule triggers',()=>{
 assert.deepEqual(DM.leftBaseline,MS.muscleBaseline('a01','left'));
 DM.leftSeries.forEach((s,i)=>assert.deepEqual(s,MS.muscleSample('a01','left',i+1,'fatigue')));
 const first=DM.leftSeries.findIndex((_,i)=>MS.muscleSummary(DM.leftSeries.slice(0,i+1),DM.leftBaseline).status.startsWith('Fatigue-related'))+1;
 assert.equal(DM.flagSecond,first);assert.ok(first>=5);
 assert.ok(DM.leftSeries.every(s=>s.quality>=80&&s.contact&&!s.artifact),'evidence has interpretable signal quality');
 const s3=DM.SCENES[2],ev=s3.beats.find(b=>b.id==='event'),sent=s3.beats.find(b=>b.id==='sent');
 assert.equal(ev.at,DM.EVENT_AT);
 const flagged=t=>MS.muscleSummary(DM.leftSeries.slice(0,DM.hudSecond(t)),DM.leftBaseline).status.startsWith('Fatigue-related');
 for(let t=s3.start;t<s3.end;t+=25){
  const id=DM.beatAt(t).id;
  if(id==='event'||id==='sent')assert.ok(flagged(t),`alert caption at ${t} ms only after the rule has triggered`);
  if(!flagged(t))assert.ok(t<ev.at,'no alert caption while the rule is not met');
  if(t>=ev.at)assert.ok(flagged(t),'HUD alert stays up for the rest of scene 3');
 }
 assert.ok(DM.hudSecond(ev.at)>=DM.flagSecond,'event caption never precedes the data flag');
 assert.ok(DM.hudSecond(ev.at-1000)<DM.flagSecond,'event caption follows the data flag within 1 s');
 assert.ok(sent.at-ev.at>=3000&&s3.end-sent.at>=2500,'alert and hand-off are each readable');
 assert.equal(DM.hudSecond(s3.end-1),DM.EVA_SECONDS,'all 30 synthetic samples play within scene 3');
 assert.equal(DM.reassessSummary.status,'No demo trend flag');
});
test('human reviewer gate: the clock pauses there until a person confirms, then plays the remaining scripted time',()=>{
 const s4=DM.SCENES[3],gates=DM.SCENES.flatMap(s=>s.beats).filter(b=>b.gate);
 assert.equal(gates.length,1);assert.equal(gates[0].at,DM.GATE_AT);assert.equal(DM.GATE_AT,35000);assert.ok(DM.GATE_AT>s4.start);
 for(const id of ['instruction','ack','reassess'])assert.ok(s4.beats.find(b=>b.id===id).at>DM.GATE_AT);
 let t=0,r;for(let i=0;i<2000;i++){r=DM.advance(t,250,false);t=r.t}   // 500 s of unconfirmed playback
 assert.equal(t,DM.GATE_AT);assert.equal(r.atGate,true);assert.equal(r.ended,false);
 let ms=0;while(!(r=DM.advance(t,250,true)).ended){t=r.t;ms+=250}
 assert.equal(DM.GATE_AT+ms+250,45000,'after confirmation the remaining scripted time plays out');
 assert.equal(DM.nextStop(DM.SCENES[2].start+1000,false),DM.SCENES[3].start);
 assert.equal(DM.nextStop(DM.SCENES[3].start+100,false),DM.GATE_AT,'Next stops at the gate');
 assert.equal(DM.clampToGate(DM.DEMO_TOTAL,false),DM.GATE_AT);
 r=DM.advance(DM.GATE_AT,DM.DEMO_TOTAL,true);assert.equal(r.t,DM.DEMO_TOTAL);assert.equal(r.ended,true);
 assert.equal(DM.prevStop(DM.SCENES[1].start+5000),DM.SCENES[1].start);assert.equal(DM.prevStop(DM.SCENES[1].start+500),0);
 assert.match(gates[0].sub,/elapsed time may exceed 45 s/i,'UI explains that real time can exceed 45 s');
 assert.match(gates[0].confirmedCaption,/demo reviewer \(simulated\)/i);assert.match(gates[0].confirmedSub,/no real authorization/i);
});
test('demo wording: ≤ 10-word captions, synthetic/simulated labels, no diagnosis claim, no RER abort, nothing prescribed',()=>{
 const count=x=>x.split(/\s+/).filter(w=>/[A-Za-z0-9]/.test(w)).length;
 assert.equal(DM.MAX_CAPTION_WORDS,10);assert.equal(DM.wordCount('8 × 8 candidate sites · not validated'),6);
 const lines=[...DM.SCENES.flatMap(s=>s.beats.flatMap(b=>[b.caption,b.sub,b.confirmedCaption,b.confirmedSub])),DM.END_CAPTION.caption,DM.END_CAPTION.sub].filter(Boolean);
 for(const l of lines){assert.ok(count(l)<=10,`"${l}" has ${count(l)} words`);assert.ok(DM.wordCount(l)<=10)}
 const text=lines.join(' | ')+' | '+DM.RETEST_INSTRUCTION;
 for(const m of text.matchAll(/diagnos\w*/gi))assert.match(text.slice(Math.max(0,m.index-6),m.index),/not a $/i,'every diagnosis mention is negated');
 assert.match(DM.SCENES[2].beats.find(b=>b.id==='event').sub,/^Not a diagnosis/);
 assert.match(DM.SCENES[0].beats[0].sub,/synthetic/i);assert.match(DM.SCENES[2].beats[0].caption,/simulated/i);
 assert.match(DM.SCENES[3].beats.find(b=>b.id==='instruction').caption,/simulated/i);
 assert.doesNotMatch(text,/\bRER\b|respiratory exchange|abort/i,'the demo never uses RER or triggers an abort');
 assert.doesNotMatch(DM.RETEST_INSTRUCTION,/\d|minute|hour|day|medic|dose|drug/i);
 assert.match(DM.DEMO_REVIEWER,/simulated/i);
});
test('demo camera shots stay inside the bay and within the camera limits',()=>{
 for(const [name,shot] of Object.entries(DM.DEMO_SHOTS)){
  const [x,y,z]=shot.position,t=B.BAY.cameraTarget,d=Math.hypot(x-t[0],y-t[1],z-t[2]);
  assert.ok(d<=B.BAY.maxCameraDistance,name+' distance '+d.toFixed(1));
  const c=Math.cos(-B.BAY.yaw),s=Math.sin(-B.BAY.yaw),lx=x*c+z*s,lz=-x*s+z*c,R=B.BAY.room;
  assert.ok(lx>R.x0&&lx<R.x1&&lz>R.z0&&lz<R.z1&&y>B.BAY.floorY&&y<B.BAY.ceilingY,name+' inside room');
 }
});
