// Browser tests for the FlexArray-MN showcase page. Serve the production build first, e.g.
//   npm run build && npx vite preview --host 127.0.0.1 --port 4173
//   ASTRA_URL=http://127.0.0.1:4173 node tests/flexarray-browser.cjs
// (Also works against the FastAPI single-server demo at the default http://127.0.0.1:8000.)
const {chromium}=require('playwright'),assert=require('node:assert/strict');
const BASE=(process.env.ASTRA_URL||'http://127.0.0.1:8000')+'/#flexarray';
const DISCLAIMER='Conceptual engineering design — not manufactured, clinically validated, or flight-qualified.';
const LAYER_IDS=['protective-film','microneedle-array','sweat-management','flex-electronics','stretchable-interconnect','adhesive-frame'];
const results=[],perf={};
// average frames per second over `ms` (requestAnimationFrame), used to report the cost of the backdrop
const fps=(page,ms=3000)=>page.evaluate(ms=>new Promise(r=>{let n=0;const t0=performance.now();const f=()=>{n++;if(performance.now()-t0<ms)requestAnimationFrame(f);else r(+(n*1000/(performance.now()-t0)).toFixed(1))};requestAnimationFrame(f)}),ms);
async function step(name,fn){const t=Date.now();try{await fn();results.push(['PASS',name,Date.now()-t])}catch(e){results.push(['FAIL',name,Date.now()-t,e.message.split('\n')[0]]);throw e}}

const panelTitle=page=>page.locator('#fa-inspector-title').innerText();
const panelClosed=page=>page.waitForFunction(()=>!document.querySelector('#fa-inspector-title'));
async function open(page){await page.goto(BASE);await page.locator('.fa-viewport[data-renderer="3d"] canvas').waitFor();await page.waitForFunction(()=>document.querySelector('.fa-viewport')?.getAttribute('data-explode-progress')==='1')}
async function view(page,mode){await page.getByLabel('View',{exact:true}).selectOption(mode);await page.waitForTimeout(1400)}
async function openSheet(page,tab){
 if(!(await page.locator('.fa-sheet').count()))await page.getByRole('button',{name:'Research & References'}).click();
 await page.locator('.fa-sheet').getByRole('tab',{name:tab}).click();
}
async function closeSheet(page){await page.getByRole('button',{name:'Close research panel'}).click();await page.locator('.fa-sheet').waitFor({state:'detached'})}
async function recordProgress(page,action,target){
 await page.evaluate(()=>{window.__fa=[];const el=document.querySelector('.fa-viewport');window.__faObs=new MutationObserver(()=>window.__fa.push(Number(el.getAttribute('data-explode-progress'))));window.__faObs.observe(el,{attributes:true,attributeFilter:['data-explode-progress']})});
 await action();
 await page.waitForFunction(t=>document.querySelector('.fa-viewport').getAttribute('data-explode-progress')===String(t),target);
 return page.evaluate(()=>{window.__faObs.disconnect();return window.__fa});
}

(async()=>{
 const browser=await chromium.launch({headless:true,args:['--enable-unsafe-swiftshader']});
 let failed=false;
 try{
  // ---------- desktop ----------
  const ctx=await browser.newContext({viewport:{width:1512,height:945}}),page=await ctx.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));page.setDefaultTimeout(15000);
  await step('route: #flexarray opens a full-screen showcase (no console shell), minimal header, disclaimer',async()=>{
   await open(page);
   assert.equal(await page.locator('.fa-title').innerText(),'ASTRA FlexArray-MN');
   assert.equal(await page.locator('.fa-subtitle').innerText(),'Interactive 3D Layer Explorer');
   assert.equal(await page.locator('nav').count(),0,'no navigation menu on this page');
   assert.equal(await page.locator('aside').count(),0,'no console sidebar');
   assert.equal(await page.getByTestId('fa-disclaimer').first().innerText(),DISCLAIMER);
   const vp=await page.locator('.fa-viewport canvas').boundingBox();
   assert.ok(vp.width*vp.height>=0.75*1512*945,'3D viewer uses ≥ 75 % of the visual area');
   assert.equal(await page.locator('#fa-inspector-title').count(),0,'technical details hidden by default');
  });
  await step('Mars EVA bay backdrop: on by default, labelled not-to-scale, switchable to Minimal; frame rate measured',async()=>{
   const vp=page.locator('.fa-viewport');
   assert.equal(await vp.getAttribute('data-environment'),'bay');
   assert.equal(await vp.getAttribute('data-quality'),'full');
   assert.match(await page.getByTestId('fa-backdrop-note').innerText(),/bay backdrop not to scale/i);
   perf.desktopBay=await fps(page);
   const canvas=page.locator('.fa-viewport canvas');const bay=await canvas.screenshot();
   await openSheet(page,'System settings');
   assert.match(await page.locator('.fa-sheet').innerText(),/original, procedurally generated backdrop \(no third-party assets\)/);
   await page.locator('.fa-sheet').getByRole('button',{name:'Minimal'}).click();await closeSheet(page);
   assert.equal(await vp.getAttribute('data-environment'),'minimal');assert.equal(await page.getByTestId('fa-backdrop-note').count(),0);
   await page.waitForTimeout(600);assert.notDeepEqual(await canvas.screenshot(),bay,'backdrop visibly changes');
   perf.desktopMinimal=await fps(page);
   await openSheet(page,'System settings');await page.locator('.fa-sheet').getByRole('button',{name:'Mars EVA bay'}).click();await closeSheet(page);
   assert.equal(await vp.getAttribute('data-environment'),'bay');
   assert.ok(perf.desktopBay>0&&perf.desktopMinimal>0);
  });
  await step('layer selector 01–06: each number selects its layer and opens the compact panel',async()=>{
   const nums=await page.locator('.fa-rail button .fa-rail-num').allInnerTexts();
   assert.deepEqual(nums,['01','02','03','04','05','06']);
   for(const [i,id] of LAYER_IDS.entries()){
    await page.locator(`[data-layer-button="${id}"]`).click();
    assert.equal(await page.locator(`[data-layer-button="${id}"]`).getAttribute('aria-pressed'),'true');
    assert.equal(await page.locator('.fa-panel').getAttribute('data-layer'),id);
    assert.match(await page.locator('.fa-panel .fa-kicker').innerText(),new RegExp(`Layer 0${i+1}`,'i'));
   }
  });
  await step('panel shows name, purpose, key parameters, rationale, validation; closes; full data still reachable',async()=>{
   await page.locator('[data-layer-button="microneedle-array"]').click();
   assert.equal(await panelTitle(page),'Microneedle Microelectrode Array (MN-sEMG)');
   for(const label of ['Purpose','Design rationale','Validation status'])await page.locator('.fa-panel .fa-dl dt',{hasText:label}).first().waitFor();
   assert.equal(await page.locator('.fa-keyparams li').count(),4);
   assert.match(await page.locator('[data-key-param-id="mn-depth"]').innerText(),/Not measured/);
   assert.match(await page.getByTestId('fa-panel-status').innerText(),/Pending validation/i);
   await page.locator('.fa-more summary').click();
   assert.match(await page.locator('tr[data-param-id="mn-depth"]').innerText(),/Not measured[\s\S]*Pending validation/i);
   assert.match(await page.locator('tr[data-param-id="mn-length"]').innerText(),/candidate/i);
   assert.match(await page.locator('.fa-more').innerText(),/not automatically 64 independent channels/);
   assert.match(await page.locator('.fa-more').innerText(),/10\.1016\/j\.bios\.2025\.117945/);
   await page.getByRole('button',{name:'Close layer details'}).click();await panelClosed(page);
   assert.equal(await page.locator('[data-layer-button="microneedle-array"]').getAttribute('aria-pressed'),'true','selection kept when panel closes');
   await page.locator('[data-layer-button="microneedle-array"]').click();await page.locator('[data-layer-button="microneedle-array"]').click();
   assert.equal(await panelTitle(page),'Microneedle Microelectrode Array (MN-sEMG)');
  });
  await step('assembled ↔ exploded transitions animate through intermediate states',async()=>{
   const down=await recordProgress(page,()=>page.getByRole('button',{name:'Assemble'}).click(),0);
   assert.ok(down.some(v=>v>0&&v<1),'intermediate frames: '+down.slice(0,8));
   assert.equal(await page.locator('.fa-viewport').getAttribute('data-exploded'),'false');
   const up=await recordProgress(page,()=>page.getByRole('button',{name:'Explode'}).click(),1);
   assert.ok(up.some(v=>v>0&&v<1));
  });
  await step('3D picking: clicking the model selects a layer; clicking empty space clears',async()=>{
   await page.getByRole('button',{name:'Close layer details'}).click();
   await view(page,'top');
   const box=await page.locator('.fa-viewport canvas').boundingBox();
   await page.mouse.click(box.x+box.width*.5,box.y+box.height*.5);
   await page.waitForFunction(()=>document.querySelector('#fa-inspector-title')?.textContent==='Protective & Breathable Film');
   await page.mouse.click(box.x+10,box.y+box.height-10);await panelClosed(page);
   assert.equal(await page.locator('.fa-rail button[aria-pressed="true"]').count(),0);
  });
  await step('rotate and zoom (drag, wheel, dock buttons) change the view; Reset view restores',async()=>{
   await view(page,'stack');
   const canvas=page.locator('.fa-viewport canvas'),box=await canvas.boundingBox(),before=await canvas.screenshot();
   await page.mouse.move(box.x+box.width*.3,box.y+box.height*.7);await page.mouse.down();await page.mouse.move(box.x+box.width*.55,box.y+box.height*.7,{steps:10});await page.mouse.up();
   await page.mouse.wheel(0,-400);await page.waitForTimeout(500);
   const dragged=await canvas.screenshot();assert.notDeepEqual(dragged,before);
   await page.getByRole('button',{name:'Rotate right'}).click();await page.getByRole('button',{name:'Zoom in'}).click();await page.waitForTimeout(400);
   assert.notDeepEqual(await canvas.screenshot(),dragged);
   await page.getByRole('button',{name:'Zoom out'}).click();await page.getByRole('button',{name:'Rotate left'}).click();
   await page.getByRole('button',{name:'Reset view'}).click();await page.waitForTimeout(2500);
  });
  await step('selection highlights the layer and fades others; hide / show layer',async()=>{
   const canvas=page.locator('.fa-viewport canvas');const before=await canvas.screenshot();
   await page.locator('[data-layer-button="flex-electronics"]').click();await page.waitForTimeout(900);
   assert.notDeepEqual(await canvas.screenshot(),before);
   await page.locator('.fa-chip-label',{hasText:'Analog front end'}).waitFor();
   const lit=await canvas.screenshot();
   await page.getByRole('button',{name:'Hide layer'}).click();await page.waitForTimeout(400);
   assert.notDeepEqual(await canvas.screenshot(),lit);
   assert.match(await page.locator('[data-layer-button="flex-electronics"]').getAttribute('aria-label'),/\(hidden\)/);
   await page.getByRole('button',{name:'Show layer'}).click();
  });
  await step('keyboard: viewer shortcuts, 01–06 arrow navigation, Escape',async()=>{
   await page.locator('.fa-viewport').focus();
   await page.keyboard.press('3');assert.equal(await panelTitle(page),'Sweat Management Layer');
   await page.keyboard.press('e');assert.equal(await page.locator('.fa-viewport').getAttribute('data-exploded'),'false');
   await page.keyboard.press('e');await page.keyboard.press('ArrowLeft');await page.keyboard.press('+');await page.keyboard.press('-');
   await page.keyboard.press('Escape');await panelClosed(page);
   await page.locator('[data-layer-button="protective-film"]').focus();await page.keyboard.press('ArrowDown');
   assert.equal(await panelTitle(page),'Microneedle Microelectrode Array (MN-sEMG)');
   assert.equal(await page.evaluate(()=>document.activeElement.getAttribute('data-layer-button')),'microneedle-array');
   await page.keyboard.press('ArrowRight');assert.equal(await panelTitle(page),'Sweat Management Layer');
   await page.locator('[data-layer-button="sweat-management"]').focus();await page.keyboard.press('Enter');await panelClosed(page);
  });
  await step('Research & References sheet: modal dialog, focus in, tabs by arrow keys, Escape returns focus',async()=>{
   const trigger=page.getByRole('button',{name:'Research & References'});await trigger.click();
   const dlg=page.getByRole('dialog',{name:'Research & References'});await dlg.waitFor();
   assert.equal(await dlg.getAttribute('aria-modal'),'true');
   assert.equal(await page.evaluate(()=>document.activeElement.id),'fa-sheet-title');
   assert.equal(await page.locator('.fa-refs li').count(),6);
   assert.match(await page.locator('[data-ref-id="ref-npj-2025"]').innerText(),/10\.1038\/s41528-025-00458-9/);
   assert.match(await page.locator('[data-ref-id="ref-nasa-delsys"]').innerText(),/Verified/i);
   await page.locator('.fa-sheet').getByRole('tab',{name:'References'}).focus();await page.keyboard.press('ArrowRight');
   assert.equal(await page.locator('.fa-sheet').getByRole('tab',{name:'Scale & assumptions'}).getAttribute('aria-selected'),'true');
   assert.equal(await page.locator('.fa-sheet .fa-disclaimer').innerText(),DISCLAIMER);
   await page.keyboard.press('Escape');await page.locator('.fa-sheet').waitFor({state:'detached'});
   assert.equal(await page.evaluate(()=>document.activeElement.textContent),'Research & References');
  });
  await step('engineering data remains accessible: system settings with A/B/C categories, electrode matrix',async()=>{
   await openSheet(page,'System settings');
   for(const c of ['Established Measurement Parameters','Proposed Engineering Targets'])await page.locator('.fa-sheet h4',{hasText:c}).first().waitFor();
   await page.locator('.fa-legend li',{hasText:'Pending Validation'}).waitFor();
   await openSheet(page,'Electrode matrix');
   assert.equal(await page.getByTestId('fa-sites').innerText(),'64');
   await page.getByLabel('Referencing').selectOption('monopolar');await page.getByLabel('AFE channels (TBD)').selectOption('16');
   assert.equal(await page.getByTestId('fa-digitized').innerText(),'≤ 16');
   assert.match(await page.locator('.fa-matrix-stats').innerText(),/Independent channels\s*Not established/i);
   await closeSheet(page);
  });
  await step('stretch control (layer 05) and skin / thigh views',async()=>{
   await page.locator('[data-layer-button="stretchable-interconnect"]').click();
   await page.getByLabel('Interconnect stretch strain').fill('0.3');
   await page.getByRole('checkbox',{name:/Animate stretch/}).check();
   assert.equal(await page.getByLabel('Interconnect stretch strain').isDisabled(),true);
   await page.getByRole('checkbox',{name:/Animate stretch/}).uncheck();
   await view(page,'skin');await page.locator('.fa-skin-label',{hasText:'Stratum corneum'}).waitFor();
   await page.getByLabel('Candidate needle length in micrometers').fill('120');
   assert.match(await page.locator('.fa-float-ctl .fa-warn').innerText(),/not validated/);
   assert.match(await page.getByTestId('fa-scale-badge').innerText(),/skin section/i);
   await view(page,'thigh');await page.locator('.fa-skin-tip',{hasText:'anterior thigh'}).waitFor();
   await view(page,'stack');
  });
  await step('presentation vs engineering scale: labels, geometry, assumptions and limitations stay visible',async()=>{
   const text=id=>page.getByTestId(id).innerText();
   assert.equal(await page.locator('.fa-viewport').getAttribute('data-scale'),'presentation');
   assert.equal(await text('fa-footprint'),'64 × 48 mm');assert.equal(await text('fa-pitch'),'5 mm');
   assert.equal(await text('fa-needle-candidate'),'200 µm');assert.equal(await text('fa-needle-rendered'),'3.6 mm');assert.equal(await text('fa-exaggeration'),'18×');
   assert.match(await text('fa-scale-badge'),/NOT TO SCALE/i);
   assert.match(await page.getByTestId('fa-needle-tag').innerText(),/3\.6 mm = 18× the 200 µm candidate/);
   const canvas=page.locator('.fa-viewport canvas');await page.waitForTimeout(400);const before=await canvas.screenshot();
   await page.getByRole('button',{name:'Engineering scale',exact:true}).click();
   assert.equal(await page.getByRole('button',{name:'Engineering scale',exact:true}).getAttribute('aria-pressed'),'true');
   assert.equal(await text('fa-needle-rendered'),'0.2 mm');assert.equal(await text('fa-exaggeration'),'1× (to scale)');
   assert.match(await text('fa-scale-badge'),/candidate \+ assumed dimensions · not a manufacturing spec/i);
   assert.match(await page.getByTestId('fa-needle-tag').innerText(),/200 µm \(unvalidated\)/);
   await page.waitForTimeout(400);assert.notDeepEqual(await canvas.screenshot(),before,'geometry changes with scale');
   await page.getByTestId('fa-scale-badge').click();
   assert.equal(await page.locator('.fa-sheet').getByRole('tab',{name:'Scale & assumptions'}).getAttribute('aria-selected'),'true');
   assert.match(await page.locator('tr[data-thickness-id="sweat-management"]').innerText(),/800 µm\s*200 µm\s*Assumption/i);
   assert.match(await page.locator('tr[data-thickness-id="microneedle"]').innerText(),/3600 µm\s*200 µm\s*Research candidate\s*18×/i);
   assert.match(await text('fa-reach-warning'),/≈ 250 µm short of the skin/);
   assert.match(await text('fa-component-warning'),/up to 1\.2 mm are taller than the assumed 0\.505 mm laminate/);
   await closeSheet(page);
   for(const id of LAYER_IDS){await page.locator(`[data-layer-button="${id}"]`).click();assert.equal(await page.locator('.fa-panel').getAttribute('data-layer'),id)}
   // engineering-scale 3D pick (assumed 1.2 mm chips protrude through the 0.5 mm laminate, so hide layer 04 first)
   await page.locator('[data-layer-button="flex-electronics"]').click();await page.getByRole('button',{name:'Hide layer'}).click();
   await page.getByRole('button',{name:'Close layer details'}).click();
   await view(page,'top');const box=await canvas.boundingBox();await page.mouse.click(box.x+box.width*.5,box.y+box.height*.5);
   await page.waitForFunction(()=>document.querySelector('#fa-inspector-title')?.textContent==='Protective & Breathable Film');
   // selecting a hidden layer reveals it again
   await page.locator('[data-layer-button="flex-electronics"]').click();
   assert.doesNotMatch(await page.locator('[data-layer-button="flex-electronics"]').getAttribute('aria-label'),/hidden/);
   await page.getByRole('button',{name:'Hide layer'}).waitFor();
   await view(page,'stack');const far=await canvas.screenshot();
   await page.locator('[data-layer-button="microneedle-array"]').click();await page.getByRole('button',{name:'Zoom to microneedles'}).click();await page.waitForTimeout(2500);
   assert.notDeepEqual(await canvas.screenshot(),far);
   await page.locator('.fa-viewport').focus();await page.keyboard.press('s');
   assert.equal(await page.locator('.fa-viewport').getAttribute('data-scale'),'presentation');
   await page.getByRole('button',{name:'Reset view'}).click();await page.waitForTimeout(1500);
  });
  await step('full screen toggles the showcase into the Fullscreen API and back',async()=>{
   await page.getByRole('button',{name:'Full screen'}).click();
   await page.waitForFunction(()=>document.fullscreenElement?.classList.contains('fa-root'));
   await page.getByRole('button',{name:'Exit full screen'}).click();
   await page.waitForFunction(()=>!document.fullscreenElement);
  });
  await step('WebGL context loss switches to the 2D fallback',async()=>{
   await page.evaluate(()=>document.querySelector('.fa-viewport canvas').getContext('webgl2').getExtension('WEBGL_lose_context').loseContext());
   await page.locator('.fa-viewport[data-renderer="2d"]').waitFor();
   await page.getByText(/graphics context was lost/).waitFor();
  });
  await step('back to ASTRA: other screens still work; FlexArray deep link restored',async()=>{
   await page.getByRole('button',{name:'Back to ASTRA mission console'}).click();
   assert.equal(await page.locator('h1').innerText(),'Built for the extraordinary.');
   assert.equal(await page.evaluate(()=>location.hash),'');
   await page.locator('nav').getByRole('button',{name:/Live EVA telemetry/}).click();
   await page.locator('nav').getByRole('button',{name:/FlexArray-MN patch/}).click();
   await page.locator('.fa-viewport').waitFor();assert.equal(await page.evaluate(()=>location.hash),'#flexarray');
   assert.deepEqual(errors,[]);
  });
  await step('safety: the persistent critical-alert rail stays visible on top of the showcase page',async()=>{
   await page.getByRole('button',{name:'Back to ASTRA mission console'}).click();
   await page.locator('nav').getByRole('button',{name:/Live EVA telemetry/}).click();
   await page.getByLabel('Scenario').selectOption('oxygen');
   await page.locator('.critical-rail').waitFor();
   await page.locator('nav').getByRole('button',{name:/FlexArray-MN patch/}).click();await page.locator('.fa-viewport').waitFor();
   const rail=page.locator('.critical-rail');assert.ok(await rail.isVisible());
   assert.ok(await rail.evaluate(el=>{const r=el.getBoundingClientRect();const top=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return el.contains(top)}),'rail is topmost');
   assert.ok(await page.locator('.fa-dock').evaluate((d,rb)=>d.getBoundingClientRect().bottom<=rb,(await rail.boundingBox()).y+1),'dock sits above the rail');
   await page.locator('.critical-rail').getByRole('button',{name:/Open safety guidance/}).click();
   assert.equal(await page.locator('h1').innerText(),'Signals into safe action.');
  });
  await ctx.close();

  // ---------- reduced motion ----------
  const rctx=await browser.newContext({viewport:{width:1280,height:900},reducedMotion:'reduce'}),rp=await rctx.newPage();
  await step('prefers-reduced-motion: instant transitions, no CSS animation, auto-animation disabled',async()=>{
   await open(rp);assert.equal(await rp.locator('.fa-root').getAttribute('data-motion'),'reduced');
   const seen=await recordProgress(rp,()=>rp.getByRole('button',{name:'Assemble'}).click(),0);
   assert.ok(seen.every(v=>v===0||v===1),'no intermediate frames: '+seen);
   await rp.locator('[data-layer-button="stretchable-interconnect"]').click();
   assert.equal(await rp.locator('.fa-panel').evaluate(el=>getComputedStyle(el).animationName),'none');
   assert.equal(await rp.getByRole('checkbox',{name:/Animate stretch/}).isDisabled(),true);
  });
  await rctx.close();

  // ---------- mobile / touch ----------
  const mctx=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,deviceScaleFactor:2}),mp=await mctx.newPage();
  await step('mobile: full-width viewer, no horizontal overflow, bottom-sheet panel, tap select in list and 3D',async()=>{
   await open(mp);
   assert.equal(await mp.locator('.fa-viewport').getAttribute('data-environment'),'bay');
   assert.equal(await mp.locator('.fa-viewport').getAttribute('data-quality'),'lite','phones get the lite bay');
   perf.mobileBayLite=await fps(mp);
   const overflow=await mp.evaluate(()=>document.documentElement.scrollWidth-innerWidth);assert.ok(overflow<=1,'overflow '+overflow);
   const vp=await mp.locator('.fa-viewport canvas').boundingBox();assert.ok(vp.width>=389,'viewer is full width');
   const dock=await mp.locator('.fa-dock').boundingBox();assert.ok(dock.x>=0&&dock.x+dock.width<=390,'dock fits');
   await mp.locator('[data-layer-button="adhesive-frame"]').tap();assert.equal(await panelTitle(mp),'Skin-Friendly Adhesive Frame');
   await mp.locator('.fa-panel').evaluate(el=>Promise.all(el.getAnimations().map(a=>a.finished))); // slide-up entry animation
   const sheet=await mp.locator('.fa-panel').boundingBox();
   assert.ok(Math.abs(sheet.y+sheet.height-844)<2&&sheet.width>=389,'panel is a bottom sheet');
   await mp.getByRole('button',{name:'Close layer details'}).tap();await panelClosed(mp);
   await mp.getByLabel('View',{exact:true}).selectOption('top');await mp.waitForTimeout(1500);
   await mp.touchscreen.tap(vp.x+vp.width/2,vp.y+vp.height/2);
   await mp.waitForFunction(()=>document.querySelector('#fa-inspector-title')?.textContent==='Protective & Breathable Film');
   await mp.getByRole('button',{name:'Research & References'}).tap();
   await mp.locator('.fa-sheet').evaluate(el=>Promise.all(el.getAnimations().map(a=>a.finished)));
   const rs=await mp.locator('.fa-sheet').boundingBox();assert.ok(Math.abs(rs.y+rs.height-844)<2,'research sheet opens from the bottom');
   assert.ok(await mp.evaluate(()=>document.documentElement.scrollWidth-innerWidth)<=1);
  });
  await mctx.close();
 }catch(e){failed=true;console.error(e)}
 await browser.close();

 // ---------- no WebGL at all ----------
 const nogl=await chromium.launch({headless:true,args:['--disable-webgl','--disable-webgl2','--disable-3d-apis','--disable-gpu']});
 try{
  const p=await nogl.newPage();p.setDefaultTimeout(15000);
  await step('WebGL unavailable: functional 2D fallback (select, explode, keyboard, skin view)',async()=>{
   await p.goto(BASE);await p.locator('.fa-viewport[data-renderer="2d"]').waitFor();
   assert.match(await p.locator('.fa-viewport').evaluate(el=>el.style.backgroundImage),/data:image\/jpeg/,'2D fallback keeps the generated Mars backdrop');
   await p.getByText(/WebGL is unavailable/).waitFor();
   await p.locator('.fa-svg-layer[aria-label="Layer 4: Flexible Electronics"]').click();assert.equal(await panelTitle(p),'Flexible Electronics');
   await p.locator('.fa-svg-layer[aria-label="Layer 2: Microneedle Microelectrode Array (MN-sEMG)"]').focus();await p.keyboard.press('Enter');
   assert.equal(await panelTitle(p),'Microneedle Microelectrode Array (MN-sEMG)');
   await p.locator('[data-layer-button="adhesive-frame"]').click();assert.equal(await panelTitle(p),'Skin-Friendly Adhesive Frame');
   await p.getByRole('button',{name:'Assemble'}).click();assert.equal(await p.locator('.fa-viewport').getAttribute('data-explode-progress'),'0');
   await p.getByLabel('View',{exact:true}).selectOption('skin');await p.getByRole('img',{name:/Penetration depth not validated/}).waitFor();
   assert.equal(await p.getByTestId('fa-disclaimer').first().innerText(),DISCLAIMER);
  });
 }catch(e){failed=true;console.error(e)}
 await nogl.close();

 for(const r of results)console.log(r[0].padEnd(5),r[1],`(${r[2]} ms)`,r[3]?'— '+r[3]:'');
 console.log(`\n${results.filter(r=>r[0]==='PASS').length}/${results.length} FlexArray browser checks passed`);
 console.log('frame rate (headless Chromium, SwiftShader software WebGL):',JSON.stringify(perf));
 process.exit(failed?1:0);
})();
