// Browser tests for the FlexArray guided demo. Serve a production build first, e.g.
//   ASTRA_URL=http://127.0.0.1:4173 node tests/flexarray-demo.cjs
const {chromium}=require('playwright'),assert=require('node:assert/strict');
const BASE=(process.env.ASTRA_URL||'http://127.0.0.1:8000')+'/#flexarray';
const DISCLAIMER='Conceptual engineering design — not manufactured, clinically validated, or flight-qualified.';
const results=[];
async function step(name,fn){const t=Date.now();try{await fn();results.push(['PASS',name,Date.now()-t])}catch(e){results.push(['FAIL',name,Date.now()-t,e.message.split('\n')[0]]);throw e}}
const demo=p=>p.locator('.fa-demo');
const attr=(p,a)=>demo(p).getAttribute(a);
const seek=async(p,ms)=>{await p.locator('.fa-demo-scrub').fill(String(ms));await p.waitForTimeout(250)};
const position=p=>p.locator('.fa-demo-scrub').inputValue().then(Number);
/** Fails if any two visible demo elements (captions, HUD, review, controls, labels) overlap. */
const LAYOUT=['.fa-demo-caption','.fa-demo-bar','[data-testid="fa-hud-left"]','.fa-hud-right','.fa-hud-top','[data-testid="fa-hud-event"]','[data-testid="fa-demo-review"]','.fa-demo-badge','[data-testid="fa-scale-badge"]','.fa-demo-readout','.fa-demo-disclaimer'];
async function noOverlap(p,label){
 const boxes=[];for(const sel of LAYOUT){const l=p.locator(sel).first();if(await l.count()&&await l.isVisible())boxes.push([sel,await l.boundingBox()])}
 for(let i=0;i<boxes.length;i++)for(let j=i+1;j<boxes.length;j++){const [a,A]=boxes[i],[b,B]=boxes[j];
  assert.ok(!(A.x<B.x+B.width-1&&B.x<A.x+A.width-1&&A.y<B.y+B.height-1&&B.y<A.y+A.height-1),`${label}: ${a} overlaps ${b}`)}
 return boxes.length;
}
async function open(p){await p.goto(BASE);await p.locator('.fa-viewport[data-renderer="3d"] canvas').waitFor();await p.waitForFunction(()=>document.querySelector('.fa-viewport')?.getAttribute('data-explode-progress')==='1')}
/** Watches every request and storage write; the demo must cause neither. */
async function guard(p){
 const api=[];p.on('request',r=>{if(/\/api\//.test(r.url()))api.push(r.method()+' '+r.url())});
 const before=await p.evaluate(()=>JSON.stringify(Object.entries(localStorage).sort()));
 return {api,unchanged:async()=>assert.equal(await p.evaluate(()=>JSON.stringify(Object.entries(localStorage).sort())),before,'localStorage unchanged')};
}

(async()=>{
 const browser=await chromium.launch({headless:true,args:['--enable-unsafe-swiftshader']});
 let failed=false;
 try{
  const ctx=await browser.newContext({viewport:{width:1512,height:945}}),p=await ctx.newPage(),errors=[];
  p.on('pageerror',e=>errors.push(e.message));p.setDefaultTimeout(20000);
  await open(p);
  const g=await guard(p);
  await step('Start demo: scene 1 plays in the Mars bay with synthetic-data labels, disclaimer and scale readout',async()=>{
   await p.getByRole('button',{name:'Start demo'}).click();
   await demo(p).waitFor();
   assert.equal(await attr(p,'data-demo-scene'),'before-eva');assert.equal(await attr(p,'data-demo-state'),'playing');
   assert.match(await p.getByTestId('fa-demo-badge').innerText(),/synthetic data.*not a clinical diagnosis/i);
   assert.equal(await p.locator('.fa-demo-disclaimer').innerText(),DISCLAIMER);
   assert.equal(await p.getByTestId('fa-footprint').innerText(),'64 × 48 mm');
   assert.match(await p.getByTestId('fa-scale-badge').innerText(),/NOT TO SCALE/i);
   assert.equal(await p.locator('.fa-viewport').getAttribute('data-environment'),'bay');
   assert.equal(await p.locator('.fa-rail').count(),0,'interactive chrome hidden during the demo');assert.equal(await p.locator('.fa-dock').count(),0);
   assert.equal(await p.evaluate(()=>document.activeElement.getAttribute('aria-label')),'Pause demo','focus moves to the demo controls');
   assert.match(await p.getByTestId('fa-demo-time').innerText(),/\/ 0:45$/,'45-second scripted timeline');
   assert.equal(await p.locator('.fa-demo-scrub').getAttribute('max'),'45000');
   assert.ok(await noOverlap(p,'scene 1')>=5);
   const t0=await position(p);await p.waitForTimeout(2500);assert.ok(await position(p)>t0,'clock advances while playing');
  });
  await step('Pause / Play: the clock stops while paused and resumes',async()=>{
   await p.getByRole('button',{name:'Pause demo',exact:true}).click();assert.equal(await attr(p,'data-demo-state'),'paused');
   const t=await position(p);await p.waitForTimeout(1500);assert.equal(await position(p),t);
   await p.getByRole('button',{name:'Play demo',exact:true}).click();assert.equal(await attr(p,'data-demo-state'),'playing');
  });
  await step('Scene 2: Next focuses the patch, explodes it and highlights layers 02, 03, 04 in turn',async()=>{
   await seek(p,1000);assert.equal(await attr(p,'data-demo-scene'),'before-eva');
   await p.getByRole('button',{name:'Next scene'}).click();
   assert.equal(await attr(p,'data-demo-scene'),'technology');
   await p.waitForFunction(()=>document.querySelector('.fa-viewport').getAttribute('data-explode-progress')==='1');
   await p.getByRole('button',{name:'Pause demo',exact:true}).click();   // short beats: hold the clock while checking the 3D badges
   for(const [ms,id,n] of [[10000,'microneedle-array','2'],[13000,'sweat-management','3'],[16000,'flex-electronics','4']]){
    await seek(p,ms);assert.equal(await attr(p,'data-demo-highlight'),id);
    await p.waitForFunction(n=>document.querySelector('.fa-badge.is-on')?.textContent===n,n);
   }
   await p.locator('.fa-chip-label',{hasText:'Analog front end'}).waitFor();
   assert.match(await p.getByTestId('fa-demo-caption').innerText(),/Layer 04/);
   await noOverlap(p,'scene 2');
   await p.getByRole('button',{name:'Play demo',exact:true}).click();
  });
  await step('Previous: back to the start of scene 2, then to scene 1',async()=>{
   await p.getByRole('button',{name:'Previous scene'}).click();assert.equal(await attr(p,'data-demo-beat'),'layers');
   await p.getByRole('button',{name:'Previous scene'}).click();assert.equal(await attr(p,'data-demo-scene'),'before-eva');
  });
  await step('Scene boundaries: 0:07, 0:18 and 0:32 start scenes 2, 3 and 4',async()=>{
   await p.getByRole('button',{name:'Pause demo',exact:true}).click();
   for(const [ms,id] of [[0,'before-eva'],[6000,'before-eva'],[7000,'technology'],[17000,'technology'],[18000,'during-eva'],[31000,'during-eva'],[32000,'medical-review']]){
    await seek(p,ms);assert.equal(await attr(p,'data-demo-scene'),id,`${ms} ms → ${id}`);
   }
   await seek(p,0);
   for(const id of ['technology','during-eva','medical-review']){await p.getByRole('button',{name:'Next scene'}).click();assert.equal(await attr(p,'data-demo-scene'),id)}
   assert.equal(await position(p),32000);
   await p.getByRole('button',{name:'Play demo',exact:true}).click();
  });
  await step('Scene 3: simulated HUD with synthetic sEMG + IMU; alert only once the MuscleSense rule triggers, labelled Not a diagnosis',async()=>{
   await seek(p,22000);
   const hud=p.getByTestId('fa-demo-hud');await hud.waitFor();
   assert.match(await hud.innerText(),/SIMULATED HUD · SYNTHETIC DATA/i);
   assert.match(await hud.innerText(),/Right quadriceps[\s\S]*IMU/i);
   assert.equal(await p.getByTestId('fa-hud-event').count(),0,'no event before the data cross the demo rule');
   await p.getByRole('button',{name:'Pause demo',exact:true}).click();
   await seek(p,24000);   // synthetic sample 19: rule not yet met
   assert.equal(await p.getByTestId('fa-hud-event').count(),0);assert.equal(await attr(p,'data-demo-beat'),'hud');
   await seek(p,25000);   // sample 22: rule met → alert + caption
   const ev=p.getByTestId('fa-hud-event');await ev.waitFor();assert.equal(await attr(p,'data-demo-beat'),'event');
   assert.match(await ev.innerText(),/Left quadriceps · fatigue-related trend[\s\S]*Flagged for human review[\s\S]*Not a diagnosis/i);
   assert.match(await p.getByTestId('fa-demo-caption').innerText(),/fatigue-related trend flagged for review/i);
   assert.match(await p.getByTestId('fa-demo-sub').innerText(),/^Not a diagnosis/);
   await noOverlap(p,'scene 3 alert');
   await p.getByRole('button',{name:'Play demo',exact:true}).click();
   assert.ok(Number((await p.getByTestId('fa-hud-median').innerText()).split(' ')[0])<85,'median frequency below the 85 % line');
   assert.doesNotMatch(await demo(p).innerText(),/diagnosed|fatigue diagnosis|is fatigued/i);
  });
  await step('Scene 4: evidence, personal baseline and sensor quality are shown',async()=>{
   await seek(p,33000);
   assert.equal(await attr(p,'data-demo-scene'),'medical-review');
   assert.match(await p.getByTestId('fa-review-status').innerText(),/Fatigue-related trend — human review: \d+\.\d % median-frequency decrease/);
   assert.match(await p.getByTestId('fa-review-baseline').innerText(),/75 µV[\s\S]*100 Hz[\s\S]*fictional/);
   assert.match(await p.getByTestId('fa-review-quality').innerText(),/Quality 95 % · contact connected · artifacts none · 30 samples/);
   assert.equal(await p.getByTestId('fa-demo-instruction').count(),0);
   await noOverlap(p,'scene 4 evidence');
  });
  await step('Human gate: autoplay, scrubbing and Next cannot pass the reviewer confirmation',async()=>{
   await seek(p,44000);
   assert.equal(await attr(p,'data-demo-state'),'gate');assert.equal(await position(p),35000,'scrubbing clamps at the gate');
   assert.equal(await p.getByRole('button',{name:'Next scene'}).isDisabled(),true);
   assert.equal(await p.locator('.fa-demo-play').isDisabled(),true);
   await p.waitForTimeout(3000);
   assert.equal(await attr(p,'data-demo-state'),'gate');assert.equal(await p.getByTestId('fa-demo-instruction').count(),0,'nothing sent without confirmation');
   assert.equal(await p.evaluate(()=>document.activeElement.textContent),'Confirm review as demo reviewer','focus moves to the confirmation');
   assert.match(await p.getByTestId('fa-gate-timing').innerText(),/paused at 0:35 of 0:45\. Actual elapsed time may exceed 45 s while waiting for review/);
   assert.match(await p.getByTestId('fa-demo-sub').innerText(),/elapsed time may exceed 45 s/i);
   assert.match(await p.getByTestId('fa-demo-time').innerText(),/0:35 \/ 0:45 · review/);
   await noOverlap(p,'review gate');
  });
  await step('Reviewer confirms → simulated retest instruction, crew acknowledgment, reassessment, end',async()=>{
   await p.getByRole('button',{name:'Confirm review as demo reviewer'}).click();
   assert.match(await p.getByTestId('fa-review-confirmed').innerText(),/Demo reviewer \(simulated\)[\s\S]*no authorization record is created/);
   assert.equal(await p.getByTestId('fa-demo-caption').innerText(),'Review confirmed by demo reviewer (simulated)');
   assert.equal(await p.getByTestId('fa-gate-timing').count(),0);
   await seek(p,37000);
   assert.match(await p.getByTestId('fa-demo-instruction').innerText(),/Approved retest instruction \(simulated\)[\s\S]*repeat the left-quadriceps check under comparable conditions/i);
   await seek(p,40000);assert.match(await p.getByTestId('fa-demo-ack').innerText(),/Acknowledged/);
   await seek(p,43000);
   assert.match(await p.getByTestId('fa-demo-reassess').innerText(),/No demo trend flag[\s\S]*Return-to-EVA decisions remain with the human medical team/);
   await p.waitForTimeout(800);
   assert.ok(await p.getByTestId('fa-demo-review').evaluate(box=>{const m=box.querySelector('[data-testid="fa-demo-reassess"]').getBoundingClientRect(),b=box.getBoundingClientRect();return m.bottom<=b.bottom+1&&m.top>=b.top-1}),'newest review message scrolled into view');
   await noOverlap(p,'reassessment');
   await seek(p,45000);
   assert.equal(await attr(p,'data-demo-state'),'ended');assert.equal(await p.getByTestId('fa-demo-caption').innerText(),'Demo complete');
  });
  await step('Replay restarts at scene 1 and resets the reviewer confirmation',async()=>{
   await p.getByRole('button',{name:'Replay demo'}).click();
   assert.equal(await attr(p,'data-demo-scene'),'before-eva');assert.equal(await attr(p,'data-demo-state'),'playing');
   await seek(p,44000);assert.equal(await position(p),35000,'gate applies again after replay');
  });
  await step('Natural playback stops by itself at the gate, then plays to 0:45 only after a person confirms',async()=>{
   await p.getByRole('button',{name:'Replay demo'}).click();await seek(p,33000);
   await p.waitForFunction(()=>document.querySelector('.fa-demo').dataset.demoState==='gate',null,{timeout:20000});
   assert.equal(await position(p),35000);
   await p.waitForTimeout(2000);assert.equal(await position(p),35000,'clock holds while waiting for review');
   await p.getByRole('button',{name:'Confirm review as demo reviewer'}).click();
   await p.waitForFunction(()=>document.querySelector('.fa-demo').dataset.demoState==='ended',null,{timeout:40000});
   assert.equal(await position(p),45000);
   assert.equal(await p.getByTestId('fa-demo-reassess').count(),1);
  });
  await step('Skip demo restores the explorer and returns focus to Start demo',async()=>{
   await p.getByRole('button',{name:'Skip demo'}).click();
   await demo(p).waitFor({state:'detached'});
   await p.locator('.fa-dock').waitFor();assert.equal(await p.locator('.fa-rail button').count(),6);
   await p.waitForFunction(()=>document.querySelector('.fa-viewport').getAttribute('data-explode-progress')==='1');
   assert.equal(await p.evaluate(()=>document.activeElement.textContent.trim()),'Start demo');
  });
  await step('Escape exits the demo; normal layer selection still works afterwards',async()=>{
   await p.getByRole('button',{name:'Start demo'}).click();await demo(p).waitFor();
   await p.keyboard.press('Escape');await demo(p).waitFor({state:'detached'});
   await p.locator('[data-layer-button="adhesive-frame"]').click();
   assert.equal(await p.locator('#fa-inspector-title').innerText(),'Skin-Friendly Adhesive Frame');
  });
  await step('Safety: the demo made no API calls and wrote nothing to storage; no page errors',async()=>{
   assert.deepEqual(g.api,[]);await g.unchanged();assert.deepEqual(errors,[]);
  });
  await ctx.close();

  const rctx=await browser.newContext({viewport:{width:1280,height:900},reducedMotion:'reduce'}),rp=await rctx.newPage();
  await step('Reduced motion: instant transitions, no caption/HUD animation, gate still enforced',async()=>{
   await open(rp);await rp.getByRole('button',{name:'Start demo'}).click();await demo(rp).waitFor();
   assert.match(await demo(rp).getAttribute('class'),/is-reduced/);
   assert.equal(await rp.locator('.fa-demo-caption').evaluate(el=>el.getAnimations().length),0);
   await rp.evaluate(()=>{window.__fa=[];const el=document.querySelector('.fa-viewport');new MutationObserver(()=>window.__fa.push(el.getAttribute('data-explode-progress'))).observe(el,{attributes:true,attributeFilter:['data-explode-progress']})});
   await rp.getByRole('button',{name:'Next scene'}).click();
   await rp.waitForFunction(()=>document.querySelector('.fa-viewport').getAttribute('data-explode-progress')==='1');
   assert.ok((await rp.evaluate(()=>window.__fa)).every(v=>v==='0'||v==='1'),'explode jumps without intermediate frames');
   await seek(rp,44000);assert.equal(await demo(rp).getAttribute('data-demo-state'),'gate');assert.equal(await rp.locator('.fa-demo-scrub').inputValue(),'35000');
  });
  await rctx.close();

  const pctx=await browser.newContext({viewport:{width:1280,height:720}}),pp=await pctx.newPage();
  await step('Projector 1280×720: no overlap in any scene; review console fits at the gate without scrolling',async()=>{
   await open(pp);await pp.getByRole('button',{name:'Start demo'}).click();await demo(pp).waitFor();
   await pp.getByRole('button',{name:'Pause demo',exact:true}).click();
   for(const ms of [3000,10000,26000,30000,33000]){await seek(pp,ms);await noOverlap(pp,`1280×720 @ ${ms} ms`)}
   await seek(pp,35000);await pp.waitForTimeout(600);await noOverlap(pp,'1280×720 gate');
   const r=await pp.getByTestId('fa-demo-review').evaluate(el=>[el.scrollHeight,el.clientHeight]);
   assert.ok(r[0]<=r[1]+1,`review content ${r[0]} px fits in ${r[1]} px`);
   const ev=await pp.getByTestId('fa-demo-review').evaluate(el=>{const b=el.querySelector('.fa-spark').getBoundingClientRect(),c=el.getBoundingClientRect();return b.top>=c.top&&b.bottom<=c.bottom});
   assert.ok(ev,'evidence chart visible at the gate');
  });
  await pctx.close();

  const mctx=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,deviceScaleFactor:2}),mp=await mctx.newPage();
  await step('Mobile: demo fits the screen; HUD and review usable; confirmation by tap',async()=>{
   await open(mp);await mp.getByRole('button',{name:'Start demo'}).tap();await demo(mp).waitFor();
   const overflow=()=>mp.evaluate(()=>document.documentElement.scrollWidth-innerWidth);
   assert.ok(await overflow()<=1);
   const bar=await mp.locator('.fa-demo-bar').boundingBox();assert.ok(bar.x>=0&&bar.x+bar.width<=390,'control bar fits');
   await noOverlap(mp,'phone scene 1');
   await mp.getByRole('button',{name:'Pause demo',exact:true}).tap();
   await seek(mp,26000);await mp.getByTestId('fa-hud-event').waitFor();
   const hud=await mp.getByTestId('fa-hud-left').boundingBox();assert.ok(hud.x>=0&&hud.x+hud.width<=390);
   assert.match(await mp.getByTestId('fa-hud-event').innerText(),/Not a diagnosis/i);
   await noOverlap(mp,'phone scene 3 alert');
   await seek(mp,35000);
   const btn=mp.getByRole('button',{name:'Confirm review as demo reviewer'});await btn.waitFor();
   await mp.waitForTimeout(800);await noOverlap(mp,'phone review gate');
   await btn.scrollIntoViewIfNeeded();await btn.tap();
   await seek(mp,43000);await mp.getByTestId('fa-demo-reassess').waitFor();
   await noOverlap(mp,'phone reassessment');
   assert.ok(await overflow()<=1);
  });
  await mctx.close();
 }catch(e){failed=true;console.error(e)}
 await browser.close();
 for(const r of results)console.log(r[0].padEnd(5),r[1],`(${r[2]} ms)`,r[3]?'— '+r[3]:'');
 console.log(`\n${results.filter(r=>r[0]==='PASS').length}/${results.length} guided-demo checks passed`);
 process.exit(failed?1:0);
})();
