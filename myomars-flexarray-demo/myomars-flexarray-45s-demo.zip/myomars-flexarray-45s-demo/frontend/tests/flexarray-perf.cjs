// Frame-rate report for the FlexArray page: Mars EVA bay backdrop vs Minimal, on desktop, retina and phone viewports.
// Uses GPU-backed headless Chromium (ANGLE). It reports numbers and does not fail on them.
//   ASTRA_URL=http://127.0.0.1:4173 node tests/flexarray-perf.cjs
// Note: phone sizes are emulated on the host GPU; this is not a measurement on a real phone.
const {chromium}=require('playwright');
const BASE=(process.env.ASTRA_URL||'http://127.0.0.1:8000')+'/#flexarray';
const ANGLE=process.platform==='darwin'?'metal':process.platform==='win32'?'d3d11':'gl';
(async()=>{
 const b=await chromium.launch({headless:true,args:[`--use-angle=${ANGLE}`,'--enable-gpu','--ignore-gpu-blocklist']});
 const fps=(p,ms=4000)=>p.evaluate(ms=>new Promise(r=>{let n=0;const t0=performance.now();const f=()=>{n++;if(performance.now()-t0<ms)requestAnimationFrame(f);else r(+(n*1000/(performance.now()-t0)).toFixed(1))};requestAnimationFrame(f)}),ms);
 const out={};
 for(const [name,vp,mob,dpr] of [['desktop 1600x900',{width:1600,height:900},false,1],['desktop 1600x900 @2x',{width:1600,height:900},false,2],['phone 390x844 @3x (emulated)',{width:390,height:844},true,3]]){
  const c=await b.newContext({viewport:vp,isMobile:mob,hasTouch:mob,deviceScaleFactor:dpr}),p=await c.newPage();
  await p.goto(BASE);await p.locator('.fa-viewport canvas').waitFor();await p.waitForTimeout(3000);
  out.renderer??=await p.evaluate(()=>{const gl=document.querySelector('.fa-viewport canvas').getContext('webgl2');const d=gl.getExtension('WEBGL_debug_renderer_info');return d?gl.getParameter(d.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER)});
  const quality=await p.locator('.fa-viewport').getAttribute('data-quality');
  const bay=await fps(p);
  await p.getByRole('button',{name:'Research & References'}).click();await p.locator('.fa-sheet').getByRole('tab',{name:'System settings'}).click();
  await p.locator('.fa-sheet').getByRole('button',{name:'Minimal'}).click();await p.getByRole('button',{name:'Close research panel'}).click();await p.waitForTimeout(800);
  out[name]={quality,bayFps:bay,minimalFps:await fps(p)};
  await c.close();
 }
 await b.close();console.log(JSON.stringify(out,null,1));
})();
