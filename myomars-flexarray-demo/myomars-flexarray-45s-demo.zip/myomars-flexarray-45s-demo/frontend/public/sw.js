const CACHE='astra-neuro-v2';
self.addEventListener('install',e=>{e.waitUntil((async()=>{const cache=await caches.open(CACHE);const response=await fetch('/index.html');const html=await response.text();const bundled=await fetch('/offline-assets.json',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Offline asset manifest unavailable');return r.json()});const assets=[...html.matchAll(/(?:src|href)="([^"#]+)"/g)].map(m=>m[1]).filter(p=>p.startsWith('/assets/'));await cache.addAll(['/','/index.html','/offline-assets.json',...new Set([...assets,...bundled])]);await self.skipWaiting()})())});
self.addEventListener('activate',e=>e.waitUntil((async()=>{for(const key of await caches.keys())if(key.startsWith('astra-')&&key!==CACHE)await caches.delete(key);await self.clients.claim()})()));
self.addEventListener('fetch',e=>{
 const url=new URL(e.request.url);
 if(e.request.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api'))return;
 e.respondWith((async()=>{
   const cache=await caches.open(CACHE);
   // Navigation refreshes the application shell online; hashed assets remain cache-first.
   const cached=await cache.match(e.request,{ignoreVary:true});
   if(cached&&e.request.mode!=='navigate')return cached;
   try {const response=await fetch(e.request);if(response.ok){const cache=await caches.open(CACHE);await cache.put(e.request,response.clone())}return response}
   catch {if(cached)return cached;if(e.request.mode==='navigate'){const shell=await caches.match('/index.html');if(shell)return shell}return Response.error()}
 })());
});
