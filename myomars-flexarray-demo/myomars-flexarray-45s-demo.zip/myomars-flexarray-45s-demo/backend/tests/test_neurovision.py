import json
import shutil
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4
import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError
from app.main import app
from app.neurovision import Screening, summary, readiness_alerts, SECTORS

NOW=datetime.now(timezone.utc)
def screening(kind='reaction',**patch):
    s=dict(session_id=str(uuid4()),astronaut_id='a01',mission_id='eva-042',kind=kind,started_at=(NOW-timedelta(seconds=20)).isoformat(),completed_at=(NOW-timedelta(seconds=1)).isoformat(),interrupted=False,trials=[dict(stimulus_at=(NOW-timedelta(seconds=18-i)).isoformat(),response_ms=200+i,false_starts=0,sector=None if kind=='reaction' else SECTORS[i]) for i in range(3 if kind=='reaction' else 8)])
    return s|patch

def assessment():
    return dict(astronaut_id='a01',mission_id='eva-042',sleep=7.6,stress=3,heart_rate=64,systolic=118,diastolic=76,symptoms=['none'],reaction_ms=201,reaction_screening=screening(),visual_screening=screening('visual'))

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv('ASTRA_DB',str(tmp_path/'sprint2.sqlite3'))
    return TestClient(app)

@pytest.mark.parametrize('kind',['reaction','visual'])
def test_complete_summary(kind):
    result=summary(Screening(**screening(kind)),NOW)
    assert result['quality']=='complete'
    assert result['status']=='within_demo_baseline'
    assert result['median_ms']==(201 if kind=='reaction' else 203.5)
    assert result['non_diagnostic'] is True

def test_miss_and_error_quality():
    s=screening();s['trials'][0]['response_ms']=None;s['trials'][1]['false_starts']=1
    result=summary(Screening(**s),NOW)
    assert result['missed_stimuli']==1
    assert result['error_rate']==.5
    assert result['quality']=='degraded'
    assert result['status']=='hold'

@pytest.mark.parametrize('patch,quality',[(dict(completed_at=None),'incomplete'),(dict(interrupted=True),'incomplete'),(dict(trials=[]),'incomplete'),(dict(started_at=(NOW-timedelta(seconds=500)).isoformat(),trials=[],completed_at=(NOW-timedelta(seconds=400)).isoformat()),'incomplete'),(dict(started_at=(NOW+timedelta(seconds=1)).isoformat(),completed_at=None,trials=[]),'invalid')])
def test_bad_completion_quality(patch,quality):
    assert summary(Screening(**screening(**patch)),NOW)['quality']==quality

def test_stale_and_boundary():
    s=Screening(**screening())
    assert summary(s,s.completed_at+timedelta(seconds=300))['quality']=='complete'
    assert summary(s,s.completed_at+timedelta(seconds=301))['quality']=='stale'

def test_duplicate_visual_location_invalid():
    s=screening('visual');s['trials'][7]['sector']='NW'
    assert summary(Screening(**s),NOW)['quality']=='invalid'

@pytest.mark.parametrize('patch',[dict(started_at='invalid'),dict(started_at='2026-11-14T18:00:00'),dict(completed_at=(NOW-timedelta(days=2)).isoformat())])
def test_invalid_timestamp_rejected(patch):
    with pytest.raises(ValidationError): Screening(**screening(**patch))

@pytest.mark.parametrize('value',[99,1501,float('nan'),float('inf')])
def test_invalid_response_rejected(value):
    s=screening();s['trials'][0]['response_ms']=value
    with pytest.raises(ValidationError): Screening(**s)

def test_fictional_individual_baseline():
    s=screening();[t.update(response_ms=450) for t in s['trials']]
    assert summary(Screening(**s),NOW)['status']=='hold'
    s['astronaut_id']='a02'
    assert summary(Screening(**s),NOW)['status']=='within_demo_baseline'

def test_missing_and_mismatched_context_hold():
    _,alerts=readiness_alerts(None,None,'a01','eva-042',NOW)
    assert len(alerts)==2
    for patch in [dict(astronaut_id='a02'),dict(mission_id='eva-043'),dict(kind='visual')]:
        _,alerts=readiness_alerts(Screening(**screening(**patch)),Screening(**screening('visual')),'a01','eva-042',NOW)
        assert alerts[0]['code']=='NEURO_REACTION'

def test_no_responses_is_not_normal():
    s=screening();[t.update(response_ms=None) for t in s['trials']]
    assert summary(Screening(**s),NOW)['median_ms'] is None
    assert summary(Screening(**s),NOW)['status']=='hold'

def test_missing_neuro_data_cannot_authorize(client):
    data=assessment();del data['reaction_screening'];del data['visual_screening']
    result=client.post('/api/readiness',json=data).json()
    assert result['status']=='hold'
    assert {a['code'] for a in result['alerts']} >= {'NEURO_REACTION','NEURO_VISUAL'}
    assert client.post('/api/authorizations',json=dict(assessment_id=result['id'],operator='Human',confirmed=True)).status_code==409

def test_valid_screenings_still_require_human(client):
    result=client.post('/api/readiness',json=assessment()).json()
    assert result['status']=='awaiting_human'
    assert client.post('/api/authorizations',json=dict(assessment_id=result['id'],operator='Human',confirmed=True)).status_code==200

def test_critical_physiology_preserved(client):
    result=client.post('/api/readiness',json=assessment()|dict(symptoms=['chest pain'])).json()
    assert result['status']=='hold'
    assert result['alerts'][0]['code']=='SEVERE_SYMPTOM'

def test_scalar_cannot_bypass_slow_cognitive_trials(client):
    data=assessment();[t.update(response_ms=800) for t in data['reaction_screening']['trials']]
    result=client.post('/api/readiness',json=data).json()
    assert result['status']=='hold'
    assert {'REACTION','NEURO_REACTION'} <= {a['code'] for a in result['alerts']}

def test_cognitive_expiry_blocks_later_authorization(client,monkeypatch):
    from app import neurovision
    data=assessment();result=client.post('/api/readiness',json=data).json()
    original=neurovision.readiness_alerts
    monkeypatch.setattr('app.main.readiness_alerts',lambda *args:original(*args,at=NOW+timedelta(seconds=301)))
    assert client.post('/api/authorizations',json=dict(assessment_id=result['id'],operator='Human',confirmed=True)).status_code==409

def test_event_sync_is_idempotent_and_audited(client):
    event=dict(event_id=str(uuid4()),event='completed',screening=screening('visual'))
    assert client.post('/api/neurovision/events',json=event).json()['duplicate'] is False
    assert client.post('/api/neurovision/events',json=event).json()['duplicate'] is True
    entries=client.get('/api/audit').json()
    assert [e['event'] for e in entries]==['neurovision_completed']
    assert len(client.get('/api/neurovision/events?astronaut_id=a01').json())==1
    event['screening']['trials'][0]['response_ms']=999
    assert client.post('/api/neurovision/events',json=event).status_code==409

def test_start_and_interruption_audited(client):
    s=screening(completed_at=None,trials=[])
    for event in ['started','interrupted']:
        if event=='interrupted':s|=dict(interrupted=True,completed_at=NOW.isoformat(),unassigned_errors=2)
        assert client.post('/api/neurovision/events',json=dict(event_id=str(uuid4()),event=event,screening=s)).status_code==200
    assert {e['event'] for e in client.get('/api/audit').json()}=={'neurovision_started','neurovision_interrupted'}

def test_new_attempt_invalidates_saved_readiness(client):
    data=assessment();result=client.post('/api/readiness',json=data).json()
    s=screening(started_at=NOW.isoformat(),completed_at=None,trials=[])
    assert client.post('/api/neurovision/events',json=dict(event_id=str(uuid4()),event='started',screening=s)).status_code==200
    assert client.post('/api/authorizations',json=dict(assessment_id=result['id'],operator='Human',confirmed=True)).status_code==409

@pytest.mark.parametrize('event,patch',[('started',{}),('completed',dict(completed_at=None)),('interrupted',dict(interrupted=False))])
def test_invalid_event_lifecycle_rejected(client,event,patch):
    assert client.post('/api/neurovision/events',json=dict(event_id=str(uuid4()),event=event,screening=screening(**patch))).status_code==422

def test_offline_python_neurovision_parity(tmp_path):
    node=shutil.which('node');frontend=Path(__file__).resolve().parents[2]/'frontend'
    ts=frontend/'node_modules/typescript/lib/typescript.js'
    if not node or not ts.exists():pytest.skip('Node and frontend dependencies required')
    inputs=[screening(),screening('visual'),screening(interrupted=True),screening(trials=[]),screening(completed_at=None),screening(started_at=(NOW+timedelta(seconds=1)).isoformat(),completed_at=None,trials=[])]
    degraded=screening();degraded['trials'][0]|=dict(response_ms=None,false_starts=2);inputs.append(degraded)
    invalid=screening('visual');invalid['trials'][7]['sector']='NW';inputs.append(invalid)
    script=tmp_path/'parity.cjs';script.write_text("const fs=require('fs'),ts=require(process.argv[2]);const m={exports:{}};new Function('exports','module',ts.transpileModule(fs.readFileSync(process.argv[3],'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText)(m.exports,m);const input=JSON.parse(fs.readFileSync(0,'utf8'));console.log(JSON.stringify(input.samples.map(s=>m.exports.summarize(s,input.now))));")
    values=json.loads(subprocess.check_output([node,str(script),str(ts),str(frontend/'src/neurovision.ts')],input=json.dumps(dict(samples=inputs,now=NOW.timestamp()*1000)).encode()))
    for s,offline in zip(inputs,values):
        server=summary(Screening(**s),NOW)
        for key,value in offline.items():assert server[key]==value,(key,s)
