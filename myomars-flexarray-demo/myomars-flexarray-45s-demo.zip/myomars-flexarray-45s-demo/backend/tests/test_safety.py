import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.models import Assessment, Telemetry
from app.rules import assess, evaluate_telemetry, rer

@pytest.fixture
def clean():
    return dict(astronaut_id="a01",mission_id="eva-042",sleep=7.6,stress=3,heart_rate=64,systolic=118,diastolic=76,symptoms=["none"],reaction_ms=280)

@pytest.mark.parametrize("vo2,vco2,expected",[(1,0.85,.85),(2,2.4,1.2),(0,1,None),(None,1,None),(1,None,None),(-1,1,None),(1,-1,None),(float('nan'),1,None)])
def test_rer(vo2,vco2,expected): assert rer(vo2,vco2)==expected

def test_clean_requires_human(clean): assert assess(Assessment(**clean))["status"]=="awaiting_human"

@pytest.mark.parametrize("field,value,code",[("sleep",5,"SLEEP"),("stress",8,"STRESS"),("heart_rate",100,"HR"),("systolic",150,"BP"),("reaction_ms",450,"REACTION"),("sleep",None,"MISSING_DATA"),("age_seconds",301,"STALE_DATA"),("symptoms",[],"MISSING_DATA"),("symptoms",["dizziness"],"SYMPTOM"),("symptoms",["none","headache"],"INVALID_SYMPTOMS"),("diastolic",120,"INVALID_BP")])
def test_assessment_holds(clean,field,value,code):
    result=assess(Assessment(**(clean|{field:value})))
    assert result["status"]=="hold"
    assert code in [a["code"] for a in result["alerts"]]

def test_critical_priority(clean):
    result=assess(Assessment(**(clean|dict(sleep=None,symptoms=["chest pain"]))))
    assert result["alerts"][0]["severity"]=="critical"

def test_individual_baseline(clean):
    data=clean|dict(heart_rate=92)
    assert any(a["code"]=="HR" for a in assess(Assessment(**data))["alerts"])
    assert not any(a["code"]=="HR" for a in assess(Assessment(**(data|dict(astronaut_id="a02"))))["alerts"])

def test_rer_never_abort():
    result=evaluate_telemetry(Telemetry(vo2=1,vco2=2,oxygen=80,co2=.3))
    assert [a["severity"] for a in result["alerts"]]==["info"]

def test_telemetry_prioritizes_critical_over_quality():
    result=evaluate_telemetry(Telemetry(vo2=None,vco2=1,oxygen=10,co2=2))
    assert [a["severity"] for a in result["alerts"]]==["critical","critical","hold"]

def test_missing_and_stale_sensor():
    for data in [Telemetry(),Telemetry(vo2=1,vco2=1,oxygen=80,co2=.3,age_seconds=16)]:
        assert evaluate_telemetry(data)["alerts"][0]["code"]=="SENSOR_QUALITY"

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv("ASTRA_DB",str(tmp_path/"test.sqlite3"))
    return TestClient(app)

def test_authorization_and_audit(client,clean):
    result=client.post("/api/assessments",json=clean).json()
    assert result["status"]=="awaiting_human"
    assert client.post("/api/authorizations",json=dict(assessment_id=result["id"],operator="Dr Demo",confirmed=True)).status_code==200
    assert client.get("/api/audit").json()[0]["event"]=="human_authorization"

def test_held_cannot_be_overridden(client,clean):
    result=client.post("/api/assessments",json=clean|dict(symptoms=["chest pain"])).json()
    assert client.post("/api/authorizations",json=dict(assessment_id=result["id"],operator="Dr Demo",confirmed=True)).status_code==409
    assert client.get("/api/audit").json()[0]["event"]=="authorization_denied"

def test_expired_authorization(client,clean):
    import sqlite3,os
    result=client.post("/api/assessments",json=clean).json()
    with sqlite3.connect(os.environ["ASTRA_DB"]) as conn:
        conn.execute("UPDATE assessments SET created='2000-01-01T00:00:00+00:00'")
    assert client.post("/api/authorizations",json=dict(assessment_id=result["id"],operator="Dr Demo",confirmed=True)).status_code==409

@pytest.mark.parametrize("patch",[{"sleep":25},{"stress":0},{"astronaut_id":"unknown"},{"symptoms":["unknown"]}])
def test_invalid_input(client,clean,patch): assert client.post("/api/assessments",json=clean|patch).status_code==422
