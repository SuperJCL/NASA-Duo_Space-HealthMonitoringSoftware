"""Compare browser offline safety rules with the Python authority, when Node is installed."""
import json
from pathlib import Path
import shutil
import subprocess
import pytest
from app.models import Assessment, Telemetry
from app.rules import assess, evaluate_telemetry

def test_offline_rule_parity(tmp_path):
    node=shutil.which('node')
    frontend=Path(__file__).resolve().parents[2]/'frontend'
    ts=frontend/'node_modules/typescript/lib/typescript.js'
    if not node or not ts.exists():
        pytest.skip('Install Node and frontend dependencies to run cross-language parity test')
    base=dict(astronaut_id='a01',mission_id='eva-042',sleep=7.6,stress=3,heart_rate=64,systolic=118,diastolic=76,symptoms=['none'],reaction_ms=280,age_seconds=0)
    inputs=[base|patch for patch in [{},{'sleep':None},{'age_seconds':301},{'symptoms':[]},{'symptoms':['none','headache']},{'symptoms':['chest pain'],'sleep':None},{'sleep':5},{'stress':7},{'heart_rate':100},{'systolic':160},{'diastolic':120},{'reaction_ms':450},{'astronaut_id':'a02','heart_rate':92}]]
    telemetry=[dict(vo2=1,vco2=2,oxygen=80,co2=.3,age_seconds=0),dict(vo2=None,vco2=1,oxygen=10,co2=2,age_seconds=0),dict(vo2=1,vco2=1,oxygen=80,co2=.3,age_seconds=16)]
    script=tmp_path/'parity.cjs'
    script.write_text('''const fs=require('fs');const ts=require(process.argv[2]);const compiled=ts.transpileModule(fs.readFileSync(process.argv[3],'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText;const mod={exports:{}};new Function('exports','module',compiled)(mod.exports,mod);const input=JSON.parse(fs.readFileSync(0,'utf8'));console.log(JSON.stringify({assessments:input.assessments.map(mod.exports.assess),telemetry:input.telemetry.map(t=>mod.exports.telemetry(t.vo2,t.vco2,t.oxygen,t.co2,t.age_seconds>15))}));''')
    result=json.loads(subprocess.check_output([node,str(script),str(ts),str(frontend/'src/rules.ts')],input=json.dumps(dict(assessments=inputs,telemetry=telemetry)).encode()))
    for data,offline in zip(inputs,result['assessments']):
        server=assess(Assessment(**data))
        assert offline['status']==server['status']
        assert offline['alerts']==server['alerts']
    for data,offline in zip(telemetry,result['telemetry']):
        server=evaluate_telemetry(Telemetry(**data))
        assert offline['rer']==server['rer']
        assert offline['alerts']==server['alerts']
