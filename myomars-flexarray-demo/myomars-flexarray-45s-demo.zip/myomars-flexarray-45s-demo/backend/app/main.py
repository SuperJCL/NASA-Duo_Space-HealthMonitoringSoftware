import json
import os
import sqlite3
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .models import Assessment, Authorization, Telemetry, NeuroReadiness
from .neurovision import ScreeningEvent, readiness_alerts, summary
from .rules import ordered
from .rules import BASELINES, assess, evaluate_telemetry

app = FastAPI(title="ASTRA Health AI — synthetic demo", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_methods=["*"], allow_headers=["*"])

def db():
    conn=sqlite3.connect(os.environ.get("ASTRA_DB", "astra.sqlite3"))
    conn.row_factory=sqlite3.Row
    conn.execute("CREATE TABLE IF NOT EXISTS assessments (id INTEGER PRIMARY KEY, created TEXT, payload TEXT, result TEXT, authorized_by TEXT)")
    conn.execute("CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY, created TEXT, event TEXT, payload TEXT)")
    conn.execute("CREATE TABLE IF NOT EXISTS neuro_events (event_id TEXT PRIMARY KEY, created TEXT, astronaut_id TEXT, payload TEXT, summary TEXT)")
    return conn

def now(): return datetime.now(timezone.utc).isoformat()
def log(conn,event,payload): conn.execute("INSERT INTO audit(created,event,payload) VALUES(?,?,?)",(now(),event,json.dumps(payload)))

@app.get("/api/astronauts")
def astronauts(): return [{"id":k,**v,"synthetic":True} for k,v in BASELINES.items()]

@app.get("/api/missions")
def missions(): return [{"id":"eva-042","name":"Ares Ridge • Geological survey","duration_minutes":120}, {"id":"eva-043","name":"Habitat perimeter • Equipment inspection","duration_minutes":60}]

@app.post("/api/assessments")
def assessment(data:Assessment):
    result=assess(data)
    with db() as conn:
        cursor=conn.execute("INSERT INTO assessments(created,payload,result) VALUES(?,?,?)",(now(),data.model_dump_json(),json.dumps(result)))
        result["id"]=cursor.lastrowid
        log(conn,"assessment_decision",result)
    return result

@app.post("/api/authorizations")
def authorize(data:Authorization):
    with db() as conn:
        row=conn.execute("SELECT * FROM assessments WHERE id=?",(data.assessment_id,)).fetchone()
        if not row: raise HTTPException(404,"Assessment not found")
        result=json.loads(row["result"])
        age=(datetime.now(timezone.utc)-datetime.fromisoformat(row["created"])).total_seconds()
        cognitive_expired=False
        payload=json.loads(row["payload"])
        if "neurovision" in result:
            _, checks=readiness_alerts(NeuroReadiness(**payload).reaction_screening,NeuroReadiness(**payload).visual_screening,payload["astronaut_id"],payload["mission_id"])
            cognitive_expired=bool(checks)
            for event_row in conn.execute("SELECT payload FROM neuro_events WHERE astronaut_id=?",(payload["astronaut_id"],)):
                event=json.loads(event_row["payload"])["screening"]
                snapshot=payload.get(event["kind"]+"_screening")
                if event["mission_id"]==payload["mission_id"] and snapshot and datetime.fromisoformat(event["started_at"].replace("Z","+00:00"))>datetime.fromisoformat(snapshot["started_at"].replace("Z","+00:00")):
                    cognitive_expired=True
        if result["status"] != "awaiting_human" or age > 300 or cognitive_expired:
            log(conn,"authorization_denied",data.model_dump())
            conn.commit()
            raise HTTPException(409,"Hold or expired assessment cannot be authorized. Reassess.")
        if len(data.operator.strip()) < 2: raise HTTPException(422,"Operator name required")
        conn.execute("UPDATE assessments SET authorized_by=? WHERE id=?",(data.operator.strip(),data.assessment_id))
        log(conn,"human_authorization",data.model_dump())
    return {"status":"authorized", "operator":data.operator.strip(), "assessment_id":data.assessment_id}

@app.post("/api/telemetry/evaluate")
def telemetry(data:Telemetry):
    result=evaluate_telemetry(data)
    with db() as conn: log(conn,"telemetry_decision",{"sample":data.model_dump(),**result})
    return result

@app.get("/api/audit")
def audit():
    with db() as conn: return [dict(row) for row in conn.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 200")]


@app.post("/api/neurovision/events")
def neuro_event(data: ScreeningEvent):
    result=summary(data.screening)
    payload=data.model_dump_json()
    with db() as conn:
        existing=conn.execute("SELECT payload, summary FROM neuro_events WHERE event_id=?",(str(data.event_id),)).fetchone()
        if existing:
            if json.loads(existing["payload"]) != json.loads(payload):
                raise HTTPException(409,"Event ID already has a different payload")
            return {"event_id":str(data.event_id),"summary":json.loads(existing["summary"]),"duplicate":True}
        conn.execute("INSERT INTO neuro_events VALUES(?,?,?,?,?)",(str(data.event_id),now(),data.screening.astronaut_id,payload,json.dumps(result)))
        log(conn,"neurovision_"+data.event,{"event_id":str(data.event_id),"screening":data.screening.model_dump(mode="json"),"summary":result})
    return {"event_id":str(data.event_id),"summary":result,"duplicate":False}

@app.get("/api/neurovision/events")
def neuro_history(astronaut_id: str):
    if astronaut_id not in ("a01","a02"): raise HTTPException(422,"Unknown astronaut")
    with db() as conn:
        return [json.loads(row["payload"]) for row in conn.execute("SELECT payload FROM neuro_events WHERE astronaut_id=? ORDER BY created, rowid",(astronaut_id,))]

@app.post("/api/readiness")
def neuro_readiness(data: NeuroReadiness):
    result=assess(data)
    summaries,alerts=readiness_alerts(data.reaction_screening,data.visual_screening,data.astronaut_id,data.mission_id)
    # Trial evidence is authoritative; a manually supplied scalar cannot bypass a slow test.
    reaction=summaries["reaction"].get("median_ms")
    if reaction is not None:
        result=assess(data.model_copy(update={"reaction_ms":reaction}))
    result["alerts"]=ordered(result["alerts"]+alerts)
    result["status"]="hold" if result["alerts"] else "awaiting_human"
    result["neurovision"]=summaries
    result["rules_version"]="demo-v1+neuro-v1"
    with db() as conn:
        cursor=conn.execute("INSERT INTO assessments(created,payload,result) VALUES(?,?,?)",(now(),data.model_dump_json(),json.dumps(result)))
        result["id"]=cursor.lastrowid
        log(conn,"assessment_decision",result)
    return result

# Serve the built UI locally with the API, without external services.
from pathlib import Path
from fastapi.staticfiles import StaticFiles
frontend_dist = Path(__file__).resolve().parents[2] / "frontend" / "dist"
if frontend_dist.exists():
    app.mount("/", StaticFiles(directory=frontend_dist, html=True), name="ui")
