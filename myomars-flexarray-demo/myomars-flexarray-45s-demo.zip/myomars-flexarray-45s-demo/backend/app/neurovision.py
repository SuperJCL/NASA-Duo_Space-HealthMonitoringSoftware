"""Non-diagnostic fictional NeuroVision screening rules. No AI or medical limits."""
from datetime import datetime, timezone
from statistics import median
from typing import Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, AwareDatetime, model_validator

BASELINES = {
    "a01": {"reaction_ms": 280, "visual_ms": 450, "miss_rate": 0.0, "error_rate": 0.0},
    "a02": {"reaction_ms": 310, "visual_ms": 480, "miss_rate": 0.0, "error_rate": 0.0},
}
SECTORS = ["NW", "N", "NE", "E", "SE", "S", "SW", "W"]
class Trial(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    stimulus_at: AwareDatetime
    response_ms: float | None = Field(default=None, ge=100, le=1500)
    false_starts: int = Field(default=0, ge=0, le=100)
    sector: Literal["NW", "N", "NE", "E", "SE", "S", "SW", "W"] | None = None

class Screening(BaseModel):
    model_config = ConfigDict(extra="forbid")
    session_id: UUID
    astronaut_id: Literal["a01", "a02"]
    mission_id: Literal["eva-042", "eva-043"]
    kind: Literal["reaction", "visual"]
    started_at: AwareDatetime
    completed_at: AwareDatetime | None = None
    interrupted: bool = False
    unassigned_errors: int = Field(default=0, ge=0, le=100)
    trials: list[Trial] = Field(default_factory=list, max_length=8)

    @model_validator(mode="after")
    def chronology(self):
        if self.completed_at and self.completed_at < self.started_at:
            raise ValueError("Completion precedes start")
        previous=self.started_at
        for trial in self.trials:
            if trial.stimulus_at < previous or (self.completed_at and trial.stimulus_at > self.completed_at):
                raise ValueError("Trial timestamps are inconsistent")
            previous=trial.stimulus_at
        return self

class ScreeningEvent(BaseModel):
    event_id: UUID
    event: Literal["started", "completed", "interrupted"]
    screening: Screening

    @model_validator(mode="after")
    def lifecycle(self):
        s=self.screening
        if self.event=="started" and (s.completed_at or s.trials or s.interrupted or s.unassigned_errors):
            raise ValueError("Start event must be empty")
        if self.event=="completed" and (not s.completed_at or s.interrupted):
            raise ValueError("Completion event requires completion timestamp")
        if self.event=="interrupted" and (not s.interrupted or not s.completed_at):
            raise ValueError("Interrupted event must record interruption time")
        return self

def summary(s: Screening, at: datetime | None = None):
    at=at or datetime.now(timezone.utc)
    expected=3 if s.kind=="reaction" else 8
    times=[t.response_ms for t in s.trials if t.response_ms is not None]
    missed=sum(t.response_ms is None for t in s.trials)
    errors=sum(t.false_starts for t in s.trials)+s.unassigned_errors
    n=len(s.trials)
    valid_layout=(all(t.sector is None for t in s.trials) if s.kind=="reaction" else all(t.sector in SECTORS for t in s.trials) and len({t.sector for t in s.trials})==n)
    complete=bool(s.completed_at) and n==expected and not s.interrupted and valid_layout
    future=s.started_at>at or bool(s.completed_at and s.completed_at>at)
    stale=bool(s.completed_at and (at-s.completed_at).total_seconds()>300)
    quality="invalid" if future or not valid_layout else "incomplete" if not complete else "stale" if stale else "degraded" if missed or errors else "complete"
    value=median(times) if times else None
    baseline=BASELINES[s.astronaut_id]["reaction_ms" if s.kind=="reaction" else "visual_ms"]
    miss_rate=missed/n if n else None
    error_rate=(missed+errors)/(n+errors) if n+errors else None
    hold=quality!="complete" or value is None or value>baseline*1.5
    return dict(session_id=str(s.session_id),kind=s.kind,quality=quality,expected_trials=expected,recorded_trials=n,median_ms=value,missed_stimuli=missed,false_starts=errors,miss_rate=miss_rate,error_rate=error_rate,baseline_ms=baseline,delta_ms=None if value is None else value-baseline,status="hold" if hold else "within_demo_baseline",non_diagnostic=True)

def readiness_alerts(reaction,visual,astronaut_id,mission_id,at=None):
    alerts=[]
    summaries={}
    for kind,s in (("reaction",reaction),("visual",visual)):
        if s is None:
            value={"quality":"missing","status":"hold","non_diagnostic":True}
        elif s.kind!=kind or s.astronaut_id!=astronaut_id or s.mission_id!=mission_id:
            value={"quality":"invalid","status":"hold","non_diagnostic":True}
        else:
            value=summary(s,at)
        summaries[kind]=value
        if value["status"]=="hold":
            alerts.append(dict(code="NEURO_"+kind.upper(),severity="hold",message=f"{kind.title()} screening requires review",action="Complete fresh, valid NeuroVision screening and request human review. Non-diagnostic demo only."))
    return summaries,alerts
