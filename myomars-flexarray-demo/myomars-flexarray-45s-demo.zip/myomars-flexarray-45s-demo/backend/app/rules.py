"""Synthetic demo rules v1. These are NOT NASA or clinical limits."""
import math
BASELINES = {
    "a01": {"name": "Maya Chen", "role": "EVA Commander", "heart_rate": 62, "systolic": 116, "diastolic": 74, "reaction_ms": 280},
    "a02": {"name": "Alex Rivera", "role": "Field Geologist", "heart_rate": 70, "systolic": 122, "diastolic": 78, "reaction_ms": 310},
}
PRIORITY = {"critical": 0, "hold": 1, "caution": 2, "info": 3}

def rer(vo2, vco2):
    if vo2 is None or vco2 is None or not all(math.isfinite(v) for v in (vo2, vco2)) or vo2 <= 0 or vco2 < 0:
        return None
    return round(vco2 / vo2, 3)

def ordered(alerts):
    return sorted(alerts, key=lambda a: (PRIORITY[a["severity"]], a["code"]))

def alert(code, severity, message, action):
    return dict(code=code, severity=severity, message=message, action=action)

def assess(data):
    b = BASELINES[data.astronaut_id]
    alerts = []
    missing = [k for k in ("sleep", "stress", "heart_rate", "systolic", "diastolic", "reaction_ms") if getattr(data, k) is None]
    if missing or not data.symptoms:
        alerts.append(alert("MISSING_DATA", "hold", "Required assessment data missing", "Complete all measures and symptom check."))
    if data.age_seconds > 300:
        alerts.append(alert("STALE_DATA", "hold", "Assessment measurements are stale", "Repeat assessment with fresh measurements."))
    if "none" in data.symptoms and len(data.symptoms) > 1:
        alerts.append(alert("INVALID_SYMPTOMS", "hold", "Conflicting symptom entries", "Correct symptom selection."))
    if data.systolic is not None and data.diastolic is not None and data.systolic <= data.diastolic:
        alerts.append(alert("INVALID_BP", "hold", "Blood pressure values inconsistent", "Repeat blood pressure measurement."))
    if any(s in data.symptoms for s in ("chest pain", "shortness of breath")):
        alerts.append(alert("SEVERE_SYMPTOM", "critical", "Serious symptom reported", "Do not start EVA. Seek human medical review."))
    elif any(s != "none" for s in data.symptoms):
        alerts.append(alert("SYMPTOM", "hold", "Symptom reported", "Human medical review required before EVA."))
    if data.sleep is not None and data.sleep < 6:
        alerts.append(alert("SLEEP", "hold", "Sleep below demo readiness threshold", "Rest and reassess with a human reviewer."))
    if data.stress is not None and data.stress >= 7:
        alerts.append(alert("STRESS", "hold", "Elevated reported stress", "Pause and request human review."))
    if data.heart_rate is not None and abs(data.heart_rate-b["heart_rate"]) > 25:
        alerts.append(alert("HR", "hold", "Heart rate differs from individual baseline", "Rest, repeat measure, and request review."))
    if data.systolic is not None and data.diastolic is not None and (abs(data.systolic-b["systolic"]) > 25 or abs(data.diastolic-b["diastolic"]) > 15):
        alerts.append(alert("BP", "hold", "Blood pressure differs from baseline", "Repeat measurement and request human review."))
    if data.reaction_ms is not None and data.reaction_ms > b["reaction_ms"] * 1.5:
        alerts.append(alert("REACTION", "hold", "Reaction time slower than individual baseline", "Rest and repeat reaction test."))
    return {"status": "hold" if alerts else "awaiting_human", "alerts": ordered(alerts), "baseline": b, "rules_version": "demo-v1"}

def evaluate_telemetry(data):
    alerts=[]
    if any(getattr(data,k) is None for k in ("vo2", "vco2", "oxygen", "co2")) or data.age_seconds > 15:
        alerts.append(alert("SENSOR_QUALITY", "hold", "Missing or stale sensor data", "Pause activity and verify sensors with mission control."))
    if data.oxygen is not None and data.oxygen < 20:
        alerts.append(alert("O2_LOW", "critical", "Simulated suit oxygen reserve low", "Stop task; contact mission control and begin simulated return protocol."))
    if data.co2 is not None and data.co2 >= 1:
        alerts.append(alert("CO2_HIGH", "critical", "Simulated suit CO₂ elevated", "Stop task; verify scrubber and request mission control guidance."))
    value=rer(data.vo2,data.vco2)
    if value is not None and value > 1.1:
        alerts.append(alert("RER_CONTEXT", "info", "RER elevated; contextual signal only", "Review workload and sensor quality. RER alone never triggers abort."))
    return {"rer": value, "alerts": ordered(alerts), "rules_version": "demo-v1"}
