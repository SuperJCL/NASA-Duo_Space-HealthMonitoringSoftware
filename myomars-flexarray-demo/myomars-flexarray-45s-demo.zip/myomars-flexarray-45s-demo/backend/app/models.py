from typing import Literal
from pydantic import BaseModel, Field

class Assessment(BaseModel):
    astronaut_id: Literal["a01", "a02"]
    mission_id: Literal["eva-042", "eva-043"]
    sleep: float | None = Field(default=None, ge=0, le=24)
    stress: int | None = Field(default=None, ge=1, le=10)
    heart_rate: int | None = Field(default=None, ge=20, le=250)
    systolic: int | None = Field(default=None, ge=50, le=250)
    diastolic: int | None = Field(default=None, ge=30, le=160)
    symptoms: list[Literal["none", "headache", "dizziness", "chest pain", "shortness of breath"]]
    reaction_ms: float | None = Field(default=None, ge=100, le=5000)
    age_seconds: float = Field(default=0, ge=0)

class Authorization(BaseModel):
    assessment_id: int
    operator: str = Field(min_length=2, max_length=80)
    confirmed: Literal[True]

class Telemetry(BaseModel):
    vo2: float | None = Field(default=None, gt=0, le=10)
    vco2: float | None = Field(default=None, ge=0, le=10)
    oxygen: float | None = Field(default=None, ge=0, le=100)
    co2: float | None = Field(default=None, ge=0, le=10)
    age_seconds: float = Field(default=0, ge=0)

from .neurovision import Screening

class NeuroReadiness(Assessment):
    reaction_screening: Screening | None = None
    visual_screening: Screening | None = None
