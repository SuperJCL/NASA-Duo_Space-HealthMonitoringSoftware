# ASTRA — NeuroVision and 3D interface delivery

The existing React/TypeScript/Tailwind, FastAPI/Pydantic, SQLite, Recharts, and Pytest application was extended in place. The six mission screens, original API routes, original safety calculations, and original 33 tests are retained.

## Delivered

- Dark navy `#060D19`, cyan `#4CE4F5`, and Mars orange `#FF9A62` visual layer across all six screens.
- Interactive full-body anatomical schematic with brain, eyes, heart, lungs, ribs, spine, joints, hands, and feet. Three.js renders local procedural geometry; no external model, texture, font, or clinical asset is required.
- Body-system selection, bounded zoom, mouse/touch rotation, keyboard-accessible controls, desktop scroll-driven focus, and smooth camera transitions. Right-side context adapts to the selected region and the existing ASTRA data.
- Actual missing inputs show **Not Assessed**. Unavailable muscle/bone measurements and metabolic baselines are acknowledged explicitly.
- Automatic SVG 2D fallback on WebGL initialization failure or context loss, plus manual toggle and retry. Reduced-motion preference removes camera interpolation, damping, CSS transitions, and chart animation.
- Persistent critical safety rail across all six screens; deterministic safety guidance remains separate from the visualization. No AI can authorize EVA or override an alert. RER alone remains informational.
- NeuroVision reaction and visual simulations integrated into Pre-EVA readiness. Trial-level response times, missed stimuli, errors, timestamps, quality, fictional personal comparisons, and longitudinal charts are saved locally.
- Started/completed/interrupted cognitive events queue offline and sync to the additive SQLite `neuro_events` table and the existing audit log. Idempotent event IDs prevent duplicate audit records during retries.
- A new `/api/readiness` contract requires fresh, valid cognitive evidence. Legacy `/api/assessments` remains compatible with Sprint 1 and is not used by the updated UI. Human authorization rechecks cognitive evidence age.
- Build-generated offline asset manifest precaches all JavaScript and CSS, including the 3D renderer. Cache versions follow asset hashes.

## Verification

- **65 backend Pytest tests passed**, including all original 33, 32 new tests, API validation, audit idempotency, cognitive-data holds, explicit human authorization, expiry, preserved critical priority, and Python/TypeScript parity.
- **27 frontend unit tests passed**: body data/selection targets/zoom limits, missing-data labels, deterministic context, cognitive calculations, latest-attempt behavior, invalid data, local storage failure, and offline synchronization.
- TypeScript check and Vite React production build passed. A non-blocking size advisory remains for the Recharts vendor bundle.
- Headless Chromium browser suite passed: 3D selection/rotate/zoom/drag, scrolling camera focus, WebGL context-loss fallback and retry, six-screen navigation, missing-data holds, complete and interrupted screening, missed stimuli, longitudinal records, human attestation, critical alerts across screens, and RER information-only behavior.
- Offline browser reload retained the 3D scene and permitted both screenings plus explicit human authorization without network access. Reconnection flushed events and verified SQLite-backed API audit records.
- Mobile viewport (390×844), all six screens without horizontal page overflow, reduced-motion preference, body selection, and corrupt-storage holds passed. No page runtime errors were observed. Desktop/mobile screenshots were inspected.

The browser script is `frontend/tests/browser.cjs`; it uses a fresh browser profile but adds synthetic records to the local demo database. Unit/backend tests use isolated storage/database fixtures.

## Run

From the `astra-health` project folder:

```sh
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cd ../frontend
npm install
npm run build
cd ../backend
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000. If a previously cached Sprint 1 page appears, allow the service-worker update to finish and refresh the tab once. Load the production app successfully once before testing offline reload. No deployment or external service configuration is required.

To run checks:

```sh
# From backend, with the virtual environment active and Node on PATH:
python -m pytest -q
# From frontend:
npm test
npm run build
npx playwright install chromium
# Keep the local API server running, then:
npm run test:browser
```

## Modified and added files

| Area | Files |
|---|---|
| Existing UI | `frontend/src/main.tsx`, `frontend/src/style.css` |
| Body explorer (new) | `frontend/src/BodyExplorer.tsx`, `frontend/src/bodyScene.ts`, `frontend/src/bodyData.ts` |
| Cognitive assessment (new) | `frontend/src/NeuroVisionPanel.tsx`, `frontend/src/neurovision.ts` |
| Offline/build/dependencies | `frontend/public/sw.js`, `frontend/vite.config.ts`, `frontend/package.json`, `frontend/pnpm-lock.yaml`, `frontend/pnpm-workspace.yaml` |
| Existing API integration | `backend/app/main.py`, `backend/app/models.py` |
| Cognitive contracts/rules (new) | `backend/app/neurovision.py` |
| New tests | `backend/tests/test_neurovision.py`, `frontend/tests/neurovision.test.cjs`, `frontend/tests/body.test.cjs`, `frontend/tests/browser.cjs` |
| Delivery/docs | `README.md`, `IMPLEMENTATION.md`, `contracts/openapi.json`, generated `frontend/dist/`, desktop/mobile/NeuroVision screenshots, project archive |

Original `backend/app/rules.py`, `frontend/src/rules.ts`, and the original backend test files remain unchanged.

## Limitations

This is a non-diagnostic simulation with fictional crew profiles, baselines, and thresholds. It does not diagnose SANS or neurological disease, measure gaze or calibrated visual fields, use real hardware, or provide medical treatments. No NASA medical or operational validation is claimed. The anatomical model is schematic, not a clinical scan. Timing depends on the browser and input device.

Human attestation is named demo input, not authenticated identity. LocalStorage and SQLite records are not encrypted or tamper-proof. Initial installation/caching requires connectivity; browser storage has capacity limits and no multi-tab conflict resolution. Abrupt tab closure or reload retains an incomplete start record, while partial in-memory trials may be lost. Completed results persist. Only NeuroVision events automatically sync; general offline readiness and authorization logs remain browser-local/exportable. Synced server history is inspectable by API but is not automatically restored into a cleared browser profile. No mobility/bone sensors or individual VO₂ baseline exist. A full physical-device and accessibility audit remains outstanding.

## MuscleSense extension

Added `frontend/src/MuscleSensePanel.tsx` and `frontend/src/muscleSense.ts`, with side-specific quadriceps focus/highlighting in `BodyExplorer.tsx` and `bodyScene.ts`, and phase-specific integration in `main.tsx`. Added feature/calculation tests and a dedicated browser workflow test. Documentation and generated production assets updated.

Verification: 65 backend tests and 35 frontend unit tests passed; TypeScript and production build passed. Dedicated MuscleSense browser test passed side selection, live simulated telemetry, local Pre-/Post-EVA records, offline reload, and artifact suppression with no runtime errors.

MuscleSense is advisory, with browser-local saved summaries only. It does not change physiological rules, human authorization or the SQLite audit API. Source-backed interpretation limits and the V1/V2/V3 roadmap are in the README and module UI. No invasive procedure or clinical validation is provided.
