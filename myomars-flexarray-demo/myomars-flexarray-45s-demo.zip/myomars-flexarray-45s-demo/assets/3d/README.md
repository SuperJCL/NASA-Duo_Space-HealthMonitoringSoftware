# ASTRA FlexArray-MN V2.1 — 3D assets (GLB)

> Conceptual engineering design — not manufactured, clinically validated, or flight-qualified.

The model ships in two **visualization scales**. They match the toggle in the 3D Explorer.

| | Presentation scale | Engineering scale |
|---|---|---|
| Purpose | Legible slides and demos | Proportion check against research-candidate dimensions |
| Footprint | 64 × 48 mm (concept design value) | 64 × 48 mm |
| Electrode pitch | 5 mm (candidate) | 5 mm (candidate) |
| Microneedle length | **3.6 mm drawn = 18×** the 200 µm candidate | **0.2 mm** = 200 µm candidate (1×) |
| Microneedle base | 1.1 mm drawn | 60 µm (candidate) |
| Layer thickness | Exaggerated 4–24× (0.5–0.8 mm per layer) | 30 µm film (candidate), other layers **assumed** (see below) |
| Assembled height | 4.1 mm | 1.4 mm. The 0.505 mm laminate plus assumed chips up to 1.2 mm |
| Labelled as | "NOT TO SCALE" | "Not a manufacturing spec" |

Neither scale is a manufacturing specification.

## Files

| File | Size |
|---|---|
| `flexarray-mn-v2.1-presentation-assembled.glb` | 2,804,668 B (2.7 MB) |
| `flexarray-mn-v2.1-presentation-exploded.glb` | 2,804,680 B (2.7 MB) |
| `flexarray-mn-v2.1-presentation-explode-animated.glb` (2 s `Explode` clip) | 2,807,092 B (2.7 MB) |
| `flexarray-mn-v2.1-engineering-assembled.glb` | 2,804,796 B (2.7 MB) |
| `flexarray-mn-v2.1-engineering-exploded.glb` | 2,804,808 B (2.7 MB) |
| `flexarray-mn-v2.1-engineering-explode-animated.glb` (2 s `Explode` clip) | 2,807,224 B (2.7 MB) |
| `flexarray-mn-v2.1-presentation-exploded-preview.png` | 2,340,310 B (2.2 MB) |
| `flexarray-mn-v2.1-presentation-assembled-preview.png` | 2,394,017 B (2.3 MB) |
| `flexarray-mn-v2.1-engineering-exploded-preview.png` | 2,305,184 B (2.2 MB) |
| `flexarray-mn-v2.1-engineering-microneedle-closeup-preview.png` | 2,543,506 B (2.4 MB) |

The previews are 1920 × 1080 Blender (EEVEE) renders of the GLBs. Each has a caption band stating the scale, the exaggeration and the disclaimer, so they can go straight onto a slide.

Regenerate the GLBs from the Explorer's geometry spec. This also re-runs the import checks:

```sh
cd frontend
npm run export:glb
```

## Dimension basis (engineering scale)

| Item | Value | Basis |
|---|---|---|
| L1 protective film | 30 µm | Research candidate (mid-point of 20–50 µm) |
| L2 microneedle substrate | 25 µm | Assumption |
| L3 sweat-management layer | 200 µm | Assumption |
| L4 flex PCB (without components) | 100 µm | Assumption |
| L5 stretchable interconnect | 50 µm | Assumption |
| L6 adhesive frame | 100 µm | Assumption |
| Microneedle | 200 µm long, 60 µm base | Research candidate (unvalidated) |
| Contact pad | 2 mm Ø × 20 µm | Assumption |
| Needles per site | 1 | Assumption |
| Microchannel width | 200 µm (100–300 µm) | Research candidate |
| Trace width | 70 µm (50–100 µm) | Research candidate |
| Component package heights | 0.7–1.2 mm | Assumption |
| Exploded spacing | 10.5 mm | Viewing offset only |

**Open design issues the engineering scale exposes.** Both are also written into each GLB's metadata.

1. **Needle reach.** In the V2.1 stack order, layers 3–6 (≈ 450 µm, assumed) sit between the needle base and the skin. A 200 µm needle on layer 2 would end ≈ 250 µm short of the skin, so apertures or a re-ordered stack are needed.
2. **Component height.** The assumed component packages (up to 1.2 mm) are taller than the 0.505 mm laminate. In the engineering view they protrude through layers 1–3, so a real cover would need to dome over the electronics island.

## Structure (both scales)

```
FlexArrayMN_V2_1_<scale>_<configuration>   root (scale 0.01 → metres)
├─ L1_Protective_film            __Substrate, __BreathablePores
├─ L2_Microneedle_array          __Substrate, __ContactPads (64), __Microneedles (64), __RowTraces
├─ L3_Sweat_management           __Substrate, __MicrofluidicChannels, __ElectrodeIsolationRings (64)
├─ L4_Flexible_electronics       __Substrate, 7 named components, __AFE_Pins, __CopperTraces_Antenna
├─ L5_Stretchable_interconnect   __Substrate, __SerpentineTraces
└─ L6_Adhesive_frame             __Substrate
```

**Root metadata.** The root node's glTF `extras` hold:
- `visualization_scale`, `scale_note`, `footprint_mm`, `candidate_electrode_pitch_mm`;
- `candidate_microneedle_length_um`, `rendered_microneedle_length_mm`, `visualization_exaggeration`;
- the per-layer `layer_thickness` table (rendered, engineering, basis, exaggeration);
- `engineering_details`, `open_issues` and `disclaimer`.

**Layer and part metadata:**
- Each layer node carries its rendered and engineering thickness and their basis.
- The `__Microneedles` mesh carries the candidate length, rendered length and exaggeration.

**Orientation:** metres, +Y away from skin (glTF), skin-facing surface at Y = 0, long axis X. Blender converts to Z-up on import.

## Validation performed (2026-11-14)

- **Khronos glTF-Validator 2.0.0-dev.3.10:** 0 errors and 0 warnings on all six GLBs. Each file has 22 informational notes; I didn't print them to see what they are.
- **three.js `GLTFLoader` re-import** (`frontend/scripts/validate-flexarray-glb.mjs`), all six files. Checks:
  - root, scale and the exact disclaimer;
  - the six layers in order;
  - gold color and metalness, transparency, emissive;
  - the 64 × 48 mm footprint;
  - **measured needle-mesh height**: 3.6 mm presentation, 0.2 mm engineering;
  - **measured film thickness**: 500 µm vs 30 µm;
  - the `extras` scale metadata (18× vs 1×);
  - assembled and exploded spacing, and the animation clip.
- **Blender 5.2.2 headless import**, all six files: one root and the six named layers, 22 meshes, 18 materials, correct extents, and the `Explode` action present.

## Open in Blender

1. Open **File → Import → glTF 2.0 (.glb/.gltf)** and pick a file.
2. Press **Numpad .** (View Selected) to frame it; the patch is only 6 cm wide.
3. In the Outliner, expand the root and select or hide `L1`–`L6`.
4. Use **Material Preview** or **Rendered** to see transparency. If layers hide details behind them, set each material's **Render Method** to **Dithered**.
5. For engineering files, zoom close to a needle (front-right electrode); it is 0.2 mm long. To read dimensions in millimetres, set **Scene → Units → Unit Scale 0.001, Length = Millimeters**.
6. In `*-explode-animated.glb`, press **Space** to play `Explode`.
7. Read the scale metadata in **Object Properties → Custom Properties** on the root object.

## Insert into PowerPoint (Microsoft 365)

1. Go to **Insert → 3D Models → This Device…** (macOS: **Insert → 3D Model → From File…**) and choose a GLB.
2. Use the **presentation** files on slides. Engineering-scale needles and films are too small to see at slide size; use the engineering close-up PNG instead.
3. **To show the layers separating**, choose one approach:
   - **Morph:** put the assembled file on slide N and the exploded file on slide N+1, at the same position and view, then apply **Transitions → Morph**.
   - **Animation:** insert `*-explode-animated.glb` and use **Animations → Play 3D**.
4. **Keep a scale label on the slide.** PowerPoint doesn't show the GLB metadata. Add "Not to scale — microneedles drawn 18×" next to presentation models, or use the captioned preview PNGs.

I tested neither of these steps inside PowerPoint itself.

## Limitations of the exported materials

- **PBR metallic-roughness only.** The Explorer's selection glow, outlines, fading, hover, holographic floor, flow particles and stretch animation are not exported. Glow becomes a flat emissive tint, with no bloom.
- **Transparency** uses `alphaMode: BLEND`. PowerPoint and Blender's default *Blended* mode sort per object, so details behind a translucent layer can disappear at some angles. In Blender, use *Dithered*.
- **Lines become thin tubes.**
  - Presentation scale: 0.2–0.28 mm Ø.
  - Engineering scale: the 70 µm candidate trace width and 200 µm channel width.
- **No text inside the GLB.** Labels exist as node names and metadata; badge text and callouts are not 3D geometry.
- **Metallic gold looks dark** in viewers without an environment map, because metal reflects its surroundings.
- **Fixed configuration:** 8 × 8 grid, interconnect relaxed (0 % strain).
- **PowerPoint treats each GLB as one object.** You can't click individual layers on a slide; use Blender for that.

**Superseded files.** The previous unprefixed `flexarray-mn-v2.1-{assembled,exploded,explode-animated}.glb` and their previews were replaced by the presentation-scale files above, which have the same geometry plus scale metadata. The old files were moved out of this folder, not kept here.
