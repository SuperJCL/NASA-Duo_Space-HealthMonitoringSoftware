# ASTRA FlexArray-MN V2.1 — 3D Layer Explorer: implementation report

> Conceptual engineering design — not manufactured, clinically validated, or flight-qualified.

## Where it lives

- **Route:** new nav entry **07 · FlexArray-MN patch** in the existing ASTRA shell. Deep link: `/#flexarray` (works on the FastAPI single-server build and `vite preview`).
- **Module:** `frontend/src/flexarray/`, lazy-loaded so the main bundle does not grow (explorer 40 kB, scene 189 kB, both loaded on first visit).

| File | Role |
|---|---|
| `flexArrayData.ts` | Typed config: 6 layers, parameters (`id, label, value, unit, category, rationale, source_id, validation_status`), references, disclaimer, `channelEstimate()` |
| `flexArrayGeometry.ts` | Pure geometry: stack/explode offsets, electrode grid, arc-length-conserving serpentine, sweat routes, component placement, skin layers, camera presets |
| `FlexArrayScene.tsx` | React Three Fiber scene: 6 pickable layers, skin cross-section, thigh attachment, camera rig |
| `FlexArray2D.tsx` | Functional SVG fallback (same state: select, visibility, explode, stretch, skin, thigh) |
| `ElectrodeMatrix.tsx` | Top-view matrix: sites → derivations → digitized channels |
| `FlexArrayExplorer.tsx` | Page: toolbar, layer list, inspector, KPIs, references, 16:9 presentation mode |
| `flexarray.css` | Styles scoped under `.fa-root` (navy `#060D19`, cyan `#4CE4F5`, gold contacts) |

## Page redesign (product showcase)

The FlexArray route is now a full-screen product showcase:
- a minimal header;
- an 01–06 layer selector;
- a compact, closable layer panel (a bottom sheet on phones);
- a glass control dock;
- a "Research & References" sheet that holds all detailed engineering content.

The model, geometry, data and GLB tooling are unchanged. Before/after screenshots, the changed-file list and test results are in `docs/flexarray-redesign/README.md`.

## Mars EVA preparation bay backdrop

The patch now sits in an original, procedurally generated Mars EVA preparation bay. It contains a metallic interior, suit lockers, a medical station, and a Mars window behind the hologram. The bay is a background only, labelled "not to scale", and can be switched to Minimal under Research → System settings.

Details, asset provenance, frame-rate figures, screenshots and changed files are in `docs/flexarray-bay/README.md`.

## Guided demonstration (45 s)

"Start demo" plays exactly 45 seconds of scripted content in four scenes:
1. **Before EVA** (0:00–0:07)
2. **FlexArray Technology** (0:07–0:18): the patch explodes; layers 02, 03 and 04 are highlighted.
3. **AI Muscle Monitoring** (0:18–0:32): a simulated HUD with synthetic MuscleSense sEMG and IMU data. A left-quadriceps alert, labelled "Not a diagnosis", appears only once the existing MuscleSense rule triggers.
4. **Mars Base Medical Review** (0:32–0:45): evidence, baseline and sensor quality, then a human reviewer gate, a simulated retest instruction, the crew acknowledgment and a reassessment.

Captions are 10 words or fewer. The clock pauses at the reviewer gate (0:35) until a person confirms, so real elapsed time can exceed 45 s; the UI says so.

Controls: play/pause, previous/next, replay, skip, seek, Escape. Reduced motion is respected.

Autoplay never confirms the reviewer gate. The demo makes no API calls and writes nothing to storage.

Details are in `docs/flexarray-demo/README.md`.

## Changes to existing files (additive only)

- `frontend/src/main.tsx`: one entry appended to `screens`, plus a matching h1/subtitle; a lazy `<FlexArrayExplorer/>` for screen 6; `#flexarray` hash sync. No changes to telemetry, assessment, NeuroVision, authorization, or safety rules.
- `frontend/package.json`: added `@react-three/fiber@8.18.0` and `@react-three/drei@9.122.0` (the React 18 lines), plus a `test:flexarray` script.
- Backend: **no changes.**

## Feature checklist

1. Drag to rotate, scroll/pinch to zoom (OrbitControls; `touch-action: none` on the canvas).
2. Click a layer to select it (R3F raycasting; drags over 6 px are ignored). Clicking empty space clears the selection.
3. The selected layer gets a cyan edge and emissive glow; the other layers fade to 12 % opacity.
4. Assembled/exploded animation is a lerp in `useFrame`. Progress is exposed as `data-explode-progress` for tests.
5. Per-layer visibility checkboxes; Reset camera; Reset model.
6. Views: Layer stack · Top view · Skin cross-section · Thigh attachment.
7. Layer 5 stretch: a slider and an animated cycle. The serpentine straightens with numerically conserved arc length; this is illustrative kinematics, not FEA.
8. Layer 3: microfluidic routes, isolation rings per electrode, and flow particles (hidden under reduced motion).
9. Layer 4: AFE, signal conditioning, ADC, IMU, MCU, radio and antenna, and a battery at a conceptual position, with callouts.
10. Keyboard:
    - Viewport: ←/→ rotate, ↑/↓ tilt, +/− zoom, `E` explode, `T` top view, `R` reset camera, `1–6` select a layer, `Esc` clear.
    - Layer list: ↑/↓ move the selection.
    - Inspector tabs: ←/→ switch tabs.
11. `prefers-reduced-motion`: transitions and camera moves are instant; auto stretch and flow animations are disabled.
12. 2D fallback: used automatically when WebGL is missing, the context is lost, or the renderer crashes (error boundary). It can also be switched on manually.
13. "Present 16:9" opens a fixed 16:9 stage fitted to the screen; `Esc` exits.

## Visualization scale (presentation vs engineering)

- A toolbar toggle switches between **Presentation scale** and **Engineering scale**. The `S` key does the same.
- Both scales come from `SCALE_PROFILES` in `flexArrayGeometry.ts`, which the Explorer and the GLB exporter share.
- **Presentation scale:**
  - A viewport badge reads "NOT TO SCALE".
  - An in-scene tag reads "needles drawn 3.6 mm = 18× the 200 µm candidate".
  - Layer thickness is exaggerated 4–24×.
- **Engineering scale:**
  - Uses research-candidate dimensions: 200 µm × 60 µm needles, a 30 µm film, 200 µm channels and 70 µm traces.
  - Every unknown dimension is shown as an **Assumption**.
  - Badge: "not a manufacturing spec".
  - The camera can zoom to about 1.2 mm, and a "Zoom to microneedles" button gives a true-scale close-up.
- **Readout strip**, always visible, including in 16:9 mode: footprint 64 × 48 mm, candidate pitch 5 mm, candidate needle 200 µm, rendered needle 3.6 mm or 0.2 mm, and exaggeration 18× or 1×.
- **Scale card**: a per-layer thickness table (drawn vs engineering, basis, exaggeration), the assumption list, two computed design checks, and the disclaimer.
  - **Needle reach:** the assumed layers 3–6 add up to 450 µm below the needle base, so the needle tip would end 250 µm short of the skin.
  - **Component height:** the assumed chips (up to 1.2 mm) are taller than the 0.505 mm laminate.
- **Visible change in presentation scale:** detail parts (pads, rings, chips, traces) now sit on their layer surface rather than floating up to 0.6 mm above it. This matches the GLB export.

## Scientific framing

- **Categories:**
  - **A. Established Measurement Parameters:** 2000 Hz, 20–500 Hz, 500 ms RMS. These are conventional settings, and the UI says so; they are not device claims.
  - **B. Proposed Engineering Targets:** 16-bit ADC, 6-axis 100 Hz IMU, 8×8 candidate grid, 5 mm pitch, ≥ 8 h runtime, candidate needle 200 µm / 60 µm.
  - **C. Pending Validation:** penetration depth, impedance reduction, SNR, skin safety, sweat drift, cyclic durability.
- The "6–10 dB SNR improvement" from the earlier concept graphic is **withdrawn**. The UI shows "Not established".
- 8×8 means **64 electrode sites**. The matrix panel computes derivations and the maximum number digitized for a chosen AFE channel count, and states that the signals are not independent.
- The skin cross-section shows a *nominal* tip position at the candidate length. It labels this "not a penetration measurement", and the layer thicknesses are illustrative.
- The patch spec's stack order puts the microneedles (layer 2) above layers 3–6. This is listed as an open limitation: aperture alignment is not engineered.

## References (verified 2026-11-14 via Crossref, PubMed, nature.com, spinoff.nasa.gov, techport API)

1. Krieger KJ, Lijnse TM, Lowery MM, O'Cearbhaill ED. *Microneedle electrodes for electromyography.* Biosens Bioelectron 290:117945 (2025). doi:10.1016/j.bios.2025.117945. A review; one author discloses a conflict of interest.
2. Zhou C, Yao G, Gan X, et al. *Modulus-adjustable and mechanically adaptive dry microneedle electrodes for personalized electrophysiological recording.* npj Flex Electron 9:77 (2025). doi:10.1038/s41528-025-00458-9. Uses ~800 µm needles; penetration depth was not measured.
3. NASA Spinoff (2022). *Electrical Body Signals Help Researchers Restore Movement and More* (Delsys wireless EMG).
4. NASA Spinoff (2000). *Monitoring on the Move* (Delsys MyoMonitor).
5. NASA TechPort 6447. *Lightweight, Wearable Metal Rubber-Textile Sensor for In-Situ Lunar Autonomous Health Monitoring, Phase II* (2007–2009). Not EMG-specific.
6. Hermens HJ et al. *Development of recommendations for SEMG sensors and sensor placement procedures.* J Electromyogr Kinesiol 10(5):361–374 (2000). doi:10.1016/S1050-6411(00)00027-4.

None of the NASA sources involves microneedles. Any reference added later without verification shows "Reference verification pending" (enforced by unit test).

## Test results (2026-11-14, after the visualization-scale update)

| Suite | Result |
|---|---|
| Backend `pytest` | 65 passed. `rules.py` and `main.py` are unchanged |
| Frontend unit `npm test` | 53 passed: 35 original + 18 FlexArray, 5 of them new for scale |
| `npm run build` (tsc + vite) | Succeeds; only the pre-existing >500 kB chunk warnings |
| Existing e2e `tests/browser.cjs` | 5/5 PASS: 3D, safety, offline, accessibility, no runtime errors |
| Existing `tests/muscle-browser.cjs` | PASS |
| `tests/flexarray-browser.cjs` | 19/19 PASS, including the new visualization-scale check |
| GLB: Khronos validator, three.js re-import, Blender import | All 6 files pass |

**How the browser suites were served.** All browser suites ran against temporary FastAPI servers using a throwaway SQLite database.

**Correction to earlier reports.** `tests/muscle-browser.cjs` hardcodes `http://127.0.0.1:8000` and ignores `ASTRA_URL`. Its earlier "PASS" results therefore ran against the user's own server on port 8000, not my test build. This run used a temporary server on port 8000, started after the user's server had stopped.

**The new scale check** covers:
- the readout values (64 × 48 mm, 5 mm, 200 µm, 3.6 mm, 18×), and 0.2 mm / 1× after the toggle;
- the badges and needle tag;
- the canvas changing between scales;
- the thickness table, both design checks, and the exact disclaimer;
- all six layers still selectable;
- a 3D pick in engineering scale;
- the needle close-up and the `S` key.

Run the browser tests against a served build:

```sh
cd frontend && npm run build
npx vite preview --host 127.0.0.1 --port 4173 &
ASTRA_URL=http://127.0.0.1:4173 npm run test:flexarray
```

## GLB export

Presentation-scale and engineering-scale GLBs (assembled, exploded, animated) and captioned previews are in `assets/3d/`. See `assets/3d/README.md`; regenerate with `cd frontend && npm run export:glb`.

## Known limitations / next steps

- Geometry is procedural (Three.js primitives), not CAD. The GLB export (`assets/3d/`) is a presentation model.
- In-canvas labels use DOM overlays (`Html`), not 3D text, so the app needs no external font fetch and stays offline-capable.
- Electrode/needle sizes are vertically exaggerated in the stack view; the skin view is drawn to scale (1 unit = 120 µm), with dermis and fat truncated.
