# FlexArray-MN page redesign — product showcase

> Conceptual engineering design — not manufactured, clinically validated, or flight-qualified.

Only the FlexArray route (`/#flexarray`, nav item 07) was redesigned. The six-layer model, the geometry and data modules, the GLB exporter and validator, the backend, and all other ASTRA screens are unchanged.

## Before / after

| | Before | After |
|---|---|---|
| Desktop | `before-desktop.png` | `after-desktop.png` |
| Desktop, layer 02 selected | `before-desktop-layer2-selected.png` | `after-desktop-layer2-selected.png` |
| Phone (390 × 844) | `before-mobile.png` | `after-mobile.png` |
| Phone, layer 02 selected | `before-mobile-layer2-selected.png` | `after-mobile-layer2-selected.png` (bottom sheet) |
| Engineering scale, needle close-up | — | `after-desktop-engineering-needle-closeup.png` |
| Research sheet: scale & assumptions | — | `after-desktop-research-scale-sheet.png` |

## What changed on the page

**Full-screen 3D viewer.**
- The canvas fills the viewport; the test checks it covers at least 75 % of the visual area.
- Background is a near-black-to-navy gradient with a soft vignette.
- The model's existing cyan lighting and gold contacts are kept.
- The console sidebar, page title block, KPI cards and boxed panels are gone from this route.

**Minimal header:**
- a small "‹ ASTRA" back link;
- "ASTRA FlexArray-MN" with the subtitle "Interactive 3D Layer Explorer";
- the scale badge;
- top right: the Presentation / Engineering scale switch and a "Research & References" button.

**Layer selector.**
- Six small numbered controls, 01–06: a vertical rail on desktop, a horizontal row on phones.
- Hovering shows the layer name; the selected layer glows.
- Arrow keys move through the layers.
- Clicking directly in the 3D model still selects a layer.

**Compact layer panel.**
- Hidden by default. It opens on selection and has a close button.
- Contents: layer name, validation badge, purpose, four key parameters, design rationale and validation status.
- The four key parameters are two proposed targets plus two pending-validation items, so limitations are never dropped.
- Layer controls: stretch for layer 05, "Zoom to microneedles" for layer 02, and Hide / Show layer.
- "Full engineering data" expands the complete parameter table, material, limitations and evidence.
- On phones the panel opens as a bottom sheet.

**Glass dock** with these controls:
- Rotate ⟲ ⟳
- Zoom − +
- Explode / Assemble
- View menu: stack, top, skin cross-section, thigh
- Reset view
- Full screen, using the Fullscreen API

**Scale is always labelled.**
- The badge reads "NOT TO SCALE · thickness & microneedles exaggerated" in presentation scale, and "candidate + assumed dimensions · not a manufacturing spec" in engineering scale.
- The readout line shows footprint 64 × 48 mm, pitch 5 mm, needle 200 µm candidate drawn at 3.6 mm (18×), or 0.2 mm (1×) in engineering scale.
- The in-scene needle tag stays.
- Clicking the badge opens the full scale table and both open design limitations: needle reach and component height.

**Research & References** is a modal side sheet (bottom sheet on phones). Focus moves into it, Escape closes it, and focus returns to the button that opened it. Its tabs:
- References (6, verified);
- Scale & assumptions;
- Electrode matrix;
- System settings: the A/B/C categories, Reset model, and the 2D schematic toggle;
- Controls: a keyboard map.

**Disclaimer** — shown under the dock and inside the research sheet.

**Cinematic but calm motion:**
- an eased panel and sheet slide-in;
- gentle highlight and fade on the model;
- hover glow;
- the hint text fades after the first interaction;
- smooth camera moves.

`prefers-reduced-motion` turns off every CSS animation and transition, and the 3D transitions become instant.

**Safety.** The persistent critical-alert rail from the console still renders on this route, on top of the page. The dock moves up so the two don't overlap.

**Removed.** The "Present 16:9" stage is gone. The page is now full screen by design, and "Full screen" replaces it. The KPI strip moved to Research → System settings.

## Changed files

| File | Change |
|---|---|
| `frontend/src/main.tsx` | The FlexArray route (screen 6) renders the explorer full-screen without the console shell; it gets `onExit`, which returns to screen 0. The critical-alert rail JSX moved into a shared `criticalRail` constant used by both branches. Markup and logic for other screens are unchanged. |
| `frontend/src/flexarray/FlexArrayExplorer.tsx` | Layout rewritten as the showcase. State, keyboard model, scene wiring, 2D fallback, data and reference components are kept. |
| `frontend/src/flexarray/flexarray.css` | Rewritten. All rules are scoped to `.fa-root` / `.flexarray-route`, with a `:where()` reset that neutralizes the console's global `button` / `select` / range-input styles inside this page only. |
| `frontend/src/flexarray/FlexArrayScene.tsx` | **Camera rig only:** framing that adapts to the screen's aspect ratio, so the whole patch fits on portrait phones, and orbit max distance raised from 24 to 60. Geometry, materials and layer logic are untouched. |
| `frontend/tests/flexarray-browser.cjs` | Rewritten for the new UI: 19 checks (listed below). |
| `docs/flexarray-redesign/*` | Before/after screenshots and this note. |

**Unchanged:** `flexArrayGeometry.ts`, `flexArrayData.ts`, `FlexArray2D.tsx`, `ElectrodeMatrix.tsx`, `scripts/export-flexarray-glb.mjs`, `scripts/validate-flexarray-glb.mjs`, `assets/3d/*`, the entire `backend/`, and every other route.

## Test results (2026-11-14)

| Suite | Result |
|---|---|
| Backend `pytest` | 65 passed |
| Frontend unit (`node --test`) | 53 passed |
| Typecheck + production build | Succeeds. FlexArrayExplorer chunk is 54 kB (19 kB gz) and the main bundle 58.7 kB; only the pre-existing >500 kB chunk warnings |
| GLB re-import validator (existing exports) | All checks passed |
| Existing e2e `tests/browser.cjs` | 5/5 PASS |
| Existing `tests/muscle-browser.cjs` | PASS |
| `tests/flexarray-browser.cjs` | 19/19 PASS, twice in a row |

**How the browser suites were served:**
- `browser.cjs`, `muscle-browser.cjs` and the first 18 FlexArray checks ran against a temporary FastAPI server on port 8000 with a throwaway SQLite database.
- The full 19-check FlexArray suite, including the new safety-rail check, ran against `vite preview` of the same build.

**The 19 FlexArray checks:**
1. Full-screen route with no shell or nav; viewer covers ≥ 75 % of the area; disclaimer present.
2. 01–06 each select their layer.
3. Panel contents and close; full data reachable.
4. Explode/assemble animates through intermediate frames.
5. 3D click picking, and clicking empty space clears.
6. Drag, wheel and dock rotate/zoom change the view; Reset view.
7. Highlight and fade, and hide/show layer.
8. Keyboard (viewer, rail arrows, Escape).
9. Research sheet as a modal: focus moves in and returns; Escape closes.
10. System settings A/B/C categories and electrode matrix.
11. Stretch control, skin and thigh views.
12. Both scale profiles, with labels, table and limitations; 3D pick at engineering scale; needle close-up; `S` key.
13. Full screen.
14. WebGL context loss → 2D fallback.
15. Back to ASTRA, other screens work, deep link restored.
16. Critical-alert rail stays topmost on this page.
17. Reduced motion.
18. Phone: full width, no overflow, dock fits, bottom-sheet panel and research sheet, tap select.
19. No WebGL → functional 2D fallback.

The existing preview PNGs that `tests/browser.cjs` overwrites were backed up and restored around the run.
