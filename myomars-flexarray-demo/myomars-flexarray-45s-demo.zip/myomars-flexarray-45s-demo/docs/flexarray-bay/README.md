# FlexArray-MN — Mars EVA preparation bay backdrop

> Conceptual engineering design — not manufactured, clinically validated, or flight-qualified.

The FlexArray page now places the interactive six-layer patch inside a cinematic Mars EVA preparation bay. The bay is a **background only**. The patch stays large and centered, and still rotates, zooms, explodes, assembles, selects layers and switches scale.

## Asset provenance

**Everything is original and generated in code at runtime**: Three.js primitives plus canvas-drawn textures. No Unity, store, or other third-party models, textures or HDRIs are used. No reference images were attached to the request, so the design follows its written brief only.

| Element | How it is made |
|---|---|
| Metallic interior | Instanced wall panels, ribs, ceiling beams and lamp panels; a reflection map from three.js `RoomEnvironment` (procedural), applied only to bay materials |
| Spacesuit storage | Three stylised suits (two in lite mode) built from capsules and spheres, in lit locker alcoves |
| Medical equipment | Diagnostic couch with scanner arch, supply cabinet, instrument pole, and two wall displays |
| Mars landscape | Canvas painting with a seeded random generator: butterscotch sky, small sun with a bluish halo, layered ridges, craters, rocks and dust haze |
| Lighting & atmosphere | Cyan and warm emissive strips and lamps, the window glow, distance fog, soft light shafts (full quality), slow drifting dust, and a holographic projector column under the patch |
| Airlock & racks | Airlock door with hazard trim, equipment racks with cyan accents |

**Labelling.** The wall displays say "SIMULATED DISPLAY", "DEMO WAVEFORM — NOT CREW DATA" and "NOT MANUFACTURED / NOT FLIGHT-QUALIFIED". The readout states "Patch shown magnified · bay backdrop not to scale". Research → System settings explains the backdrop and offers a **Minimal** background.

## Design and engineering choices

- **Composed for the default camera.** The room is turned so its back wall faces the opening view. That wall reads as a panorama, with the Mars window directly behind the hologram, suit lockers on the left and the medical station on the right.
- **The patch is untouched.**
  - No bay object accepts pointer events, so clicking still picks layers only.
  - The bay adds **no dynamic lights**. Its mood comes from emissive surfaces and a reflection map applied to bay materials only, so the patch is lit exactly as before.
  - Fog starts beyond the patch.
- **Camera stays inside the room.** In bay mode, camera distance is capped at 32 and downward tilt at 1.92 rad (about 110°). A unit test sweeps every allowed orbit position and confirms none leaves the walls, floor or ceiling.
- **Keep-out zone.** A unit test confirms no prop enters a 9-unit cylinder around the hologram.
- **Phones.** On screens under 720 px wide, or devices with 4 or fewer CPU cores, the bay switches to lite quality: fewer suits and dust particles, no light shafts, and a smaller Mars texture.
- **Retina.** In bay mode the canvas pixel ratio is capped at 1.5 so retina screens hold 60 fps.
- **Reduced motion.** Dust stops drifting, and the existing rules apply: instant 3D transitions and no CSS animation.
- **Explode/assemble timing.** The animation step is now capped at 1/20 s, so the transition stays smooth on slow devices instead of jumping in one frame.
- **2D fallback.** Without WebGL, the 2D schematic keeps the bay mood by using the same generated Mars painting as a dimmed background.

## Screenshots (GPU-rendered)

| File | View |
|---|---|
| `desktop-bay.png` | Default view: exploded patch, Mars window behind, suits left, medical right |
| `desktop-bay-orbit.png` | After dragging to orbit |
| `desktop-bay-layer2-selected.png` | Layer 02 selected, compact panel open |
| `desktop-bay-assembled.png` | Assembled patch over the projector |
| `desktop-bay-engineering-scale.png` | Engineering scale |
| `mobile-bay.png` | Phone, lite quality |
| `mobile-bay-layer4-selected.png` | Phone, layer 04 bottom sheet |

## Changed files

| File | Change |
|---|---|
| `frontend/src/flexarray/bayLayout.ts` | **New.** Bay layout spec: room, yaw, window, props, camera limits, quality settings, seeded random generator, ridge generator |
| `frontend/src/flexarray/bayTextures.ts` | **New.** Canvas painters: Mars landscape, labelled wall displays, hazard stripes, floor plates |
| `frontend/src/flexarray/FlexArrayEnvironment.tsx` | **New.** The procedural bay |
| `frontend/src/flexarray/FlexArrayScene.tsx` | Optional `environment` / `quality` props; mounts the bay; in bay mode, caps camera distance, downward tilt and pixel ratio; caps the explode animation step. The patch's geometry, materials and layer logic are unchanged. |
| `frontend/src/flexarray/FlexArrayExplorer.tsx` | Background state (Mars EVA bay, the default, or Minimal) under Research → System settings; automatic lite quality; "bay backdrop not to scale" note; Mars background in the 2D fallback |
| `frontend/src/flexarray/flexarray.css` | Top and bottom legibility gradients over the 3D view; inline background switch style |
| `frontend/tests/flexarray.test.cjs` | +5 unit tests: keep-out zone, camera containment, layout facing the camera, lite settings, deterministic landscape |
| `frontend/tests/flexarray-browser.cjs` | +1 check (bay on by default, labelled, switchable, frame rate reported); bay assertions added to the phone and no-WebGL checks |
| `frontend/tests/flexarray-perf.cjs` | **New.** GPU frame-rate report: bay vs Minimal at three viewport sizes |
| `frontend/package.json` | `test:flexarray-perf` script |

**Unchanged:** the six-layer model and `flexArrayGeometry.ts` / `flexArrayData.ts`, the 2D fallback component, the electrode matrix, the GLB exporter and validator, `assets/3d/`, the entire backend, and all other routes.

## Test results (2026-11-14)

| Suite | Result |
|---|---|
| Backend `pytest` | 65 passed |
| Frontend unit | 58 passed (53 → 58) |
| Typecheck + production build | Succeeds. The 3D chunk is 205.7 kB (65.5 kB gzipped), up 15.7 kB / 4.4 kB gzipped; the main bundle is unchanged at 58.7 kB |
| GLB re-import validator | All checks passed |
| Existing e2e `tests/browser.cjs` | 5/5 PASS |
| Existing `tests/muscle-browser.cjs` | PASS |
| `tests/flexarray-browser.cjs` | 20/20 PASS |

The FlexArray checks cover all six layer selections, rotation and zoom, exploded and assembled modes, both scales, desktop and phone, keyboard, the research sheet, full screen, reduced motion, the safety rail, WebGL loss and no-WebGL.

The `browser.cjs`, `muscle-browser.cjs` and `flexarray-browser.cjs` runs used a temporary FastAPI server on port 8000 with a throwaway database.

**Frame rate.** Measured with `tests/flexarray-perf.cjs`, headless Chromium on the Apple M4 GPU through ANGLE/Metal:

| Viewport | Bay | Minimal |
|---|---|---|
| Desktop 1600×900 | 60 fps | 60 fps |
| Desktop 1600×900 @2× (retina) | 60 fps (was 32–42 before the pixel-ratio cap) | 60 fps |
| Phone 390×844 @3×, lite (emulated on the Mac GPU, **not a real phone**) | 60 fps | 60 fps |

In the CI-style software renderer (SwiftShader, no GPU) the bay runs at 3.6 fps against 8.1 fps for Minimal on desktop, and 4.5 fps on the emulated phone in lite mode. That renderer is far slower than any real GPU, but it shows the bay is fill-rate heavy on very weak hardware. Minimal remains available for that case.

## Known limitations

- The suits and props are stylised low-poly shapes, not photoreal assets. Higher fidelity would need properly licensed models (e.g. CC0) or bespoke modelling.
- No real-phone GPU measurement was possible here; the figures above come from the Mac GPU and a software renderer.
- The background choice is not remembered between visits.
- The bay is not part of the GLB exports, which contain the patch only.
