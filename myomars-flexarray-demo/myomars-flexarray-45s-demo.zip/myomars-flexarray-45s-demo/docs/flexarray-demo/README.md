# FlexArray-MN — guided demonstration (45 s)

> Conceptual engineering design — not manufactured, clinically validated, or flight-qualified.
> Guided demo · synthetic data · not a clinical diagnosis.

A **Start demo** button on the FlexArray page plays a 45-second cinematic walkthrough inside the Mars EVA preparation bay. It is sized for a 3-minute NASA Space Apps presentation. The six-layer patch and all existing controls are unchanged: the demo drives them (camera, explode/assemble, layer highlight) and hands them back when it ends.

**Open it at:** `http://127.0.0.1:8000/#flexarray` (with the app started as in the project README), then press **Start demo**.

## Timeline: exactly 45 s of scripted content

| # | Time | Scene | What happens |
|---|---|---|---|
| 1 | 0:00–0:07 | **Before EVA** | Wide shot of the bay, suits and Mars window. One caption introduces fictional crew A01. |
| 2 | 0:07–0:18 | **FlexArray Technology** | Camera moves to the patch, which explodes into six layers. Short labels highlight layer 02 (microneedle array), 03 (sweat management) and 04 (flexible electronics). |
| 3 | 0:18–0:32 | **AI Muscle Monitoring** | Simulated helmet HUD: synthetic sEMG (RMS, median frequency) and IMU for both quadriceps, compared with a fictional personal baseline. When the existing MuscleSense rule triggers, a **left-quadriceps fatigue-related trend** alert appears, tagged **Not a diagnosis**. |
| 4 | 0:32–0:45 | **Mars Base Medical Review** | The console shows evidence (trend chart and rule result), personal baseline and sensor quality, then the **human reviewer gate**. After a person clicks **Confirm review as demo reviewer**, the console shows a simulated approved retest instruction, the crew acknowledgment and a reassessment ("No demo trend flag"). |

**Caption beats** (every caption line is 10 words or fewer; a unit test enforces this):

| Time | Caption | Sub-label |
|---|---|---|
| 0:00 | Sol 142 · Crew A01 prepares for a Mars EVA | Fictional astronaut · all data synthetic |
| 0:07 | Six flexible layers · exploded view | Magnified for clarity · not to scale |
| 0:09.5 | Layer 02 · Microneedle array | 8 × 8 candidate sites · geometry not validated |
| 0:12.3 | Layer 03 · Sweat management | Proposed microchannels route sweat away · untested concept |
| 0:15.1 | Layer 04 · Flexible electronics | sEMG front end, ADC, IMU, radio · concept only |
| 0:18 | Simulated EVA telemetry · sEMG and IMU, both quadriceps | Compared with a fictional personal baseline |
| ≈ 0:24.5 | Left quadriceps · fatigue-related trend flagged for review | Not a diagnosis · existing MuscleSense demo rule triggered |
| ≈ 0:28.5 | Evidence sent to Mars base medical (simulated) | No automatic instruction to the crew |
| 0:32 | Mars base medical review · evidence and baseline | Trend, personal baseline and sensor quality |
| **0:35** | **Human reviewer confirmation required** (clock pauses) | Paused for review · elapsed time may exceed 45 s |
| after confirm | Review confirmed by demo reviewer (simulated) | No real authorization is created |
| 0:36.5 | Approved retest instruction sent (simulated) | No treatment or recovery duration prescribed |
| 0:39.5 | Crew acknowledges the instruction (simulated) | Crew A01 confirms and pauses strenuous tasks |
| 0:42 | Reassessment · no demo trend flag | Return-to-EVA decision stays with medical team and mission control |

### Pausing at the review gate

The scripted timeline is 45 s, but the clock **stops at 0:35** until a person confirms. It then plays the remaining 10 s. Real elapsed time is therefore 45 s plus however long the presenter waits at the gate.

The UI explains this in three places:
- the caption: "Paused for review · elapsed time may exceed 45 s";
- the review console: "Scripted timeline paused at 0:35 of 0:45. Actual elapsed time may exceed 45 s while waiting for review.";
- the time display: "0:35 / 0:45 · review".

**Presenter tip:** let scenes 1–3 play hands-free (35 s). Narrate the review console while the demo waits, then click **Confirm** to finish the last 10 s.

**Controls:**
- play / pause, previous / next scene, replay, skip demo;
- a seekable position slider (keyboard accessible, 1-second steps);
- Escape exits the demo.

Captions are announced to screen readers through a live region. The demo keeps the scale badge, the scale readout ("Patch shown magnified · bay backdrop not to scale") and the exact disclaimer on screen throughout. The HUD and the console carry "SIMULATED · SYNTHETIC DATA" labels.

## Data and safety design

**Synthetic data from existing logic.** Every number comes from the existing MuscleSense simulation in `src/muscleSense.ts`, unchanged:
- left quadriceps: `muscleSample('a01', 'left', s, 'fatigue')`;
- right quadriceps: `'nominal'`;
- baseline: `muscleBaseline`;
- review decision: `muscleSummary`, with the existing demo rule (≥ 15 % median-frequency decrease over 5 valid samples, quality ≥ 80 %, contact, no artifact).

**The alert appears only when the rule triggers.**
- The HUD alert box is drawn only while `muscleSummary` of the samples shown so far returns the review status.
- The 30 synthetic samples play over the first 10 s of scene 3. The rule first triggers at sample 20, about 0:24.3.
- The alert caption is timed from that sample (`EVENT_AT`, about 0:24.5). If the rule never triggered, no alert would be scripted.
- A unit test sweeps scene 3 in 25 ms steps. It checks that no alert caption appears while the rule is not met, and that the alert stays up once it is.

**No diagnosis claims.** Every mention of "diagnosis" is the negation "not a diagnosis" (unit-tested). The console repeats the existing limitation: "A frequency decrease alone cannot establish fatigue or injury." The demo text never mentions RER and never triggers an abort (unit-tested).

**Human authorization is preserved:**
- Autoplay stops at the reviewer gate and never confirms.
- Next and Play are disabled at the gate, and the slider clamps there.
- The retest instruction appears only after a person clicks **Confirm review as demo reviewer**.
- Replay resets the confirmation.

The confirmation is explicitly labelled "Demo reviewer (simulated) … no authorization record is created and no data leave this page."

**The retest instruction prescribes nothing.** It reads: "Pause strenuous tasks. After rest, repeat the left-quadriceps check under comparable conditions and report back." It gives no duration, treatment or medication (unit-tested). Return-to-EVA decisions stay "with the human medical team and mission control".

**No side effects:**
- The demo makes **no `/api` requests**.
- It writes **nothing to localStorage**, the audit log or SQLite.
- It never calls the real authorization endpoint.

A browser test records all requests and storage throughout the demo and asserts both stay empty / unchanged.

## Layout: no overlapping HUD, captions or controls

- **HUD layout.** The HUD is laid out top-down. The two quadriceps columns sit at the top-left and top-right, and the alert drops into the right column under them. The centre stays clear for the 3D patch at every screen height.
- **Review console.** On short laptop and projector screens it compacts so the whole console fits at the gate without scrolling: chart, evidence, baseline, rule note, gate note and the Confirm button.
- **Other screen sizes:**
  - Portrait tablets stack the console above the caption.
  - Small phones drop the subtitle and secondary HUD detail.
- **Checks.**
  - Browser tests assert that no two demo elements overlap: desktop 1512×945 (every scene), projector 1280×720 (every scene) and phone 390×844.
  - A one-off probe also checked 14 viewports × 15 beats with no overlap: 1920×1080, 1920×960, 1512×945, 1440×900, 1440×790, 1366×768, 1280×720, 1280×640, 1024×768, 768×1024, 412×915, 390×844, 375×667, 360×780.

## Screenshots

All were rendered on the Apple M4 GPU through ANGLE/Metal.

**Desktop 1600×900:**
- `desktop-1-before-eva.png`
- `desktop-2-microneedle.png`
- `desktop-3-hud-event.png`
- `desktop-4-review-gate.png`
- `desktop-4b-confirmed-reassess.png`

**Projector 1280×720:**
- `projector-1280x720-3-hud-event.png`
- `projector-1280x720-4-review-gate.png`

**Phone 390×844:**
- `mobile-1-before-eva.png`
- `mobile-2-microneedle.png`
- `mobile-3-hud-event.png`
- `mobile-4-review-gate.png`
- `mobile-4b-confirmed-reassess.png`

## Changed files (45-second revision)

| File | Change |
|---|---|
| `frontend/src/flexarray/demoScript.ts` | 45 s timeline with the scene boundaries above. Short captions (≤ 10 words) plus a word-count helper. The alert time is derived from the MuscleSense flag (`EVENT_AT`). The gate has captions for after confirmation, and there is an end caption. Scene titles are updated. |
| `frontend/src/flexarray/DemoPlayer.tsx` | Captions switch after confirmation. The review-wait note appears in the console, the caption, the time display and the screen-reader text. The HUD alert is shorter, with a "Not a diagnosis" tag. The evidence chart has a fixed height. |
| `frontend/src/flexarray/flexarray.css` | Top-down HUD layout with the alert in the right column. Review console width scales with the screen. Layouts for short screens, portrait tablets, narrow phones and short phones. Styles for the new elements. |
| `frontend/tests/flexarray.test.cjs` | Demo unit tests rewritten: exact 45 s and scene boundaries, alert timing against the rule, gate pause and resume, ≤ 10-word captions, no RER/abort wording |
| `frontend/tests/flexarray-demo.cjs` | 17 browser checks (was 15): new scene-boundary and 1280×720 projector checks, overlap assertions, and the review-wait note. Natural playback now continues to 0:45 only after confirmation. |

**Unchanged:**
- `FlexArrayExplorer.tsx`, `main.tsx`, `muscleSense.ts`, `rules.ts`;
- all backend code, mission approvals and safety rules;
- the six-layer model and geometry;
- the GLB tools and assets;
- `package.json` and all other routes.

## Test results (2026-11-14)

| Suite | Result |
|---|---|
| Backend `pytest` | 65 passed |
| Frontend unit (`npm test`) | 64 passed |
| Typecheck + production build | Succeeds. FlexArrayExplorer chunk 79.3 kB (27.8 kB gzipped); main bundle unchanged at 58.8 kB |
| GLB re-import validator | All checks passed |
| Existing e2e `tests/browser.cjs` | 5/5 PASS |
| Existing `tests/muscle-browser.cjs` | PASS |
| `tests/flexarray-browser.cjs` | 20/20 PASS |
| `tests/flexarray-demo.cjs` | **17/17 PASS** |
| GPU frame rate (`tests/flexarray-perf.cjs`) | 60 fps at desktop, retina and emulated-phone sizes. One of two runs measured 52.7 fps for the Minimal background at retina. |

The 17 demo checks:
1. Start: scene 1 with labels, disclaimer and readout; the timeline reads "/ 0:45" and its maximum is 45000; no overlap.
2. Pause / play.
3. Scene 2: explode, then highlight layers 02, 03, 04, checked in the 3D badges.
4. Previous.
5. Scene boundaries at 0:07, 0:18 and 0:32, by seeking and with Next.
6. Scene 3: no alert at sample 19 (0:24). At 0:25 the alert appears with "Not a diagnosis" in both the HUD and the caption.
7. Scene 4: evidence, baseline, sensor quality.
8. Human gate: scrubbing, Next, Play and waiting cannot pass 0:35. Focus moves to Confirm, and the review-wait note is shown.
9. Confirm, then instruction, acknowledgment, reassessment (scrolled into view) and end at 0:45.
10. Replay resets the gate.
11. Natural playback stops at the gate, holds, and plays to 0:45 only after confirmation.
12. Skip restores the explorer and returns focus.
13. Escape exits; layer selection still works.
14. No `/api` calls, no storage writes, no page errors.
15. Reduced motion: instant transitions, no caption animation, gate enforced.
16. Projector 1280×720: no overlap in any scene; the review console fits at the gate with the evidence chart visible.
17. Phone: fits, no overlap, HUD and review usable, confirm by tap.

**Test environment.**
- The browser suites ran against temporary FastAPI servers with throwaway SQLite databases; the app's own `backend/astra.sqlite3` was never written.
- The preview PNGs that `browser.cjs` overwrites were restored.
- The previous 84-second screenshots and README were archived outside the project.

## Limitations

- **Demo-only screens.** The HUD and the medical-review console are illustrations only. By design they are not wired to the app's real readiness review, authorization flow or telemetry, so the safety logic stays untouched.
- **Clock speed.** The clock runs on the browser's animation frames, capped at 250 ms per frame. On very slow hardware the scripted part plays slower than 45 s rather than skipping content.
- **Compressed HUD timeline.** 30 synthetic samples play in 10 s of demo time; mission elapsed times are illustrative.
- **Small screens.** On portrait tablets and small phones the review console and HUD cover more of the patch than on laptop and projector screens. On landscape screens shorter than about 700 px (e.g. a 1280×640 browser window), the review console scrolls at the gate instead of fitting. Use full screen (dock button or F) on small projectors.
- **Language and memory.** Captions are English only. The demo does not remember progress between visits.
- **Browser coverage.** Tested in Chromium (desktop, projector size, emulated phone, reduced motion). Not tested in Safari or Firefox, or on a real phone.
