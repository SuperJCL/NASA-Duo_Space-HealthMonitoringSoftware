# MyoMars FlexArray-MN · 45-second guided demo

> Conceptual engineering design — not manufactured, clinically validated, or flight-qualified.
> Guided demo · synthetic data · not a clinical diagnosis.
> All profiles, missions, telemetry, baselines, and thresholds are synthetic. No real hardware or clinical validation. Demo limits are not NASA medical limits.

This package contains the **ASTRA FlexArray-MN V2.1** demonstration from the ASTRA Health AI project (MyoMars, NASA Space Apps). It is a portable copy of the working project, built so that a teammate can run the 45-second demo with one command.

## Contents

**What you will see:**
- A **Mars EVA preparation bay** (procedural 3D backdrop with suits, racks and a Mars window).
- An **interactive six-layer FlexArray-MN patch**. Rotate, zoom, explode and assemble it, and select layers 01–06.
- A **Presentation / Engineering scale toggle**. Presentation magnifies the patch for slides; Engineering shows candidate research dimensions.
- The **45-second guided demonstration** (Start demo button).
- A **synthetic astronaut helmet HUD** with simulated sEMG and IMU for both quadriceps.
- A **human medical-reviewer confirmation gate**. The demo pauses until a person clicks Confirm.
- A **retest and reassessment simulation** after the review.
- **GLB files and preview images** of the patch in `assets/3d/`.

**Folder layout:**

```
myomars-flexarray-45s-demo/
├── README.md               this file
├── start-demo.mjs          one-command launcher (Node.js only)
├── .env.example            optional settings template (port, backend DB path)
├── MANIFEST.sha256         SHA-256 of every file in the package
├── FLEXARRAY_REPORT.md     FlexArray implementation report
├── ASTRA-HEALTH-README.md  the original ASTRA Health AI README (full app, safety contract)
├── IMPLEMENTATION.md       ASTRA implementation notes
├── frontend/               React 18 + TypeScript + Vite source, tests, lockfiles
│   ├── src/flexarray/      FlexArray explorer, bay, demo player and demo script
│   ├── dist/               prebuilt production build (what the launcher serves)
│   └── tests/              unit tests and Playwright browser tests
├── backend/                FastAPI + SQLite backend (only needed for --full)
├── contracts/openapi.json  backend API contract
├── assets/3d/              6 GLB models + 4 preview images + README
└── docs/                   demo, bay and redesign notes with screenshots
```

The demo route is `frontend/src/flexarray/`. The 45-second timeline is in `demoScript.ts` and the player in `DemoPlayer.tsx`. The synthetic muscle data and the review rule come unchanged from `frontend/src/muscleSense.ts`.

## Requirements

| What | Version | Needed for |
|---|---|---|
| **Node.js** | 18 or newer (tested with 24.22.1) | Everything. The default mode needs nothing else. |
| npm (bundled with Node) or pnpm | any npm 7+ · pnpm tested 11.25.0 | Only `--rebuild` and running tests |
| Python | 3.12 or newer (tested with 3.12.10) | Only `--full` (the whole ASTRA app with its backend) and backend tests |
| Browser | Desktop Chrome or Edge, with WebGL | Viewing the demo. Safari, Firefox and phones were not tested. |
| Internet | Only to install dependencies | Not needed to run the prebuilt demo |

Install Node.js (LTS) from https://nodejs.org if `node --version` does not work.

## Installation

1. Unzip `myomars-flexarray-45s-demo.zip`.
2. Open a terminal in the unzipped `myomars-flexarray-45s-demo` folder.

The prebuilt demo needs no further installation. Install dependencies only if you want to rebuild, run the tests or use the backend.

**Frontend (rebuild and tests):**

```bash
cd frontend
npm ci              # or: pnpm install --frozen-lockfile
npm run build
```

**Backend (full app and backend tests), macOS/Linux:**

```bash
cd backend
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock.txt
```

On Windows, use `py -3 -m venv .venv` and `.venv\Scripts\python -m pip install -r requirements.lock.txt`.

## Start the application

One command, from the package folder:

```bash
node start-demo.mjs
```

| Command | What it does |
|---|---|
| `node start-demo.mjs` | Serves the prebuilt demo (`frontend/dist`). Node only; no install, no internet. |
| `node start-demo.mjs --open` | Same, and opens the page in your default browser. |
| `node start-demo.mjs --rebuild` | Installs frontend dependencies if missing (pnpm with the lockfile if installed, otherwise `npm ci`), rebuilds from source, then serves. |
| `node start-demo.mjs --full` | Runs the full ASTRA app with its FastAPI backend. Creates `backend/.venv` and installs the pinned Python packages on first run. |
| `node start-demo.mjs --port 8080` | Uses another port (or set `PORT`, see `.env.example`). |

Stop the server with **Ctrl+C**. The server listens on `127.0.0.1` only, so it is not reachable from other computers.

In the default mode, the other ASTRA screens (assessment, NeuroVision, live EVA) still open, but they run in their existing offline/local mode because no backend is running. Use `--full` to get the backend-backed workflow (SQLite audit, server-side authorization checks).

**Manual start without the launcher** (full app, after the installation steps above):

```bash
cd backend
.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

## Local URL

**http://127.0.0.1:8000/#flexarray**

This opens the FlexArray page directly. (`http://127.0.0.1:8000` opens the ASTRA app; the FlexArray page is nav entry **07 · FlexArray-MN patch**.) If you used `--port`, replace `8000`.

If an old version appears, hard-reload with **Cmd+Shift+R** (macOS) or **Ctrl+Shift+R** (Windows). The app installs an offline cache (service worker) on first visit.

## Playing the 45-second demo

1. Open the URL above and press **Start demo**.
2. Let it play. The scripted timeline is exactly 45 s:

| Time | Scene | What happens |
|---|---|---|
| 0:00–0:07 | **Before EVA** | Wide shot of the bay. Fictional crew member A01 prepares for a Mars EVA. |
| 0:07–0:18 | **FlexArray Technology** | The patch explodes into six layers. Labels highlight layer 02 (microneedle array), 03 (sweat management) and 04 (flexible electronics). |
| 0:18–0:32 | **AI Muscle Monitoring** | The simulated helmet HUD shows synthetic sEMG and IMU for both quadriceps. When the existing MuscleSense demo rule triggers (about 0:24.5), a **left-quadriceps fatigue-related trend** is flagged for review, tagged **Not a diagnosis**. |
| 0:32–0:45 | **Mars Base Medical Review** | Evidence, personal baseline and sensor quality, then the **human reviewer gate** at 0:35. After confirmation: a simulated retest instruction, crew acknowledgment and reassessment ("No demo trend flag"). |

**Controls** (bottom bar):
- play / pause, previous / next scene, replay, **Skip demo**;
- a position slider (keyboard accessible);
- **Escape** exits the demo.

Every caption is 10 words or fewer and is announced to screen readers. The demo follows the system **reduced-motion** setting.

**Full screen:** use the full-screen button in the control dock, or press **F** while the 3D view has focus. This is best on a projector. On a browser window shorter than about 700 px, the review console scrolls.

**Presenter tip:** let scenes 1–3 play hands-free (35 s), talk over the review console while it waits, then click **Confirm** for the last 10 s.

## How the reviewer confirmation works

- At **0:35** the clock **stops**. The console shows **Human reviewer confirmation required** and the button **Confirm review as demo reviewer**.
- The demo **never confirms by itself**. Play and Next are disabled at the gate, and the slider cannot move past it.
- Only a real click on the button continues the demo. It then plays the remaining 10 s: the approved retest instruction, crew acknowledgment and reassessment.
- Because the clock waits for you, **real elapsed time may exceed 45 s**. The caption, the console ("Scripted timeline paused at 0:35 of 0:45 …") and the time display ("0:35 / 0:45 · review") all say so.
- The confirmation is a **simulated demo reviewer**. It creates **no authorization record**, makes **no network requests** and writes **nothing** to browser storage, the audit log or the database. Replay resets it.
- The retest instruction prescribes nothing. It gives no treatment, medication or rest duration. Return-to-EVA decisions stay with the human medical team and mission control.

## Scientific and safety disclaimers

These statements appear in the app and in the documents in this package. Keep them when you present or share the demo.

- **Conceptual design.** FlexArray-MN is a conceptual engineering design. It is not manufactured, clinically validated, or flight-qualified. Geometry is procedural (Three.js primitives), not CAD. Microneedle geometry is "not validated"; sweat microchannels are an "untested concept".
- **Not to scale.** In Presentation scale the patch is magnified, for example microneedles are drawn 18× the 200 µm candidate length, and the bay backdrop is not to scale.
- **Synthetic data.** The astronaut (Crew A01), missions, telemetry, baselines and thresholds are fictional and synthetic. The HUD and console carry "SIMULATED · SYNTHETIC DATA" labels.
- **Not a diagnosis.** The muscle flag is a "fatigue-related trend flagged for review", produced by a demo rule (≥ 15 % median-frequency decrease vs the fictional baseline, signal quality ≥ 80 %). "A frequency decrease alone cannot establish fatigue or injury."
- **Human review is always required.** No automatic medical decision, authorization or instruction to the crew is made.
- **RER is information only.** The ASTRA app computes RER (VCO₂ / VO₂) for information only and never uses it alone to trigger an abort. The 45-second demo does not use RER at all.
- **Not NASA limits.** Demo thresholds are not NASA medical limits.

Further detail: `FLEXARRAY_REPORT.md`, `docs/flexarray-demo/README.md`, `assets/3d/README.md`, and the safety contract in `ASTRA-HEALTH-README.md`.

## Running the tests

After the frontend installation step (`npm ci` in `frontend/`):

```bash
cd frontend
npm test                      # 64 unit tests, including the 45 s timeline and gate
npm run build                 # typecheck (tsc -b) + production build
```

**Browser tests** need the app running on port 8000 (`node start-demo.mjs --full` in another terminal) and a Playwright Chromium:

```bash
cd frontend
npx playwright install chromium   # one-time, about 150 MB
npm run test:demo                 # 17 guided-demo checks
npm run test:flexarray            # 20 FlexArray explorer checks
npm run test:browser              # 5 ASTRA end-to-end checks (needs --full)
node tests/muscle-browser.cjs     # MuscleSense check (needs --full, port 8000)
node scripts/validate-flexarray-glb.mjs   # GLB re-import validator
```

Backend tests:

```bash
cd backend
.venv/bin/python -m pytest -q     # 65 tests
```

The demo and FlexArray browser tests also work in the default demo-only mode. The ASTRA end-to-end and MuscleSense tests need the backend (`--full`). `tests/browser.cjs` saves `*-preview.png` screenshots into the package folder.

## Known limitations

- **Not validated.** This is a concept demonstration with synthetic data. It is not a medical device and makes no clinical claims.
- **Browsers.** Tested only in Chromium (Chrome) on macOS with a GPU. Safari, Firefox, Windows and real phones were not tested. Without WebGL, the page falls back to a 2D view.
- **Small screens.** On tablets and small phones the HUD and review console cover more of the 3D patch than on laptops and projectors. On windows shorter than about 700 px, the review console scrolls.
- **Elapsed time.** The scripted timeline is 45 s, but the demo waits at the reviewer gate, so real elapsed time is 45 s plus the wait.
- **Simulated review.** The reviewer and the "demo reviewer" name are not authenticated. No real authorization exists anywhere in the demo.
- **Backend mode.** `--full` needs Python 3.12+ and internet for the first install. Its SQLite audit log (`backend/astra.sqlite3`) is local and not tamper-proof.
- **Launcher on Windows.** `start-demo.mjs` is written to be cross-platform but was only tested on macOS.
- **Offline cache.** After an update, the service worker may serve the previous build until a hard reload.

## Troubleshooting

| Problem | Fix |
|---|---|
| `Port 8000 is already in use` | The demo may already be running: open the URL. Otherwise use `node start-demo.mjs --port 8080`. |
| `node: command not found` | Install Node.js LTS from https://nodejs.org and open a new terminal. |
| Page shows an older version | Hard-reload (Cmd/Ctrl+Shift+R). |
| Grey or 2D view instead of 3D | Enable hardware acceleration in the browser settings, or use Chrome. |
| `--full` says Python is missing | Install Python 3.12+, or use the default mode (the demo does not need Python). |

## Verifying the download

Each ZIP comes with a SHA-256 checksum. To check the ZIP:

```bash
shasum -a 256 myomars-flexarray-45s-demo.zip           # macOS / Linux
```

On Windows PowerShell, use `Get-FileHash myomars-flexarray-45s-demo.zip -Algorithm SHA256`. Compare the result with the checksum you received.

To check every file after unzipping (macOS / Linux), run this from the package folder:

```bash
shasum -a 256 -c MANIFEST.sha256
```

## What is not included

The package deliberately leaves out:
- installed dependencies: `node_modules`, Python virtual environments;
- `.env` files, credentials, API keys and tokens (the demo uses none);
- local databases (`*.sqlite3`) and browser data;
- caches, build-info files and test-run screenshots.

All astronaut data are fictional. There is no personal data about real people.
